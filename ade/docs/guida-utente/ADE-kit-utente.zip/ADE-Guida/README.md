<!-- Copyright (c) Microsoft Corporation. All rights reserved. Licensed under the MIT License. -->

# Guida completa ad ADE

**Un tour, un progetto costruito da zero, un atlante da consultare.** Edizione del 18 novembre 2026. Il riferimento è ADE desktop con base `main` al commit `c8c4f6d81dc567e457e259c98a68e841221138bf` e le correzioni del collaudo applicate nel workspace.

ADE è un ambiente di sviluppo integrato (IDE) desktop per progettare software con diagrammi, definire contratti e comportamenti, esplorare codice e lavorare con l’intelligenza artificiale (IA). I diagrammi chiariscono chi fa cosa, quali dati usa e cosa accade se qualcosa fallisce. Con questa guida costruirai un modello di negozio, lo salverai e proverai alcune regole locali. Il modello descrittivo, il codice prodotto e le verifiche hanno risultati distinti, indicati in ogni fase.

## Come usare questa guida

La guida si rivolge a chi progetta o sviluppa software e usa ADE per la prima volta. Per iniziare basta saper gestire file e cartelle e conoscere i concetti di dato, funzione e condizione; le notazioni vengono spiegate quando servono. L16 e la modifica diretta di L20 richiedono anche basi di JavaScript e del terminale. Per installare ADE dai sorgenti servono gli strumenti indicati in A1.

Prima di T1 verifica che ADE si avvii e di poter scrivere nella cartella degli esempi estratti: userai quella copia per modificare e salvare il modello, non soltanto per leggerlo. Se devi ancora preparare l’applicazione, completa A1. Il tour e la progettazione manuale non richiedono un account IA; per generare e verificare i profili locali di L12-L15 serve Node 24.22.1 disponibile all’avvio di ADE, perché il runner esegue i file prodotti con quel runtime. Le simulazioni guidate di L14-L15 non richiedono un broker. I prerequisiti esterni delle attività assistite sono in L17-L19.

**La Parte I è un tour di Bottega Ordini**, già pronto. **La Parte II è il laboratorio Mercato**, da costruire nella tua copia. **La Parte III è l’atlante**: consultalo quando vuoi scegliere o approfondire una notazione. Le appendici raccolgono installazione, strumenti dell’IDE e recupero degli errori.

| Obiettivo | Percorso | Risultato riconoscibile |
| --- | --- | --- |
| Orientarti al primo utilizzo | A1 se necessario, poi T1-T5 | Apri, leggi, modifichi e riapri Bottega Ordini |
| Progettare Mercato | L1-L11, con l’atlante come riferimento | Modello salvato con 18 viste, tipi, contratto e decisione |
| Verificare una regola locale | L12, poi reverse in L20 | Limite 1–10 verificato, file applicati e prova di annullamento |
| Esplorare altri comportamenti locali | L13-L15, dopo i concetti di L7 e la review di L12 | Leggi le chiamate e simuli stati e consegne in moduli separati |
| Confrontarti con il codice | L16 | Sette test superati, demo e dichiarazione aperta dalle evidenze |
| Usare IA, worktree o Sync | L17-L19, solo con i prerequisiti della sezione | Bozze o modifiche revisionate nel percorso compatibile |
| Consegnare il lavoro | L21 | Progetto riapribile, risultati e decisioni aperte documentati |

L’ordine L1-L11 prepara gli oggetti riusati nelle lezioni successive. L13-L15 sono esercizi autonomi e puoi sceglierne uno dopo aver imparato la review in L12. L17-L19 sono rami facoltativi: il completamento delle attività locali non li richiede.

Per il tour prevedi circa mezz’ora; il tempo dipende dalla familiarità con l’interfaccia. Il laboratorio richiede più sessioni: fermati ai controlli di tappa, salva e riprendi. Le aperture spiegano quale problema affronti e come userai il risultato; i controlli finali indicano quando procedere. Nei progetti reali crea solo le viste utili a una decisione: il laboratorio le attraversa tutte per insegnarne l’uso.

Estrai [i progetti di esempio](progetti-esempio.zip) in una cartella tua. Copia le cartelle intere, inclusi i dati nascosti: `.ade` contiene il modello, quindi copiare soltanto i file visibili può lasciare fuori il progetto da aprire. Conserva l’archivio originale per poter ripartire senza perdere la copia su cui hai lavorato. **Non devi aprire o modificare il JSON del modello:** comandi, proprietà e form conservano i riferimenti condivisi mentre costruisci gli esercizi. Se ADE non parte ancora, svolgi prima A1.

| Materiale | Uso nella guida |
| --- | --- |
| `01-bottega-visuale` | Tour con Acquisto e Resi e rimborsi: due feature, otto viste |
| `07-mercato-laboratorio/inizio` | Spazio iniziale del laboratorio, senza un modello precostruito |
| `07-mercato-laboratorio/tappe` | Due checkpoint visuali per confrontare i primi risultati |
| `07-mercato-laboratorio/soluzione` | Riferimento completo con 18 viste nelle 16 notazioni |
| `07-mercato-laboratorio/moduli` | Esercizi eseguibili di quantità, interazioni, stati e messaggi; ogni sottocartella è un progetto ADE autonomo |
| `07-mercato-laboratorio/codice` | Piccolo modulo JavaScript da eseguire e importare |
| `02` fino a `06` | Le stesse basi dei laboratori avanzati, disponibili anche separatamente |

I nomi inglesi in grassetto riprendono i controlli dell’interfaccia. **Progetto > Project Settings** significa aprire il menu con il nome del progetto. **Palette** significa `F1`, oppure `Cmd+Shift+P` su macOS e `Ctrl+Shift+P` su Windows/Linux. La ricerca nella palette è anche un’alternativa ai menu. Nella versione HTML l’indice e la ricerca raggiungono i capitoli; clicca le immagini per ingrandirle.

Prima di iniziare, distingui tre termini: una **feature** è una capacità del prodotto, come l’acquisto; il **modello** conserva definizioni e collegamenti condivisi; una **vista** o **diagramma** ne mostra una prospettiva sul **canvas**, l’area di disegno. Una **review** è la revisione di una proposta prima di applicarla. Le immagini aiutano a orientarti; nomi dei comandi e risultati testuali permettono di seguire le procedure anche senza riconoscerne colori o posizione.

## Parte I - Tour di Bottega Ordini

Prima di costruire Mercato, osservi un negozio già modellato per riconoscere che cosa racconta ciascuna vista e che cosa rimane condiviso fra le viste. Alla fine provi una modifica reversibile: saprai ritrovare e recuperare il lavoro prima di affrontare il progetto da zero.

### T1. Apri il negozio e trova i comandi essenziali

Inizia da un negozio già modellato per imparare a leggere le viste prima di costruirne una. In questa tappa riconosci progetto e diagramma attivi e impari a raggiungere gli elementi senza cambiarli: userai questi comandi per confrontare acquisto e reso nelle tappe successive.

Dalla schermata **Start a Project** premi **Open Project**, seleziona la cartella `01-bottega-visuale` nel selettore del sistema e conferma. Devi leggere **Bottega Ordini** nella testata e **Struttura acquisto** come diagramma attivo.

![La Home: aprire, creare o importare un progetto](immagini/01-home.png)

Il negozio di esempio permette a un cliente di confermare un acquisto. Un pagamento autorizzato porta all’ordine confermato; un pagamento rifiutato porta all’esito negativo. La seconda feature gestisce la richiesta di reso e il rimborso. “Entro 30 giorni” è una regola didattica di questo progetto, non una descrizione di obblighi commerciali o legali.

![Il punto di partenza del tour, con il diagramma al centro](immagini/02-canvas.png)

Per confrontare le viste ti bastano quattro comandi: il selettore cambia prospettiva, le proprietà spiegano il contenuto e Fit Diagram ti permette di ritrovare gli oggetti prima di considerarli mancanti. Individua questi punti dell’interfaccia:

1. Clicca il **nome del diagramma** per aprire **Choose Diagram**. Digita parte del nome se l’elenco è lungo. Se la vista è già visibile nella barra laterale, clicca direttamente il suo nome.
2. **Un elemento del canvas:** apre le sue proprietà; **Close Properties** le richiude.
3. **Fit Diagram:** inquadra l’intero contenuto. Zoom e trascinamento dello sfondo aiutano a leggere.
4. **Nome del progetto:** consente di tornare alla Home o aprire un altro progetto. Le impostazioni servono più avanti.

**Diagrams** apre e chiude la navigazione laterale; **Code** raccoglie il lavoro sul codice. Nella sidebar, **New** raccoglie Add Feature, Add Diagram e Structural Blueprint. Il cambio di vista non modifica il modello. **Save** appare con modifiche pendenti; **Model Saved Locally** indica il salvataggio locale, non un commit o una pubblicazione online.

**Controllo T1.** Apri **Choose Diagram** e trova le otto viste raggruppate nelle due feature. Il selettore include anche **Add Diagram** e **Add Feature**. Nella barra laterale **Related Diagrams** ripropone sotto Acquisto due viste della feature Resi e rimborsi. Clicca fuori dal selettore per richiuderlo. Se il canvas sembra vuoto, premi **Fit Diagram** prima di creare qualcosa.

### T2. Segui un acquisto attraverso quattro prospettive

Leggi lo stesso acquisto da quattro prospettive per separare responsabilità, alternative, messaggi e stato risultante. Parti dalla struttura per riconoscere gli oggetti, poi passa al comportamento: così una freccia di chiamata e uno stato dell’ordine non diventano due modi intercambiabili di dire la stessa cosa. Questa distinzione ti servirà quando costruirai le viste di Mercato.

Apri **Struttura acquisto**. Leggi da Cliente a Pagina acquisto, poi a Conferma ordine e infine a Ordine. Il Cliente è un ruolo; Pagina acquisto è l’interfaccia del negozio; Conferma ordine coordina la richiesta; Ordine è la risorsa registrata. La pagina del negozio non è un “diagramma”: è un elemento rappresentato nel diagramma.

Seleziona la relazione verso Ordine. **Write**, “crea ordine”, indica chi registra il dato; la condizione “pagamento autorizzato” dichiara quando la registrazione è prevista. Questa vista descrive la regola: non esegue il pagamento e non impedisce scritture nel codice. Le proprietà spiegano i ruoli senza affollare il canvas di etichette.

Nella barra laterale clicca **Flusso acquisto**. Parti da Richiedi pagamento e segui le alternative verso Ordine confermato o Pagamento rifiutato. Qui la domanda è “che cosa succede a seconda dell’esito?”, non “quale oggetto possiede il dato?”.

![Il flusso distingue conferma e rifiuto del pagamento](immagini/05-flusso.png)

Apri **Sequenza pagamento**. Le colonne sono i partecipanti; le due frecce mostrano “conferma ordine” se il pagamento è autorizzato e “mostra errore” se è rifiutato. Sono esiti alternativi: la posizione delle frecce non implica che avvengano entrambi nello stesso acquisto. Questa sequenza minima non mostra la chiamata di autorizzazione e la successiva scrittura dell’Ordine; costruirai quel dettaglio in L7. Poi apri **Stati ordine**: In attesa, Confermato e Pagamento rifiutato distinguono le condizioni dell’ordine. L’azione “richiedi pagamento” avvia un tentativo; lo stato “confermato” ne descrive l’esito positivo.

**Controllo T2:** racconta l’acquisto con quattro frasi: chi collabora, quali alternative esistono, chi chiama chi, come cambia l’ordine. Non premere Code per “eseguire” queste figure: questa variante è descrittiva. L11-L15 mostreranno come aggiungere contratti e prove eseguibili.

### T3. Esplora la seconda feature: resi e rimborsi

Dopo aver letto l’acquisto, esplora il reso: la richiesta dipende da un Ordine già esistente. Confrontando le due feature vedrai perché si riusano Cliente e Ordine e si introduce invece una nuova Richiesta di reso. Le viste del comportamento distinguono poi l’ammissione della richiesta dal completamento del rimborso.

Clicca **Struttura resi** nella barra laterale, sotto **Related Diagrams** o nella feature **Resi e rimborsi**. Se la voce è fuori dall’area visibile, usa **Choose Diagram** dalla testata. La richiesta parte dallo stesso Cliente già usato nell’acquisto, passa da Pagina resi a Gestione resi, legge l’Ordine esistente e registra una nuova Richiesta di reso. Ordine e Richiesta di reso sono due oggetti diversi: il reso fa riferimento a un acquisto, non lo sostituisce.

![Le due feature e le loro quattro prospettive nel selettore](immagini/15-tour-due-feature.png)

![La gestione del reso riusa Cliente e Ordine e introduce la richiesta](immagini/16-tour-resi.png)

Dopo aver individuato i dati condivisi, apri le altre tre viste per seguire la richiesta dalla valutazione all’esito. Il flusso mostra le alternative, la sequenza la lettura dell’Ordine prima della registrazione e gli stati distinguono una richiesta autorizzata da una già rimborsata:

| Vista | Cosa seguire | Domanda a cui rispondere |
| --- | --- | --- |
| Flusso rimborso | Valuta richiesta, Emetti rimborso, Reso non ammesso | Quale condizione ammette il rimborso? |
| Sequenza reso | Richiesta del cliente, invio, lettura ordine, registrazione | Quale informazione deve esistere prima della registrazione? |
| Stati richiesta di reso | Richiesto, Autorizzato, Rimborsato, Rifiutato | Quando una richiesta autorizzata diventa rimborsata? |

Seleziona ogni freccia del flusso e leggi la condizione. Poi guarda la transizione Autorizzato verso Rimborsato: autorizzare e completare il rimborso sono due momenti distinti. Il progetto non contatta una banca né calcola una scadenza: rappresenta la regola concordata per l’esempio.

**Controllo T3:** trova una lettura dell’Ordine e una scrittura della Richiesta di reso. Spiega perché la seconda feature riusa l’Ordine invece di crearne un duplicato chiamato “Ordine resi”.

### T4. Ritrova un elemento e riconosci l’identità condivisa

Ora che hai visto Ordine in due feature, prova a ritrovarlo e a rinominarlo in una copia. La prova rende visibile l’identità condivisa: una modifica alla risorsa si riflette nelle sue viste, mentre i titoli dei diagrammi restano autonomi. Imparare a leggere l’impatto prima di intervenire ti prepara alla modifica della prossima tappa.

Clicca **Search System** nella barra laterale. Se la barra è chiusa, riaprila con **Diagrams**. Cerca “Ordine”, leggi il tipo **Resource** e le viste associate, quindi clicca il risultato. ADE centra e seleziona la risorsa in una vista. Cliccala sul canvas per aprire **Properties**. La ricerca include le modifiche ancora da salvare e può aprire i dettagli delle identità senza una vista. **Back** e **Forward** raggiungono le destinazioni visitate.

Usa **Search System** quando conosci il nome. Per esplorare ciò che appartiene a un attore o a una feature clicca **System Map** nella testata o nella barra laterale. Il clic aggiunge filtri cumulativi, la freccia apre un livello e **×** rimuove il proprio filtro. Gli elementi interni e condivisi delle feature collegate all’attore restano disponibili. La sezione **A9** illustra accessi, filtri e relazioni.

Un elemento conserva la propria identità cambiando nome o posizione. Un diagramma seleziona elementi e relazioni e conserva un layout proprio. **Add Existing Element** riusa un’identità; **Add Element** ne crea una nuova. Due nomi identici non rendono identici due oggetti.

Nella copia del tour, seleziona **Ordine** e clicca **Rename** accanto al titolo delle proprietà. Scrivi “Ordine cliente” nel campo **Name** e premi **Save Changes**. Apri **Struttura resi** e ritrova la risorsa con il nome aggiornato. Cliccala, poi scegli **Show Change Impact** sotto **Explore** per vedere le viste e i riferimenti interessati. Premi **Undo** per ripristinare il nome originale. Se vedi **Save**, premilo per salvare le modifiche ancora pendenti.

**Controllo T4:** distingui il nome della risorsa dai nomi dei diagrammi “Stati ordine” e “Struttura acquisto”, che non devono essere rinominati automaticamente. La rinomina aggiorna il nome dell’elemento selezionato; la sua identità resta stabile e gli altri testi che contengono la parola ordine non cambiano.

### T5. Fai una prima modifica reversibile

Aggiungi una notifica per provare una modifica piccola dopo aver imparato a leggere e ritrovare gli oggetti. Rappresentala come componente perché stai assegnando una responsabilità, e collega Conferma ordine con una richiesta condizionata all’ordine confermato. Salvataggio, Undo/Redo e riapertura ti permettono di controllare separatamente la scelta di progetto e la sua conservazione locale prima di iniziare Mercato.

Lavora in una copia di Bottega Ordini per provare anche salvataggio e annullamento. Apri Struttura acquisto:

1. Premi **Add Element**. Nel form scrivi “Notifiche ordine” in **Name**, scegli **Component** in **Element Type** e clicca **Create**.
2. Trascina il componente in uno spazio libero. Clicca **Conferma ordine** sul canvas, premi **Connect** e scegli **Invocation**.
3. Clicca **Notifiche ordine** sul canvas. Nel form **Create Relationship** scrivi “invia conferma” in **Relationship Name** e `ordine confermato` in **Condition (Optional)**. Clicca **Save Changes** per creare la relazione oppure **Cancel** per annullare.
4. Seleziona la freccia e controlla origine, destinazione e testo. Richiudi le proprietà.
5. Clicca **Save** nella testata. Se compare **Update Codebase from Diagrams**, scegli **Cancel**. Qui stai salvando la responsabilità nel modello. La sua implementazione verrà dopo.
6. Clicca **Undo** e poi **Redo** accanto a **Fit Diagram**. Salva la versione che vuoi conservare. Dal menu **Bottega Ordini** scegli **Open Project**, seleziona di nuovo la cartella del tour e controlla che la modifica salvata sia presente.

![In Mercato le proprietà di Ordine mostrano Rename e Remove from This Diagram](immagini/04-proprieta.png)

Per togliere una rappresentazione dal canvas, seleziona l’elemento e premi **Remove from This Diagram** nella scheda **Properties**. Il riquadro si chiude e puoi usare **Undo** accanto a **Fit Diagram** per ripristinare l’elemento. **Delete Element**, sotto **Manage**, rimuove la definizione condivisa dal sistema e può coinvolgere altri riferimenti. Controlla l’impatto prima di confermarla. Eliminare una vista conserva gli elementi semantici. Se cambi progetto con modifiche pendenti, scegli salvataggio, scarto o annullamento.

**Controllo T5:** dopo la riapertura ritrova la notifica e la relazione; oppure, se hai scelto di annullarle, controlla che siano assenti. Hai completato il tour quando sai raggiungere una vista, leggere una relazione, riusare un’identità e recuperare una modifica.

## Parte II - Laboratorio: costruisci Mercato da zero

Ora trasformi una richiesta di negozio in scelte verificabili: prima chiarisci utenti e confini, poi responsabilità, dati e comportamenti. Le viste costruite preparano i contratti; i moduli locali ti fanno provare alcune regole senza richiedere un e-commerce completo. Questo è l’ordine didattico del laboratorio, non un obbligo di produrre tutte le viste in ogni progetto.

### L1. Prepara il laboratorio e scegli la cartella giusta

Prepara una cartella di lavoro per costruire **Mercato**, un piccolo e-commerce didattico, senza sovrascrivere i riferimenti. Dopo il tour passi da leggere un progetto a prendere le tue decisioni: parti quindi da `inizio` o da una cartella vuota. I checkpoint serviranno a confrontare i risultati; i moduli separati serviranno più avanti alle prove eseguibili.

Il Cliente acquista e chiede resi; l’Assistenza li gestisce. Pagamenti esterni autorizza il pagamento, Corriere esterno rappresenta la consegna e Catalogo prodotti fornisce il contesto dei dati. Otterrai un modello coerente e prove locali di comportamenti delimitati; il pacchetto non avvia un negozio reale.

Separa ora lavoro, checkpoint e moduli: ADE apre una root alla volta e salva il modello nella cartella scelta. Partire dalla soluzione nasconderebbe gli effetti delle creazioni che stai per imparare. Prepara il materiale così:

1. Estrai `progetti-esempio.zip` e conserva l’archivio originale.
2. Trova `07-mercato-laboratorio`. **Non aprire questa cartella contenitore come progetto ADE.** Aprirai ogni volta la sottocartella indicata dalla lezione.
3. Per costruire il progetto usa `inizio`, che contiene solo istruzioni, oppure crea con il gestore file una cartella vuota chiamata `Mercato-mio`. Non copiarvi il modello della soluzione.
4. Avvia ADE. Se stai guardando un diagramma, premi **Home** nella barra laterale **Diagrams** o apri il menu con il nome del progetto e scegli **Home**.

La regola didattica è: quantità intera da 1 a 10 per riga, prezzi in centesimi per evitare arrotondamenti impliciti, almeno una riga per ordine, conferma solo dopo autorizzazione del pagamento, reso riferito a un ordine esistente e ammesso entro 30 giorni. Il coupon sarà un esempio opzionale nei casi d’uso. Tasse, pagamenti reali, sicurezza e regole commerciali effettive richiedono una specifica ulteriore.

| Lezioni | Cartella da aprire | Cosa farai |
| --- | --- | --- |
| L2-L11 | La tua `Mercato-mio` o `inizio` | Costruzione manuale delle viste e dei contratti |
| Confronto dopo L3 | `tappe/01-confini` | Controllo della prima tappa senza sovrascrivere il tuo lavoro |
| Confronto dopo L5 | `tappe/02-architettura-dati` | Controllo di architettura e dati |
| Confronto dopo L10-L11 | `soluzione` | Riferimento finale |
| L12 | `moduli/quantita`, in una copia | Regola eseguibile, casi, review, verifica, Apply e Undo |
| L13-L15 | `moduli/interazioni`, poi `moduli/stati`, poi `moduli/messaggi` | Tre esercizi locali distinti |
| L16-L20 | `codice`, in una copia, e il progetto pertinente alla lezione | Test, importazione e percorsi avanzati |

“Root del progetto” significa precisamente la cartella scelta in Open Project o Create Project. Il clone dell’IDE e la cartella del tuo negozio hanno scopi diversi. **Open Project** apre un modello già presente; **Create Project** prepara quello nuovo; **Import Codebase** analizza una cartella di sorgenti.

Salva alla fine di ogni lezione per avere una tappa da riprendere. Per confrontarla, apri una copia del checkpoint con Open Project e poi riapri la tua cartella per continuare. Non incollare il file della soluzione sopra il tuo modello: sostituiresti il lavoro invece di confrontarlo. I moduli eseguibili sono progetti autonomi: il modello descrittivo principale non si trasforma da solo in un intero e-commerce.

### L2. Crea il progetto, le feature e la prima struttura

Costruisci prima una panoramica dell’acquisto per assegnare un nome alle responsabilità e ai dati che riuserai nelle viste successive. Le feature Acquisto, Catalogo prodotti e Resi e rimborsi organizzano le capacità del negozio; la Structure ti permette di mostrare insieme chi entra, chi coordina e quale risultato viene registrato, prima di precisare confini e dettagli.

#### Creazione e navigazione iniziale

Crea prima il progetto nella cartella preparata, poi le tre feature: avrai destinazioni riconoscibili per le viste di acquisto, catalogo e resi. Il raggruppamento serve alla navigazione del modello; non definisce ruoli di accesso o servizi in esecuzione. Torna infine alla Structure di Acquisto per costruire una sola panoramica di partenza.

1. Nella Home premi **Create Project**.
2. Scrivi `Mercato` in **Name** e premi **Save Changes**.
3. Seleziona la cartella preparata in L1 e premi **Apri**. Su macOS puoi anche creare `Mercato-mio` con **Nuova cartella** nel selettore. ADE apre la Home di Mercato.
4. Premi **Create First Feature**, scrivi `Acquisto` e premi **Save Changes**. ADE apre **Acquisto · Structure** e crea anche **Acquisto · Flow**.
5. Clicca il nome della vista nella testata, scegli **Add Feature**, scrivi `Catalogo prodotti` e premi **Save Changes**.
6. Ripeti il passaggio per `Resi e rimborsi`.
7. Dal nome della vista apri **Acquisto · Structure**. Se la vista è già visibile in **Diagrams**, puoi aprirla direttamente con un clic.

Nel laboratorio le viste ordinarie saranno associate alla feature scelta dal form, prevalentemente Acquisto; le due viste Resi avranno la propria feature. Le viste C4 si creano dal blueprint e compaiono anche nella navigazione del sistema. La classificazione della vista non duplica gli elementi che essa mostra.

#### Aggiungi i primi sei elementi

Dai alla panoramica sei identità da riusare: Actor indica chi agisce, Application / Container il negozio web, Component le responsabilità interne, Resource il risultato di dominio e Software System il servizio di pagamento. Scegliere i tipi adesso permette ai picker delle viste successive di proporre le rappresentazioni compatibili; nomi uguali non sostituiscono questa distinzione.

Per ogni riga premi **Add Element**, compila **Name** e premi **Create**. Cambia **Element Type** quando il tipo proposto è diverso da quello della riga. L’elenco mostra i tipi disponibili per la vista corrente. **Cancel** chiude il modulo.

| Nome | Element Type | Responsabilità |
| --- | --- | --- |
| Cliente | Actor | Richiede l’acquisto |
| Web shop | Application / Container | Applicazione web del negozio |
| Checkout | Component | Coordina la conferma |
| Ordine | Resource | Risultato di dominio registrato |
| Pagamenti esterni | Software System | Servizio esterno di autorizzazione |
| Gestione resi | Component | Consulta l’acquisto per gestire il reso |

La forma Software System verrà qualificata come esterna in L3. Per ora basta crearla. Se una scheda finisce fuori dall’inquadratura premi **Fit Diagram**. Non aggiungere un duplicato per sostituire una scheda che non riesci a vedere.

#### Crea una relazione dall’inizio alla fine

Collega gli elementi per trasformare l’elenco delle responsabilità in un percorso leggibile: ingresso del Cliente, coordinamento del checkout, autorizzazione e registrazione. Inizia da Cliente verso Web shop per imparare il form completo, poi ripetilo per gli altri significati:

1. Clicca **Cliente** sul canvas e premi **Connect**.
2. Se compare **Relationship Type**, scegli **Communication**. Se il tipo compatibile è unico, ADE evidenzia subito le destinazioni.
3. Clicca **Web shop** tra le destinazioni evidenziate sul canvas.
4. Scrivi `naviga` in **Relationship Name**, lascia vuoto **Condition (Optional)** e premi **Save Changes**.

Se l’origine è già selezionata, puoi iniziare da **Connect**. **Connect Selection** nelle proprietà apre il modulo completo, con tipo, destinazione, nome e condizione nella stessa schermata.

Ripeti lo stesso procedimento per le quattro righe seguenti. Compila la condizione soltanto dove indicata.

| Origine | Relationship Type | Destinazione | Relationship Name | Condition |
| --- | --- | --- | --- | --- |
| Web shop | Invocation | Checkout | invia acquisto | Vuota |
| Checkout | Invocation | Pagamenti esterni | autorizza pagamento | Vuota |
| Checkout | Write | Ordine | registra ordine | pagamento autorizzato |
| Gestione resi | Dependency | Checkout | consulta acquisto | Vuota |

Communication descrive l’accesso al negozio, Invocation una richiesta, Write la registrazione del dato. La condizione sul Write dichiara che la registrazione è prevista solo dopo l’autorizzazione; il diagramma non esegue né verifica la regola. Dependency dichiara ciò che Gestione resi usa, senza imporre un ordine di chiamate.

**Riusare un elemento e riusare una relazione sono due operazioni distinte.** Add Existing Element aggiunge soltanto la scheda. In una vista ordinaria includi prima entrambi gli estremi, poi usa **Diagram > Contents > Add Existing Relationship** e scegli il collegamento. Una vista C4 può includere le relazioni compatibili fra gli elementi visibili. Controlla il canvas prima di aggiungerne una. In Sequence usa Add Existing Message. Non usare Connect per copiare un collegamento: creerebbe una seconda relazione nel sistema.

#### Rinomina, disponi e salva

Assegna alla vista un nome che ne esprima lo scopo: la ritroverai fra i diagrammi creati nelle prossime lezioni. Disponi elementi ed etichette per leggere le responsabilità senza aprire ogni proprietà; poi salva e riapri per controllare che la prima tappa sia conservata nella root corretta.

Se le proprietà sono aperte, premi **Close Properties**. Apri **Diagram** e premi **Rename** accanto al titolo. Scrivi `01 Panoramica delle responsabilità` e premi **Save Changes**. Controlla il nuovo nome nella testata.

Apri **Diagram** e premi **Arrange** accanto al titolo. Scegli **Balanced**, poi premi **Fit Diagram**. Puoi trascinare le schede per rendere più chiaro il percorso. In **Diagram > Layout and Display**, **Show Relationship Labels** mostra tutte le etichette.

Premi **Save** nella testata. Se compare **Update Codebase from Diagrams**, scegli **Cancel**. Il salvataggio del modello è indicato da **Model Saved Locally**.

**Controllo L2:** torna alla Home, scegli Open Project e riapri la stessa cartella. Devi trovare tre feature, sei elementi nella panoramica e cinque relazioni. Le altre viste automatiche possono essere ancora vuote. Continua sulla tua panoramica: non occorre crearne una seconda a livello di sistema.

### L3. Definisci il contesto e gli obiettivi degli utenti

La panoramica di L2 nomina le prime responsabilità. Ora fissa il confine di Mercato e gli obiettivi di Cliente e Assistenza: il Context distinguerà ciò che progetti dai servizi esterni, i casi d’uso ciò che il negozio deve consentire. In L4 suddividerai l’interno sulla base di questi obiettivi, senza confondere un servizio esterno con una parte da realizzare.

#### Apri Structural Blueprint

Structural Blueprint conserva dichiarazioni condivise come confini, appartenenze e contratti. Lo userai per assegnare queste proprietà agli oggetti già creati e controllare la bozza prima di aggiornare il modello.

Premi **Structural Blueprint** nella testata. A sinistra scegli un’area e un’attività, per esempio **Structure > C4 View Subject and Context**. Al centro seleziona una voce in **Configuration** per modificarla oppure usa il pulsante di creazione dell’attività. Compila i campi direttamente nella scheda. Puoi cambiare configurazione o attività e ritrovare le modifiche in bozza.

In basso **Review** mostra le modifiche in bozza e il nome di ciascuna configurazione ti riporta alla sua scheda. **Apply to Model** applica tutte le configurazioni valide al modello. Premi **Save** nella testata per conservarle nel progetto. **Cancel Creation** scarta la nuova configurazione corrente e **Discard Draft** scarta tutte le modifiche in bozza. Per tornare al lavoro sul canvas premi **Back to Diagram** o **Back to Workspace**. Le azioni contestuali delle proprietà aprono l’attività sull’oggetto da cui provieni. In L12, **Apply to Project** scrive i sorgenti della review del codice.

#### Crea e qualifica il sistema

Aggiungi Mercato come Software System per rappresentare il confine del prodotto: il solo nome del progetto non lo crea. Dichiara quali sistemi governi prima del Context, perché il suo soggetto deve essere un sistema governato. Riusa Cliente e Pagamenti esterni di L2 per mantenere gli stessi riferimenti; crea solo il Corriere e il ruolo Assistenza che mancavano.

Nella panoramica premi **Add Element**, compila **Name**, scegli **Software System** in **Element Type** e premi **Create**. Crea così **Mercato** e **Corriere esterno**. Per **Assistenza** usa lo stesso form con **Actor**. Cliente e Pagamenti esterni esistono già.

Apri **Structural Blueprint > Structure > System Scope or Container Responsibility**. In **Configuration** scegli **Mercato** e in **Scope** seleziona **Governed System**. Passa a **Pagamenti esterni** e **Corriere esterno** dallo stesso selettore e imposta **External System** per entrambi. Premi **Apply to Model**. Mercato è il sistema che progetti, gli altri due forniscono servizi dall’esterno.

#### Crea il C4 Context

Il modello C4 descrive l’architettura per livelli: dal contesto del prodotto alle applicazioni e ai loro componenti. Parti dal Context per vedere chi usa Mercato e quali servizi gli stanno fuori, senza anticipare la divisione interna di L4. Il soggetto fissa ciò che analizzi; il contesto dichiara le dipendenze esterne; i visibili scelgono quali di queste identità disegnare. Tieni il soggetto visibile per rendere riconoscibile il confine e distingui dichiarare una dipendenza dal mostrarla nella vista.

1. In **Structure > C4 View Subject and Context** premi **New C4 View**.
2. In **View Identity** scrivi `02 C4 Contesto Mercato` come **View Name**, scegli **L1 · System Context** in **C4 Level** e **Mercato** in **View Subject**. Se non trovi Mercato, controlla che sia un Software System con scope Governed System.
3. Nella tabella **View Contents** spunta **Context** e **Visible** per Cliente, Assistenza, Pagamenti esterni e Corriere esterno. Mercato è già visibile come soggetto. Per trovare una voce puoi usare **Filter Elements**. Le selezioni restano quando cambi il filtro.
4. Controlla **View Preview**, premi **Apply to Model**, poi **Open Diagram** nella scheda della vista.

![Structural Blueprint mostra il soggetto Mercato e le quattro dipendenze del contesto](immagini/33-blueprint-choose.png)

Completa il Context con gli scambi che attraversano il confine. Nel form **Create Relationship** usa come **Relationship Type** **Communication**, scegli origine e destinazione, scrivi il nome, lascia vuoto **Condition (Optional)** e premi **Save Changes**. Collega Cliente a Mercato con “acquista e richiede resi”, Assistenza a Mercato con “gestisce richieste”, Mercato a Pagamenti esterni con “autorizza e rimborsa” e Mercato a Corriere esterno con “richiede consegna”. Se una relazione è già visibile, riusala.

Se un progetto esistente mostra **Draft Needs Correction** per il perimetro C4, riapri **C4 View Subject and Context**, scegli la vista in **Configuration** e controlla **C4 Level** e **View Subject**. La scheda include automaticamente il soggetto fra i visibili. Premi **Apply to Model** e salva.

#### Crea Use Case e aggiungi gli elementi esistenti

Il Context ha chiarito chi sta dentro e fuori; i casi d’uso chiariscono quale risultato gli attori chiedono al negozio. Il Cliente vuole confermare un acquisto e richiedere un reso; l’Assistenza interviene nella gestione della richiesta. Rappresenta questi obiettivi prima dei container di L4 per assegnare poi responsabilità che li servano. È l’ordine scelto dal laboratorio, non un vincolo tecnico di ADE. Al termine distinguerai gli obiettivi degli attori, l’autorizzazione necessaria e il coupon facoltativo: saranno riferimenti per flussi, contratti e casi successivi.

Apri **Add Diagram**. Nel form **Create Diagram** scrivi `12 Casi d’uso` in **Name**, scegli **Use Case** in **Diagram Type** e **Acquisto** in **Choose Feature**. Premi **Create** per aprire la nuova vista.

Dal canvas premi **Add Existing Element**, cerca Cliente e scegli la riga di tipo **Actor**. Ripeti per Assistenza e per il **Software System Mercato**. L’azione riusa la stessa identità nella vista.

Riusa gli attori e Mercato del Context per collegare gli obiettivi alle stesse identità e allo stesso confine. Con **Add Element** scegli **Use Case** in **Element Type** e crea **Confermare acquisto**, **Autorizzare pagamento**, **Richiedere reso** e **Applicare coupon**. Le associazioni indicano chi partecipa all’obiettivo. **Include** dichiara un comportamento necessario ed **Extend** l’aggiunta condizionata. Collega gli elementi come indicato qui sotto.

| Origine | Tipo | Destinazione | Nome | Condizione |
| --- | --- | --- | --- | --- |
| Cliente | Association | Confermare acquisto | avvia | Vuota |
| Cliente | Association | Richiedere reso | richiede | Vuota |
| Assistenza | Association | Richiedere reso | gestisce | Vuota |
| Confermare acquisto | Include | Autorizzare pagamento | include | Vuota |
| Applicare coupon | Extend | Confermare acquisto | extend | coupon presente |

Assegna i quattro casi d’uso a Mercato per dichiarare a quale sistema appartengono. Apri **Structural Blueprint > Structure > Architectural or Lifecycle Owner**. In **Configuration** scegli **Confermare acquisto** e in **Architectural Owner** seleziona **Mercato**. Espandi **Assign the Same Owner to More Elements** e spunta **Autorizzare pagamento**, **Richiedere reso** e **Applicare coupon**. Premi **Apply to Model** e **Back to Diagram**. Con Mercato visibile il diagramma rappresenta il confine dei suoi casi. Usa **Diagram > Arrange > Balanced**, poi **Fit Diagram** per disporre gli ovali e mantenerne leggibili i nomi.

L’autorizzazione del pagamento è necessaria alla conferma: usa Include. Il coupon è opzionale: usa Extend, dal comportamento aggiuntivo al caso base. La distinzione guida le alternative attese: l’assenza del coupon non deve escludere l’acquisto, mentre senza autorizzazione non è prevista la conferma. Il pagamento necessario sarà ripreso nei flussi; il coupon resta un esempio di estensione facoltativa. Qui dichiari gli obiettivi e le loro dipendenze, mentre Activity e Sequence descriveranno l’ordine dei passi.

**Controllo L3:** salva. Nel Context distingui un sistema governato, due attori e due sistemi esterni. Nei casi d’uso riconosci i due obiettivi del Cliente e l’azione opzionale del coupon. Il checkpoint `tappe/01-confini` permette di confrontare il lavoro raggiunto.

### L4. Costruisci C4 Container e C4 Component

Dopo aver definito confine e obiettivi, suddividi Mercato in applicazioni, persistenza e messaggistica, poi dettaglia il servizio API. La vista Container rende leggibili le parti che comunicano; la vista Component distribuisce le responsabilità interne dell’API. Dichiarerai prima appartenenze e ruoli, così i due livelli mostreranno lo stesso sistema a diverse profondità.

#### Crea i container e scegli i ruoli mostrati dal form

Separa Web shop, API, archivio e broker per distinguere presentazione, regole applicative, dati conservati ed eventi. Il ruolo descrive che cosa svolge ciascuna parte; l’owner Mercato ne dichiara l’appartenenza al prodotto. Queste scelte preparano la vista Container: non installano né avviano i servizi.

Torna alla panoramica. Con **Add Element** crea **API Mercato**, **Archivio Mercato** e **Broker eventi** scegliendo **Application / Container** in **Element Type**. Web shop è già presente. API Mercato è il servizio che riceve le richieste del negozio.

Apri **Structural Blueprint > Structure > System Scope or Container Responsibility**. Scegli un container in **Configuration** e compila **Description** e **Container Role**. Passa al prossimo container dal selettore. Dopo aver compilato le quattro schede premi **Apply to Model**.

| Container | Responsibility | Container Role |
| --- | --- | --- |
| Web shop | Interfaccia web del negozio | Web Client |
| API Mercato | Conferma acquisti e gestisce resi | Service |
| Archivio Mercato | Conserva ordini e prodotti | Data Store |
| Broker eventi | Distribuisce eventi | Messaging |

Assegna **Mercato** come owner architetturale ai quattro container. Apri **Architectural or Lifecycle Owner**, scegli **Web shop** in **Configuration** e seleziona **Mercato** in **Architectural Owner**. Espandi **Assign the Same Owner to More Elements** e spunta **API Mercato**, **Archivio Mercato** e **Broker eventi**. Premi **Apply to Model**. Prima di creare la vista, controlla l’appartenenza dei quattro container.

#### Crea e apri la vista Container

Ora che i container hanno un owner, mostra le comunicazioni fra loro: il Context non le dettagliava. Conserva Mercato come confine e Cliente come punto d’ingresso, mentre le parti interne spiegano come la richiesta raggiunge servizio, dati ed eventi. È una vista dedicata del modello già creato, non una nuova copia delle applicazioni.

Torna a **C4 View Subject and Context** e premi **New C4 View**. Scegli **L2 · Containers**, soggetto Mercato e nome `03 C4 Applicazioni e dati`. Spunta **Context** per Cliente e **Visible** per Cliente e i quattro container. Mercato è già visibile. Premi **Apply to Model** e **Open Diagram**.

Cliente verso Web shop “naviga” è già una relazione condivisa: conservala. Crea Communication da Web shop ad API Mercato “invia ordini”, dall’API ad Archivio Mercato “legge e scrive” e dall’API a Broker eventi “pubblica eventi”, tutte con condizione vuota. Può apparire anche la comunicazione già dichiarata Cliente–Mercato del Context: è lo stesso modello, non un errore di importazione.

Dichiara il protocollo dopo aver definito gli estremi per esplicitare l’ipotesi di integrazione. Seleziona la freccia e premi **Edit Cardinalities and Protocol** nelle proprietà della relazione. Compila **Protocol / Transport**, lascia vuoti i campi delle molteplicità e dei membri e premi **Save Changes**. Usa i valori della tabella.

| Relazione | Protocol / Transport |
| --- | --- |
| Cliente verso Web shop | HTTPS |
| Web shop verso API Mercato | HTTPS / JSON |
| API Mercato verso Archivio Mercato | SQL |
| API Mercato verso Broker eventi | Messaggistica dichiarata |

Il nome spiega a cosa serve il collegamento; il protocollo come si prevede di comunicare. I primi quattro campi restano vuoti perché qui non stai descrivendo cardinalità o colonne di dati. HTTPS/JSON e SQL sono scelte progettate; “Messaggistica dichiarata” mantiene aperto il trasporto del broker. Queste etichette non dimostrano una connessione e non selezionano un prodotto da installare.

Per selezionare una freccia clicca il tratto o la sua etichetta. Controlla origine e destinazione nelle proprietà prima di modificare.

#### Costruisci prima i componenti, poi il contratto

Dettaglia ora API Mercato per separare chi coordina l’acquisto, registra gli esiti, tratta i resi e gestisce le scorte. Prima crea e assegna i componenti all’API, poi includili nella sua vista C4: l’owner definisce il confine che la vista deve rappresentare. Il contratto renderà riconoscibile l’accordo offerto da Checkout; firma e dati saranno precisati in L11.

Torna alla panoramica. Con **Add Element** crea **Registro esiti** e **Scorte** come **Component**. Checkout e Gestione resi esistono. In **Architectural or Lifecycle Owner** scegli **Checkout** in **Configuration**, poi **API Mercato** in **Architectural Owner**. Con **Assign the Same Owner to More Elements** spunta **Registro esiti**, **Gestione resi** e **Scorte**, poi premi **Apply to Model**. Scorte rappresenta la responsabilità applicativa per la disponibilità. Archivio Mercato rappresenta la persistenza.

In questo esercizio la vista mette a fuoco i quattro componenti interni dell’API. Da **C4 View Subject and Context** premi **New C4 View** e scegli **L3 · Components**, soggetto API Mercato, nome `04 C4 Componenti API`. Lascia vuota la colonna **Context**. Spunta **Visible** per Checkout, Registro esiti, Gestione resi e Scorte. API Mercato è già visibile. Premi **Apply to Model** e **Open Diagram**.

Usa un contratto per precisare in L11 l’accordo offerto da Checkout. Nella vista C4 premi **Add Element**, scrivi **Contratto acquisto**, scegli **Contract** in **Element Type** e premi **Create**. ADE lo colloca sotto API Mercato, soggetto della vista.

Aggiungi Checkout verso Registro esiti con **Communication**, nome “registra esito”; Checkout verso Contratto acquisto con **Implementation**, “espone contratto”; Checkout verso Scorte con **Dependency**, “richiede disponibilità”. Gestione resi verso Checkout “consulta acquisto” è già presente: riusala. La vista C4 propone i collegamenti architetturali compatibili; le invocazioni operative saranno mostrate nella sequenza di L7.

**Controllo L4:** salva e premi Fit Diagram. Ogni container ha Owner Mercato e un ruolo dichiarato; i quattro componenti appartengono all’API; Contratto acquisto è il contratto dell’API fornito da Checkout. Trascinare una scheda cambia il layout, mentre il form di ownership cambia la struttura dichiarata.
### L5. Crea entità, colonne e riferimenti con i form

Le viste C4 hanno assegnato responsabilità e persistenza; ora definisci i dati necessari all’acquisto e al reso. Parti dal significato dei dati e dai loro legami nell’ERD, poi progetta tabelle e chiavi nello schema fisico. Tenere distinti questi due livelli permette di discutere la regola “un reso riguarda un ordine esistente” prima di scegliere come conservarne il riferimento.

#### Crea l’ERD e le entità

Fissa prima le entità del dominio: cliente, ordine, riga, prodotto e reso devono avere attributi e collegamenti comprensibili anche senza decidere le tabelle. Questi dati serviranno a controllare le responsabilità già progettate: per esempio, il checkout deve conoscere quantità e prezzo della riga.

L’ERD (Entity–Relationship Diagram) rappresenta entità e relazioni fra i dati. Dal selettore dei diagrammi scegli **Add Diagram**. Nel form **Create Diagram** scrivi `05 Entità e cardinalità` in **Name**, scegli **Entity–Relationship** in **Diagram Type** e **Acquisto** in **Choose Feature**, poi premi **Create**. Con **Add Element** scegli **Entity** in **Element Type** e crea Cliente, Ordine, Riga ordine, Prodotto e Reso.

Usa Add Element: queste entità definiscono i dati del dominio. L’Actor Cliente descrive chi agisce e la Resource Ordine l’oggetto coinvolto; l’ERD ne dettaglia invece attributi e legami. Per mostrare la stessa entità in un altro diagramma dati userai Add Existing Element.

#### Compila un attributo dall’inizio alla fine

Aggiungi gli attributi per precisare le informazioni di ogni entità. `customerId` è un identificativo testuale del cliente. In questo diagramma usa **No Key**. Dichiarerai le chiavi fisiche nello schema.

1. Seleziona la scheda **Cliente** e premi **Edit Attributes and Technology** in **Properties**.
2. Premi **Add Attribute** nella sezione **Attributes and Methods**.
3. Compila **Member Name** con `customerId` e **Type or Method Signature** con `string`. Lascia **Attribute / Column**, **No Key** e **Required Field** ai valori iniziali. Scegli **Non-null Value** in **Nullability (Independent of Presence)**.
4. Premi di nuovo **Add Attribute** per aggiungere `email` e compilalo come indicato nella tabella. Premi **Save Changes** per applicare entrambi gli attributi.

La scheda mostra `customerId: string` e `email: string`. Per correggere un membro riapri **Edit Attributes and Technology**, modifica la riga esistente e premi **Save Changes**.

In questa lezione il campo del tipo è una dichiarazione descrittiva: scrivi letteralmente **string** per il testo e **integer** per gli interi. Il form non richiede di creare prima Shared Types. I tipi condivisi dei contratti saranno costruiti in L11.

Gli identificativi permettono di riferirsi agli oggetti. Quantità e importi descrivono il contenuto economico. Per ogni entità aggiungi in un unico form i membri della tabella con **Attribute / Column**, **No Key**, **Required Field** e **Non-null Value**.

| Entità | Membri da aggiungere con nome e tipo |
| --- | --- |
| Cliente | customerId: string; email: string |
| Ordine | orderId: string; totalCents: integer |
| Riga ordine | quantity: integer; unitPriceCents: integer |
| Prodotto | sku: string; priceCents: integer |
| Reso | returnId: string; reason: string |

Required richiede che il campo sia presente; Non-null Value vieta che il suo valore sia null. Qui servono entrambi: un ordine senza totale, o con totale null, non fornisce l’importo da usare.

#### Disegna e completa le cardinalità

Dopo aver definito gli oggetti e i loro attributi, precisa quante istanze possono essere collegate: il solo nome “contiene” non dice se un ordine può essere vuoto. Le cardinalità rendono esplicite queste regole prima di tradurle in riferimenti fisici. I campi delle colonne restano vuoti perché stai ancora collegando entità, non chiavi di tabelle.

Crea le quattro relazioni **Association** con la procedura di L2 e **Condition (Optional)** vuoto. Seleziona ogni relazione e apri **Edit Cardinalities and Protocol**. Compila **Source Multiplicity** e **Target Multiplicity** come in tabella. Lascia vuoti i campi dei membri e del protocollo e premi **Save Changes**.

| Origine | Destinazione | Relationship Name | Source Multiplicity | Target Multiplicity |
| --- | --- | --- | --- | --- |
| Cliente | Ordine | effettua | `1` | `0..*` |
| Ordine | Riga ordine | contiene | `1` | `1..*` |
| Riga ordine | Prodotto | riguarda | `0..*` | `1` |
| Reso | Ordine | si riferisce a | `0..*` | `1` |

Cliente `1` verso Ordine `0..*` ammette un cliente senza acquisti, ma assegna ogni ordine a un cliente. Ordine verso Riga ordine `1..*` richiede invece almeno una riga: un ordine vuoto non è valido. Leggi entrambe le direzioni; le cardinalità dichiarano regole, non contano record presenti.

#### Crea lo schema fisico

Passa ora dal significato dei dati alla loro conservazione prevista. Crea Table distinte dalle Entity: una tabella ha colonne, chiavi e riferimenti fisici, e non coincide automaticamente con la definizione di dominio. Lo schema è un esercizio di progettazione; non crea il database e non costituisce da solo tutti i vincoli necessari a implementare le regole dell’ERD.

Con **Add Diagram** crea `06 Schema dati progettato`, scegliendo **Database Schema** in **Diagram Type** e **Acquisto** in **Choose Feature**. Crea le cinque **Table** elencate sotto. Per ogni tabella apri **Edit Attributes and Technology** e usa **Add Attribute** per aggiungere tutte le colonne prima di premere **Save Changes**. Imposta **Key Kind** come in tabella, mantieni **Required Field** e scegli **Non-null Value**.

| Tabella | Colonne: nome, tipo e Key Kind |
| --- | --- |
| customers | id, string, Primary Key; email, string, Unique Key |
| orders | id, string, Primary Key; customer_id, string, Foreign Key; total_cents, integer, No Key |
| order_lines | id, string, Primary Key; order_id, string, Foreign Key; product_id, string, Foreign Key; quantity, integer, No Key |
| products | id, string, Primary Key; sku, string, Unique Key; price_cents, integer, No Key |
| returns | id, string, Primary Key; order_id, string, Foreign Key; reason, string, No Key |

In questo schema la chiave primaria identifica ogni riga, le chiavi univoche distinguono email e sku e le chiavi esterne collegano le righe conservate. Per ogni chiave esterna specifica anche la colonna di destinazione. Crea una **Association** da **orders** a **customers**, nome `customer_id`, condizione vuota. Seleziona la relazione, apri **Edit Cardinalities and Protocol**, usa i valori della tabella e premi **Save Changes**.

| Campo del form | Valore |
| --- | --- |
| Source Multiplicity | `0..*` |
| Target Multiplicity | `1` |
| Source Attribute / Column | `customer_id` |
| Target Attribute / Column | `id` |
| Protocol / Transport | Vuoto |

I nomi dei membri si **scrivono** nel campo: non includere `orders.` o `customers.`. Il riferimento è già associato alle due tabelle della relazione. Se il membro non esiste, correggi il nome o crea prima la colonna: non usare un nome inventato per superare la validazione.

Completa poi i riferimenti che ricollegano righe d’ordine e resi ai dati già esistenti: la riga deve individuare ordine e prodotto, il reso il proprio ordine. Ripeti con queste tre relazioni, sempre Source Multiplicity `0..*`, Target Multiplicity `1`, Target Attribute / Column `id` e protocollo vuoto:

| Origine | Destinazione | Relationship Name e Source Attribute / Column |
| --- | --- | --- |
| order_lines | orders | order_id |
| order_lines | products | product_id |
| returns | orders | order_id |

Il ruolo Foreign Key (FK, chiave esterna) identifica la colonna di riferimento; la relazione dice quale dato deve esistere all’altro estremo. Insieme esprimono, per esempio, che un reso deve riferirsi a un ordine esistente. Il solo testo FK non ne indica la destinazione.

**Controllo L5:** salva e riapri. L’ERD contiene cinque entità, dieci attributi e quattro associazioni; lo schema cinque tabelle, quindici colonne e quattro riferimenti. Confronta il checkpoint `tappe/02-architettura-dati`. Non hai creato un database o eseguito SQL. I mapping fra tipi di dominio e colonne richiedono i tipi condivisi di L11: affrontali dopo averli creati.

### L6. Costruisci Class, UML Component e Package

Dopo aver definito i dati, descrivi i tipi del software e le loro collaborazioni con UML (Unified Modeling Language). La vista Class descrive tipi e operazioni; UML Component mostra chi offre i contratti; Package rende esplicita la direzione delle dipendenze fra gruppi logici. Sono scelte sull’organizzazione del codice da realizzare, da confrontare con architettura e dati già progettati.

#### Class descrive tipi e metodi

Definisci Order come tipo con attributi e operazione di conferma, CheckoutService come servizio e OrderRepository come accordo per la persistenza. La Resource Ordine indica il dato coinvolto nelle responsabilità e l’Entity Ordine ne descrive il dominio: creare una Class distinta permette di discutere i metodi senza attribuirli automaticamente a tutte le rappresentazioni omonime.

Con **Add Diagram** crea `11 Classi e repository`, scegliendo **Class** in **Diagram Type** e **Acquisto** in **Choose Feature**. Con **Add Element** crea **Order** e **CheckoutService** di tipo **Class** e **OrderRepository** di tipo **Interface Contract**.

Seleziona **Order** e apri **Edit Attributes and Technology**. Con **Add Attribute** aggiungi `orderId: string` e `totalCents: integer` come in L5, con **No Key**, **Required Field** e **Non-null Value**.

Nello stesso form premi **Add Method**. Scrivi `confirm` in **Member Name** e `string` in **Type or Method Signature**. Mantieni **Required Field** e scegli **Non-null Value**. Per un metodo **Key Kind** è disabilitato. Premi **Save Changes**. La scheda mostra `confirm(): string`.

Ripeti per il metodo `submit` di CheckoutService e `save` di OrderRepository, sempre con risultato descrittivo string: i nomi distinguono invio al servizio e conservazione tramite contratto. Queste firme sono volutamente minime e non definiscono l’intero checkout. In L11 userai input e risultati tipizzati per un contratto più completo.

Crea due Dependency con condizione vuota: CheckoutService verso Order, nome “valida e conferma”; CheckoutService verso OrderRepository, nome “usa contratto”. I membri descrivono i tipi: non sono implementazioni già scritte.

#### UML Component riusa i contratti esistenti

Collega ora l’accordo OrderRepository al componente che lo fornisce e rileggi il Contratto acquisto già esposto da Checkout. Riusa interfacce, componenti e relazioni per conservare un solo significato nelle viste Class, C4 e UML Component: una modifica al contratto deve restare riconoscibile nei punti che lo usano. Qui specifichi le collaborazioni, non replichi le classi.

Con **Add Diagram** crea `13 Componenti e interfacce`, scegliendo **UML Component** in **Diagram Type** e **Acquisto** in **Choose Feature**. Con **Add Existing Element** sul canvas aggiungi Checkout, Contratto acquisto, Registro esiti e OrderRepository. Controlla il tipo della riga, in particolare Component Checkout e Interface Contract OrderRepository.

Gli elementi da soli non portano con sé tutte le frecce. Apri **Diagram > Contents > Add Existing Relationship** e scegli **Checkout → Contratto acquisto: espone contratto**. Ripeti per **Checkout → Registro esiti: registra esito**. Ora crea la nuova Implementation da Registro esiti verso OrderRepository, nome “fornisce persistenza”, condizione vuota. Devi vedere tre collegamenti. Il riuso conserva identità e dettagli della relazione: Connect ne creerebbe una nuova.

![Contents distingue il riuso degli elementi dal riuso delle relazioni](immagini/32-riuso-relazione.png)

#### Package mostra i layer logici

Raggruppa le responsabilità in Dominio, Applicazione e Adapter per discutere dove devono andare le dipendenze prima di organizzare i sorgenti. Il dominio contiene le regole da preservare, l’applicazione coordina gli obiettivi, gli adapter collegano i dettagli esterni. Crea quindi nuove identità Package: i gruppi logici non sono copie dei componenti né cartelle già create.

Con **Add Diagram** crea `14 Moduli applicativi`, scegliendo **Package** in **Diagram Type** e **Acquisto** in **Choose Feature**. Crea tre elementi **Package** chiamati Dominio, Applicazione e Adapter. Aggiungi tre relazioni **Dependency** con condizione vuota. Collega Applicazione a Dominio con “usa regole”, Adapter a Dominio con “implementa contratti” e Adapter ad Applicazione con “collega esterni”. In fase di implementazione potrai confrontare la direzione delle dipendenze del codice con quella dichiarata qui.

**Controllo L6:** salva. OrderRepository è la stessa interfaccia nelle viste Class e UML Component; la sua modifica deve essere visibile in entrambe. Nel Package il dominio non dipende dagli adapter. Classe, componente e package rispondono a domande diverse e rimangono identità distinte.
### L7. Costruisci flusso, sequenza e stati dell’acquisto

Responsabilità e dati sono definiti; ora descrivi ciò che accade durante l’acquisto. Parti da Activity per distinguere passi e alternative, passa a Sequence per assegnare le chiamate ai partecipanti, poi a State per descrivere l’Ordine dopo l’esito. È un ordine di lettura consigliato per confrontare tre domande diverse; ADE non richiede di creare queste viste in questa sequenza.

#### Activity: azioni e alternative

Riusa il Flow creato con la feature per descrivere il percorso dall’avvio all’esito, senza aggiungere una seconda vista per lo stesso esercizio. Valida il carrello prima del pagamento e separa l’indisponibilità delle scorte dal pagamento rifiutato: entrambi portano al rifiuto, ma per ragioni diverse che la struttura non mostrava.

Apri dal selettore **Acquisto · Flow**, la vista creata con la feature. Apri **Diagram** e premi **Rename** accanto al titolo. Usa il nome `08 Flusso acquisto`.

Per ogni oggetto premi **Add Element**, inserisci il nome, scegli il tipo in **Element Type** e premi **Create**.

| Tipo | Nomi da creare |
| --- | --- |
| Start | Inizio |
| Action | Valida carrello; Richiedi pagamento; Conferma ordine; Rifiuta ordine |
| Decision | Scorte disponibili? |
| End | Fine |

Collega i nodi con **Control Flow** per dichiarare passi e alternative. Nel form **Create Relationship** usa **Relationship Name** per nominare il passaggio e **Condition (Optional)** per indicare quando avviene. Premi **Save Changes** al termine di ogni relazione.

| Origine | Destinazione | Relationship Name | Condition |
| --- | --- | --- | --- |
| Inizio | Valida carrello | avvia | Vuota |
| Valida carrello | Scorte disponibili? | controlla | Vuota |
| Scorte disponibili? | Richiedi pagamento | prosegui | disponibili |
| Scorte disponibili? | Rifiuta ordine | rifiuta | non disponibili |
| Richiedi pagamento | Conferma ordine | conferma | pagamento autorizzato |
| Richiedi pagamento | Rifiuta ordine | rifiuta | pagamento rifiutato |
| Conferma ordine | Fine | termina | Vuota |
| Rifiuta ordine | Fine | termina | Vuota |

Premi Fit Diagram e segui i due esiti. Le condizioni sono descrittive; questa lezione non contatta un servizio di pagamento.

#### Sequence: partecipanti e messaggi sono due selezioni diverse

Dopo aver distinto i percorsi, assegna le chiamate alle responsabilità di L2. Riusa Actor Cliente, Component Checkout, Software System Pagamenti esterni e Resource Ordine: sono gli oggetti che richiedono, coordinano, autorizzano e ricevono la registrazione. Entity e Class omonime descrivono altri livelli e non vanno scelte per sostituirli. Includere i messaggi separatamente permette di dichiararne l’ordine in questa vista senza duplicare le relazioni del sistema.

Con **Add Diagram** crea `07 Sequenza acquisto`, scegliendo **Sequence Diagram** in **Diagram Type** e **Acquisto** in **Choose Feature**. Con **Add Existing Element** sul canvas aggiungi, nell’ordine, Cliente di tipo Actor, Checkout di tipo Component, Pagamenti esterni di tipo Software System e Ordine di tipo Resource.

Nell’elenco possono comparire anche l’Entity Cliente e l’Entity Ordine create in L5. Leggi il tipo della riga prima di confermare. La sequenza può mostrare inizialmente **No messages**: aggiungere partecipanti non include automaticamente le relazioni già dichiarate.

1. Seleziona **Cliente** e premi **Connect**. Se compare **Relationship Type**, scegli **Invocation**. Clicca **Checkout** tra le destinazioni evidenziate. Scrivi `conferma acquisto`, lascia vuoto **Condition (Optional)** e premi **Save Changes**. Questo è il primo messaggio.
2. Apri **Diagram > Contents > Add Existing Message**. Scegli **Checkout → Pagamenti esterni: autorizza pagamento**, di tipo Invocation. Non creare di nuovo quella relazione con Connect.
3. Ripeti Add Existing Message e scegli **Checkout → Ordine: registra ordine**, di tipo Write. La condizione pagamento autorizzato viene conservata.

Il risultato atteso è: 1 Cliente–Checkout, 2 Checkout–Pagamenti esterni, 3 Checkout–Ordine. L’autorizzazione deve precedere la registrazione condizionata dell’ordine: invertire i messaggi cambierebbe il comportamento progettato. I partecipanti conservano le identità condivise; spostare le schede non riordina le chiamate.

#### State: associa la risorsa del ciclo di vita

Descrivi infine quale condizione conserva l’Ordine dopo il tentativo di pagamento: In attesa, Confermato o Rifiutato. Gli stati descrivono la Resource **Ordine** già usata dalla struttura e dalla sequenza.

Apri **Add Diagram** e scrivi `09 Stati ordine` in **Name**. Seleziona **State Diagram** in **Diagram Type**, **Acquisto** in **Choose Feature** e **Ordine** in **Resource Whose State Is Represented**. Premi **Create**.

Il canvas include la risorsa Ordine e il pulsante **Add State**. Usalo per creare **In attesa**, **Confermato** e **Rifiutato**. Mantieni Ordine come risorsa per ogni stato e premi **Create**.

Seleziona **In attesa** e premi **Connect**. La vista usa **Transition** e mette in evidenza gli stati raggiungibili. Clicca **Confermato**. Usa `Pagamento autorizzato` in **Relationship Name** ed `esito positivo` in **Condition (Optional)**, poi premi **Save Changes**. Ripeti da In attesa verso Rifiutato con nome `Pagamento rifiutato` e condizione `esito negativo`.

**Controllo L7:** salva. Activity contiene sette nodi e otto Control Flow; Sequence quattro partecipanti e tre messaggi nell’ordine indicato; State una risorsa e tre stati con due transizioni. Sono descrizioni: le interazioni e i lifecycle eseguibili saranno affrontati nei moduli di L13-L14.

### L8. Costruisci le viste Resi e verifica il riuso

Il reso legge un acquisto già registrato e crea una richiesta distinta. Dopo aver descritto l’acquisto, riusi Cliente e Ordine nella seconda feature e aggiungi il coordinamento del reso: puoi così controllare che entrambe le capacità facciano riferimento agli stessi dati e che ammissione e rimborso restino riconoscibili.

#### Riusa la struttura automatica della feature

La vista automatica della feature offre già lo spazio in cui separare responsabilità nuove e condivise. Apri **Resi e rimborsi · Structure** e usa **Diagram > Rename** accanto al titolo per chiamarla `Resi - responsabilità condivise`. Aggiungi con **Add Existing Element** Cliente di tipo Actor e Ordine di tipo Resource. Per ciascun elemento della tabella premi **Add Element**, compila **Name**, scegli **Element Type** e premi **Create**.

| Name | Element Type |
| --- | --- |
| Pagina resi | Interface |
| Coordinamento reso | Controller |
| Richiesta di reso | Resource |

Interface qui rappresenta una pagina/interfaccia del negozio; Interface Contract è il tipo di contratto usato in L6. Il Component Gestione resi di C4 è la responsabilità applicativa; il Controller Coordinamento reso ne descrive il coordinamento di dettaglio.

Apri **Structural Blueprint > Structure > Architectural or Lifecycle Owner**. Scegli **Coordinamento reso** in **Configuration**, seleziona **API Mercato** in **Architectural Owner** e premi **Apply to Model**. Nel laboratorio controller e Gestione resi appartengono allo stesso container. Il primo dettaglia il coordinamento del reso.

Collega richiesta, coordinamento, lettura e registrazione per distinguere il dato consultato da quello nuovo. In questa struttura lascia Condition vuota; esprimerai le alternative temporali nel flusso immediatamente successivo. Crea queste quattro relazioni:

| Origine | Tipo | Destinazione | Nome |
| --- | --- | --- | --- |
| Cliente | Invocation | Pagina resi | chiede reso |
| Pagina resi | Invocation | Coordinamento reso | invia richiesta |
| Coordinamento reso | Read | Ordine | verifica acquisto |
| Coordinamento reso | Write | Richiesta di reso | registra reso |

Ordine viene letto, Richiesta di reso viene registrata. L’Ordine originale rimane condiviso con Acquisto.

#### Completa il flusso del rimborso

Ora che sai chi gestisce il reso e quali dati usa, il flusso rende esplicita la scelta fra rimborso e rifiuto. Apri **Resi e rimborsi · Flow**, rinominala `Resi - ammissione e rimborso` con **Diagram > Rename** e crea **Valuta reso**, **Emetti rimborso** e **Rifiuta richiesta** con **Action** in **Element Type**. Collega Valuta reso a Emetti rimborso con **Control Flow**, nome `autorizza` e condizione `entro 30 giorni`. Collega Valuta reso a Rifiuta richiesta con **Control Flow**, nome `rifiuta` e condizione `termine superato`.

#### Controlla impatto e identità

Ordine compare ora in due feature. Torna alla struttura Resi, seleziona **Ordine** e premi **Show Change Impact** nel gruppo **Explore** delle proprietà. Consulta i riferimenti e le viste interessate, poi premi la freccia **Back** nella navigazione del progetto. Seleziona di nuovo Ordine se le proprietà sono chiuse. Premi **Rename** accanto al titolo delle proprietà, scrivi `Ordine cliente` e premi **Save Changes**. Apri la panoramica di Acquisto e controlla il nuovo nome sulla stessa risorsa. Premi **Undo** sul canvas per ripristinare il nome e **Save** se ci sono modifiche pendenti.

**Controllo L8:** ritrovi il nome Ordine ripristinato in entrambe le viste. Non è stato creato un Ordine resi separato. La richiesta di reso è una nuova risorsa; il controller è un dettaglio della responsabilità Gestione resi. Il flusso contiene due alternative con condizioni esplicite.
### L9. Progetta collocazione e connessioni

Le responsabilità applicative sono definite: puoi riusarle per progettare dove collocare software e dati e quali connessioni prevedere. Deployment descrive la collocazione; Network i confini e i protocolli. Affrontale dopo l’architettura per riferirti alle stesse applicazioni, senza confondere ownership e infrastruttura.

#### Deployment: dove sono collocate le parti

Associa le parti già progettate a host e pacchetti distribuibili. Con **Add Diagram** crea `10 Distribuzione locale progettata`, scegliendo **Deployment** in **Diagram Type** e **Acquisto** in **Choose Feature**.

Con **Add Element** crea **Host Web**, **Host API** e **Host dati** di tipo **Deployment Node**, poi **Web bundle** e **API ESM** di tipo **Artifact**. ESM indica il formato dei moduli JavaScript scelto per l’esempio. Dal canvas usa **Add Existing Element** per includere **API Mercato** e **Archivio Mercato**. Così Deployment e C4 fanno riferimento agli stessi container.

Le relazioni **Hosts** dichiarano quale host ospiterà ciascuna parte. Non richiedono qui una condizione di business: rappresentano la collocazione prevista per l’esempio. Crea le quattro relazioni con condizione vuota:

| Origine ospitante | Destinazione ospitata | Nome |
| --- | --- | --- |
| Host Web | Web bundle | ospita |
| Host API | API ESM | ospita |
| Host API | API Mercato | ospita |
| Host dati | Archivio Mercato | ospita |

Per ogni host seleziona la scheda e premi **Edit Attributes and Technology** in **Properties**. Nel form scrivi `Processo locale progettato` in **Technology** e `Didattico locale` in **Environment**, poi premi **Save Changes**. I due campi descrivono la collocazione prevista per l’esempio.

#### Network: quali collegamenti sono dichiarati

Usa Network per descrivere le comunicazioni fra client, API e archivio. Con **Add Diagram** crea `16 Connessioni progettate`, scegliendo **Network / Infrastructure** in **Diagram Type** e **Acquisto** in **Choose Feature**. Con **Add Element** crea **Rete client** e **Rete backend** di tipo **Network Node**. Con **Add Existing Element** includi **Web shop**, **API Mercato** e **Archivio Mercato**.

Crea le tre relazioni **Communication** con condizione vuota. Per ognuna apri **Edit Cardinalities and Protocol**, compila **Protocol / Transport** come in tabella e premi **Save Changes**. Lascia vuoti molteplicità e membri. I protocolli distinguono accesso web, chiamata API e persistenza.

| Origine | Destinazione | Nome | Protocol / Transport |
| --- | --- | --- | --- |
| Rete client | Web shop | accesso web | HTTPS 443 |
| Rete client | Rete backend | confine applicativo | HTTPS 443 |
| Rete backend | API Mercato | API | HTTPS / JSON |

Il quarto collegamento esiste già: **Diagram > Contents > Add Existing Relationship > API Mercato → Archivio Mercato: legge e scrive**. Il protocollo SQL viene riusato con la relazione. Non ricrearlo con Connect. Devi vedere quattro relazioni nella Network. Il riuso mantiene un’unica dichiarazione della comunicazione API–archivio anche se la mostri da una prospettiva diversa.

Nel Deployment controlla il raggruppamento. Se serve più spazio, prova **Diagram > Arrange > Balanced** e **Fit Diagram**. Se due gruppi si sovrappongono ancora, trascina **API ESM** accanto ad **API Mercato** e separali da **Archivio Mercato** e **Web bundle**. L’appartenenza di ogni oggetto è dichiarata dalla relazione **Hosts**.

Salva e premi Fit Diagram. Il Deployment risponde a “dove sono collocate le parti”; la Network a “quali collegamenti sono previsti”. Le frecce non avviano processi, non aprono porte e non dimostrano una connessione reale.

### L10. Segui i dati e controlla tutte le notazioni

Dopo responsabilità e comportamenti, segui i dati necessari all’acquisto: il Cliente invia la richiesta, il catalogo fornisce prezzi e disponibilità, il processo conserva l’ordine e restituisce l’esito. Poi controlli insieme le viste create finora, prima di formalizzare il contratto in L11.

La vista Data Flow mostra quali dati entrano nel processo e quali ne escono. Con **Add Diagram** crea `15 Dati dell’acquisto`, scegliendo **Data Flow** in **Diagram Type** e **Acquisto** in **Choose Feature**.

Includi l’**Actor Cliente** con **Add Existing Element**. Con **Add Element** crea **Elabora ordine** di tipo **Process**, poi **Dati ordini** e **Dati catalogo** di tipo **Data Store**. Processo e depositi rappresentano il trattamento e la conservazione dei dati in questa vista.

Nomina i collegamenti con il dato trasferito, così puoi controllare che Elabora ordine riceva ciò che gli serve e produca sia un dato conservato sia un esito per il Cliente. Crea quattro relazioni **Data Flow**, con Condition vuota:

| Origine | Destinazione | Nome del dato trasferito |
| --- | --- | --- |
| Cliente | Elabora ordine | dati acquisto |
| Dati catalogo | Elabora ordine | prezzi e disponibilità |
| Elabora ordine | Dati ordini | ordine confermato |
| Elabora ordine | Cliente | esito acquisto |

Usa **Diagram > Arrange > Balanced**, premi **Fit Diagram** e salva. I nomi delle frecce indicano quali dati passano da un elemento all’altro.

Le due viste automatiche di Catalogo prodotti sono ancora vuote. Per ottenere le 18 viste del riferimento apri ciascuna e usa **Diagram > Manage Diagram > Delete Diagram**. Controlla il nome nella conferma e premi **Delete**. L’azione rimuove la vista. Con **Undo** puoi recuperare una cancellazione appena effettuata.

Per riportare la panoramica alle sei responsabilità di L2, seleziona una alla volta le otto schede di dettaglio: Mercato, Corriere esterno, Assistenza, API Mercato, Archivio Mercato, Broker eventi, Registro esiti e Scorte. Per ciascuna premi **Remove from This Diagram** nella scheda **Properties**. Il riquadro si chiude dopo l’esclusione e l’elemento resta disponibile nelle altre viste che lo usano. Disponi le schede rimaste e premi **Fit Diagram**.

Salva e riapri la tua root per controllare anche la persistenza del lavoro. Usa la tabella per trovare eventuali prospettive mancanti prima di aggiungere i contratti; i numeri indicano la prospettiva, non l’ordine in cui l’hai creata.

| Notazione | Vista del riferimento | Lezione |
| --- | --- | --- |
| Structure | 01 Panoramica delle responsabilità | L2 |
| C4 System Context | 02 C4 Contesto Mercato | L3 |
| C4 Container | 03 C4 Applicazioni e dati | L4 |
| C4 Component | 04 C4 Componenti API | L4 |
| ERD | 05 Entità e cardinalità | L5 |
| Database Schema | 06 Schema dati progettato | L5 |
| Sequence | 07 Sequenza acquisto | L7 |
| Activity / Flowchart | 08 Flusso acquisto | L7 |
| State Machine | 09 Stati ordine | L7 |
| Deployment | 10 Distribuzione locale progettata | L9 |
| Class | 11 Classi e repository | L6 |
| Use Case | 12 Casi d’uso | L3 |
| UML Component | 13 Componenti e interfacce | L6 |
| Package | 14 Moduli applicativi | L6 |
| Data Flow | 15 Dati dell’acquisto | L10 |
| Network / Infrastructure | 16 Connessioni progettate | L9 |

Le 16 viste in tabella e le due viste Resi formano **18 viste di 16 tipi**. Apri ciascuna dal selettore, controlla gli elementi e almeno una relazione pertinente. Se hai conservato le due viste automatiche vuote del Catalogo, le vedrai in aggiunta.

**Controllo di coerenza:** Cliente e Ordine sono riusati nelle prospettive compatibili; entità, tabelle e classi restano distinte; tutte le relazioni hanno estremi pertinenti; le condizioni descrivono esiti comprensibili; le ownership corrispondono ai confini; la lettura testuale riporta i dettagli. Non occorre raggiungere una disposizione identica agli screenshot per aver progettato correttamente.


### L11. Formalizza tipi, contratto e decisione

Le viste mostrano chi collabora al checkout; ora definisci l’accordo fra chi lo chiama e chi lo realizza. Tipi, firma, risultati ed errori rendono precisi i dati scambiati; provider e mapping collegano l’accordo all’architettura e alla persistenza. Registra infine la scelta sui centesimi perché le implementazioni future possano rispettarla.

#### Crea prima i tipi, nell’ordine delle dipendenze

I tipi condivisi danno agli input e ai risultati una definizione comune. Apri **Structural Blueprint > Data and Operations > Shared Types**. Per ogni riga, nell’ordine della tabella, premi **New Shared Type**, compila **Type Name** e **Type Kind** e completa i campi del tipo. Le configurazioni valide in bozza sono disponibili mentre prepari le successive. Quando hai completato i sette tipi, premi **Apply to Model**.

| Type Name | Type Kind | Dato successivo |
| --- | --- | --- |
| Testo | Primitive | Nel campo **Primitive Defined by the Profile** scrivi `string` |
| Intero | Primitive | Nello stesso campo scrivi `integer` |
| Riga ordine | Record | Aggiungi `productId` e `quantity` come indicato nella seconda tabella |
| Righe ordine | Collection | In **Item Type** scegli **Riga ordine** |
| Dati ordine | Record | Aggiungi `orderId` e `rows` come indicato nella seconda tabella |
| Esito acquisto | Enumeration | In **Enumeration Values** scrivi `confirmed` nella prima riga. Premi **Add Value** e scrivi `declined` nella seconda |
| Errore input | Record | Lascia vuota la sezione **Fields**. L’operazione dichiarerà il codice dell’errore |

Nella scheda di ciascun record premi **Add Field** per ogni campo della tabella. Compila **Name** e **Type**, mantieni **Required** selezionato e **Non-null Value** in **Nullability**. La presenza rende obbligatorio il campo, la nullabilità riguarda il suo valore.

| Record | Nome campo | Tipo da scegliere |
| --- | --- | --- |
| Riga ordine | productId | Testo |
| Riga ordine | quantity | Intero |
| Dati ordine | orderId | Testo |
| Dati ordine | rows | Righe ordine |

Completa prima **Riga ordine**, poi la collezione **Righe ordine** e infine il campo `rows`. La presenza del campo consente anche una collezione vuota. Includi “almeno una riga” fra le precondizioni del contratto.

#### Crea l’operazione sul contratto corretto

Ora i tipi possono essere usati dalla firma. Assegna submitCheckout al Contratto acquisto per esporre un accordo condiviso; Checkout ne sarà il fornitore. Input, risultato ed errore dichiarano rispettivamente che cosa inviare, che cosa attendere e come riconoscere un input non valido.

1. Apri **Data and Operations > Shared Operations** e premi **New Shared Operation**.
2. Nella scheda **Signature** scrivi `submitCheckout` in **Operation Name** e scegli **Contratto acquisto** in **Operation Owner**.
3. Premi **Add Input**. Usa il nome `ordine` e il tipo **Dati ordine**, lasciando **Required** e **Non-null Value**.
4. Premi **Add Result**. Usa il nome `esito` e il tipo **Esito acquisto**, lasciando **Required** e **Non-null Value**.
5. Premi **Add Error**. Scrivi `INPUT_INVALID` in **Error Code**, `Ordine assente o non valido` in **Description** e scegli **Errore input** in **Declared Type**.

![La scheda Signature mostra l’operazione submitCheckout, il contratto proprietario, l’input e il risultato](immagini/06-operazione.png)

Completa le regole nella stessa configurazione. La precondizione distingue un ordine compilato da una collezione vuota. Il criterio sulle scorte fissa una richiesta da verificare quando implementerai l’operazione.

| Percorso dall’operazione | Valore |
| --- | --- |
| Behavior Rules > Add Precondition | L’ordine contiene almeno una riga |
| Behavior Rules > Add Postcondition | L’esito viene registrato |
| Access and Acceptance > Add Criterion | **Given** Scorte disponibili. **When** Il cliente conferma. **Then** Le scorte sono riservate una sola volta |

Controlla firma, regole e criterio nel **Review** e premi **Apply to Model**. In L12 userai un predicato per formalizzare una regola eseguibile.

#### Esponi il contratto e dichiara chi lo fornisce

Includi l’operazione nell’interfaccia offerta ai chiamanti. Apri **Data and Operations > Interfaces and Invariants** e premi **Add Contract Definition**. Scegli **Contratto acquisto** in **Contract or Interface Element**, scrivi `1` in **Contract Version** e spunta **submitCheckout** in **Declared Operations**. Lascia vuoti i **Descriptive Invariants** e premi **Apply to Model**. Se l’operazione non compare, controlla che abbia **Contratto acquisto** come owner.

Dichiara che Checkout fornisce il contratto. Apri **Connections > Provided or Required Interface** e premi **Add Interface to Element**. Scegli **Checkout** in **Element**, **Contratto acquisto** in **Declared Contract or Interface** e **Provided** in **Direction**, poi premi **Apply to Model**. L’assegnazione permette ai controlli di riconoscere il provider oltre alla freccia Implementation.

Le interfacce richieste, le connessioni consumer/provider e i trasporti si configurano nello stesso gruppo Connections quando il progetto ne ha bisogno. Non aggiungerli a caso per eliminare una diagnostica: un servizio di pagamento reale richiederebbe contratti e policy che questo esempio non fornisce.

#### Mappa il campo e collega il Catalogo

Collega il campo condiviso `orderId` alla colonna in cui si conserva. Apri **Technology > Domain Field Mapping** e premi **Add Field Mapping**. Scegli **Dati ordine · orderId** in **Domain Field** e **orders · id** in **Physical Column or Class Attribute**. Premi **Apply to Model**.

Apri **Structure > Feature Memberships** e scegli **Scorte** in **Configuration**. Spunta **Catalogo prodotti**, conserva **Acquisto** e premi **Apply to Model**. Le due appartenenze rendono visibile il ruolo delle scorte in entrambe le capacità. API Mercato è l’owner architetturale.

#### Registra una decisione verificabile

Una decisione architetturale (ADR, Architectural Decision Record) conserva una scelta e le sue ragioni. Registra perché gli importi usano centesimi: chi cambierà tipi o codice potrà valutarne le conseguenze invece di dedurle dai nomi dei campi. Lo fai dopo tipi e contratto per collegare la motivazione alle responsabilità già identificate, prima che una successiva implementazione introduca rappresentazioni monetarie diverse.

Apri **Decisions > Project Architecture Decisions** e premi **New Architecture Decision**. Compila i campi nella scheda **Record**.

| Campo | Valore dell’esercizio |
| --- | --- |
| Decision Number | ADR-001 |
| Decision Title | Importi in centesimi |
| Context | Prezzi e totali devono essere confrontabili senza arrotondamenti impliciti |
| Decision | Usare interi in centesimi per prezzi e totali |
| Decision Status | Proposed |
| Consequences | Premi **Add Consequence** per inserire “Mostrare la valuta soltanto al confine della UI”. Premi di nuovo **Add Consequence** e inserisci “Validare gli importi nel dominio” |
| Applicable Scope | Spunta soltanto **Checkout** e **Registro esiti** per collegare la decisione alla conferma e alla registrazione dell’esito |

Premi **Apply to Model**. Per rileggere la decisione scegli **ADR-001 · Importi in centesimi** in **Configuration**. La scheda **Record** contiene motivazione, stato e ambito. **Constraints** raccoglie i vincoli strutturati. Per il laboratorio conserva lo stato **Proposed**.

Prima di passare alla regola eseguibile, controlla che le definizioni condivise siano salvate e utilizzabili: riferimenti mancanti renderebbero ambiguo il contratto che hai appena costruito. Salva e riapri Mercato. Non devono comparire Draft Needs Correction o tipi mancanti. Se una bozza impedisce il canvas, puoi selezionare l’elemento con Search System e correggerne l’ownership dal blueprint; non serve intervenire sul JSON.

**Controllo L11:** ritrovi sette tipi, l’operazione con input/risultato/errore, il contratto versione 1, Checkout come provider, il mapping e ADR-001. Il riferimento finale contiene questi dati. Le diagnostiche di generazione che dipendono da adapter, implementazioni o scelte non fornite non trasformano questa progettazione descrittiva in un negozio eseguibile.

### L12. Implementa e verifica il limite della quantità

L’obiettivo finale è accettare solo quantità intere da 1 a 10. Prima verifichi il template, che accetta gli interi positivi, e provi Apply e Undo; poi aggiungi il massimo 10 e controlli i confini. La prima review dimostra la regola iniziale, la seconda quella aggiornata.

#### Creare il template dal principio

Usa un modulo autonomo per verificare una regola delimitata senza dover rendere eseguibile tutto Mercato. La cartella pronta e il comando creano la stessa base didattica: scegli la prima per continuare subito, il secondo per riprodurne la creazione. Puoi usare la cartella `07-mercato-laboratorio/moduli/quantita` già pronta oppure creare un progetto vuoto e richiamare **A.D.E: Add Pure Quantity Feature** dalla palette. Il comando prepara feature, tipi, operazione `validateQuantity`, predicato e casi di base. Salva il modello. Il nodo visibile “Domain” è il contesto della regola.

La precondizione del template è **quantity maggiore di zero**. I valori appartengono a un tipo intero sicuro. Il testo `due` è quindi un errore di tipo, mentre 0 è un input del tipo corretto che non soddisfa la condizione.

#### Modificare il predicato dal form

Prima di cambiare la regola, apri il costruttore e distingui i valori usati dal confronto dal risultato booleano. Dal menu del progetto **Quantità ordine** scegli **Project Settings > Executable Behavior > Edit Pure Predicate**. Seleziona **validateQuantity**, la precondizione esistente e **Precondition · Inputs Only**. Avanza con **Next** dopo ogni scelta. Questo ambito usa gli input, mentre **Postcondition · Inputs and Outputs** consente anche i risultati.

Il costruttore offre **Add Value** per riferimenti e letterali, **Combine Values** per operatori compatibili e **Choose Result and Save** per il risultato. Il predicato deve rispondere “la quantità è ammessa?”: serve quindi una condizione booleana. I risultati di altro tipo non sono proposti come esito finale.

Per una prova reversibile aggiungi un letterale del tipo Quantity e inserisci `2`: è un numero normale, senza sintassi JSON. Per un testo digita direttamente le parole; per booleani ed enumerazioni scegli una voce. Gli operatori numerici comprendono somma, sottrazione, moltiplicazione, divisione e resto nel sottoinsieme degli interi sicuri. Puoi distinguere presenza e null, combinare condizioni e usare count/any/every sulle collezioni supportate. Il valore 2 serve qui a riconoscere l’inserimento tipizzato senza cambiare la regola salvata; lo scarterai prima della modifica del limite.

Clicca **Cancel** per scartare il letterale di prova. Per cambiare il limite, componi una nuova condizione e scegli il risultato da usare. **Clear Detached Expression** svuota la copia in lavorazione. Il predicato salvato resta disponibile fino all’applicazione della modifica.

#### Scrivere due casi indipendenti

Scrivi gli attesi dalla regola di business, separatamente dal generatore: se regola e codice condividessero lo stesso errore, i soli casi derivati potrebbero non rilevarlo. Zero e testo distinguono una quantità vietata da un dato del tipo sbagliato. Definiscili prima della verifica per avere un riferimento indipendente con cui giudicare la proposta.

In **Project Settings > Executable Behavior**, trova la sezione **Cases and Simulation** e apri **Independent Business Expectations > Add Predicate Test Case**. Nel modulo quantità il predicato e il criterio sono univoci e compaiono nel campo **Independent Case Name**. Se sono disponibili più predicati o criteri, scegli quelli pertinenti. Inserisci il nome, conferma con **OK**, scegli come fornire il valore e conferma il campo del valore con **OK**. Seleziona il risultato atteso. Crea i due casi seguenti:

| Nome | Input da scegliere | Valore | Risultato atteso |
| --- | --- | --- | --- |
| Zero quantità | Value for quantity | 0 | Not Satisfied |
| Testo non numerico | Different Value Type, poi Text | due | Input Type Error |

![Il campo per il nome del caso indipendente mostra il pulsante OK](immagini/07-input.png)

Il nome non può essere vuoto o duplicato. Un testo inserito nel normale campo intero viene rifiutato: per testare deliberatamente un tipo errato usa **Different Value Type**. **Absent** e **Null** permettono di rappresentare quelle condizioni nei casi negativi. Nei form ordinari restano disponibili soltanto le alternative consentite dal contratto.

Seleziona un caso esistente per **Edit Inputs**, **Edit Expected Result** o **Delete Case**. Cambiare un input conserva l’aspettativa precedente finché non la modifichi esplicitamente. L’eliminazione richiede una conferma; **Keep Case** conserva il dato. La conferma senza cambiamenti e l’annullamento non devono creare una nuova revisione. Rivedi input e atteso separatamente per evitare che una modifica del dato riscriva anche il risultato con cui vuoi controllarlo.

I risultati attesi disponibili comprendono Satisfied, Not Satisfied, Indeterminate, Input Type Error, Division by Zero e Nonintegral Result or Integer Overflow. Scegli secondo la regola di business e il tipo di espressione. Non ricavare l’atteso copiando automaticamente quello che il programma ha appena restituito.

#### Preparare, verificare, applicare e annullare

La review mostra cosa sarà scritto, la verifica confronta il comportamento con gli attesi, Apply conserva i file approvati. Ora che regola e casi sono dichiarati, segui questo ordine per giudicare la proposta prima che diventi codice del progetto; l’undo verifica che tu possa ritornare allo stato precedente senza perdere il modello.

1. Salva il modello e apri **Code > Review and Verification > Prepare Model to Code Review**.
2. Leggi comportamento e file previsti. L’azione prepara una proposta locale, senza inferenza IA per il profilo del template.
3. Premi **Run Real Verification**. Conferma l’esecuzione locale se ADE lo chiede.
4. Controlla lo stato corrente. Con gli otto casi iniziali e i due appena aggiunti, l’esercizio verificato mostra **10 Derived Cases e 10 Independent Cases**.
5. Con la review corrente e le verifiche superate, leggi l’elenco dei file e clicca **Apply to Project**. Attendi **Applied Locally**.
6. Controlla i file con **Files** o nel terminale. Riapri la review con **Code > Review Changes** se necessario, clicca **Undo Local Changes** e controlla **Local Changes Undone**. Conferma l’applicazione o l’annullamento se ADE presenta un dialogo.

In **Restricted Mode**, ADE può chiedere l’attendibilità della cartella prima della preparazione. Controlla che il percorso indichi la copia del modulo che hai scelto per il laboratorio, poi premi **Trust Folder & Continue**.

![La review distingue proposta, verifica superata e applicazione locale](immagini/08-verifica.png)

Nel template iniziale la proposta crea un modulo, il test associato, `package.json` e `.gitignore`. Il nome del modulo è assegnato da ADE. Non è necessario rinominarlo o editarlo per completare l’esercizio. La verifica riguarda il comportamento formalizzato e gli attesi del runner; non è un test end-to-end di un negozio reale.

Se cambi modello, criteri o sorgenti pertinenti dopo la review, preparala di nuovo. Quando Code mostra **Review Changes**, aprila e scegli **Prepare New Review**. Una vecchia verifica verde non autorizza ad applicare una revisione nuova. Se l’undo incontra modifiche manuali successive, ADE lo blocca: conserva il tuo lavoro e confronta i file prima di riprovare.

#### Esercizio completo: da quantità positiva a massimo dieci



Dopo la prova del ciclo review–verifica–Apply–Undo, modifica il requisito del modulo quantità: la nuova regola accetta gli interi da 1 a 10. Usa una copia per conservare la base di confronto. Prova i confini e i valori appena fuori: 0 e 11 devono essere Not Satisfied; 1 e 10 devono essere Satisfied. Questi casi distinguono un limite incluso da un confronto errato.

1. Apri **Edit Pure Predicate**, scegli validateQuantity, la precondizione esistente e Precondition · Inputs Only: il limite riguarda il dato ricevuto, prima di eseguire l’operazione.
2. Con **Add Value > Add Typed Literal > Quantity**, inserisci `10`: è il massimo incluso scelto per Mercato.
3. Con **Combine Values > Add Comparison**, scegli `quantity`, poi il letterale `10` e il confronto **≤** (minore o uguale), così 10 resta ammesso.
4. Con **Combine Values > Add Boolean Logic > All True**, scegli prima la condizione `quantity > 0`, poi `quantity` minore o uguale a `10`. All True richiede entrambi i vincoli: il solo massimo ammetterebbe anche zero e negativi.
5. Con **Choose Result and Save**, scegli il risultato che inizia con **and(** e comprende entrambe le condizioni. Premi **Next**, controlla il riepilogo **Review Your Changes** e clicca **Apply Changes**. Salva il modello con **Save** nella barra di ADE.
6. Nei casi indipendenti aggiungi “Limite 10” con input 10 e atteso Satisfied e “Oltre limite 11” con input 11 e atteso Not Satisfied.
7. Apri **Structural Blueprint > Data and Operations > Shared Operations**. Scegli **validateQuantity** in **Configuration** e apri **Access and Acceptance**. Nel criterio esistente cambia **Then** in “Soltanto i valori da 1 a 10 soddisfano la precondizione”, mantenendo **Given** e **When**. Premi **Apply to Model** e **Save**. La modifica conserva l’identità del criterio e i casi associati. Torna a **Independent Business Expectations** e usa **Edit Expected Result** per portare a **Not Satisfied** l’atteso del caso con input **9007199254740991**. Gli altri attesi iniziali restano pertinenti.
8. Prepara e verifica una nuova review. Se hai seguito tutti i passaggi di L12, ora gli indipendenti sono **12**; anche i derivati sono **12** nella variante qui verificata. Se Code mostra Review Changes, aprila e scegli Prepare New Review. Leggi la regola combinata e i risultati, poi applica se vuoi conservare il cambiamento. Non cambiare un atteso soltanto per nascondere un errore: qui la modifica del caso massimo deriva dalla nuova regola di business.

Per confrontare il risultato puoi aprire con Open Project la sottocartella **07-mercato-laboratorio/moduli/quantita/soluzione-limite** del pacchetto: contiene il predicato completo e i **dodici casi indipendenti** del percorso completo: otto iniziali, Zero quantità, Testo non numerico, Limite 10 e Oltre limite 11.

Controlla infine che modificare soltanto il layout non cambi la regola. Se sai spiegare perché 11 viene rifiutato e quali file saranno applicati, hai completato il percorso principale. Questo confronto distingue una scelta di presentazione da un cambiamento del comportamento da rigenerare e verificare.

**Traguardo L12:** parti dal template, aggiungi gli attesi indipendenti, modifichi il predicato con il costruttore visuale, prepari una nuova review, verifichi, applichi e annulli. Conserva nel diario del progetto il limite scelto e i casi 0, 1, 10, 11 e tipo errato. Il valore massimo sicuro deve ora essere atteso Not Satisfied: cambiare la regola richiede anche rivedere gli attesi di business.


### L13. Rendi esplicite le chiamate del checkout

La Sequence di Mercato descrive l’ordine delle chiamate; il modulo seguente aggiunge argomenti, risposte ed errori per verificarne il comportamento. Dopo la regola isolata di quantità, controlli la collaborazione fra Checkout, Payments e Orders con risposte simulate, senza coinvolgere un pagamento reale.

Apri `07-mercato-laboratorio/moduli/interazioni` e il diagramma **Checkout e pagamento**. Scorri verticalmente per seguire l’intero flusso. L’interazione principale chiama Payments, valuta un’alternativa, può richiamare la sotto-interazione di persistenza e gestisce una notifica opzionale.

![La sequenza eseguibile mostra chiamate, guardie e frame](immagini/12-interazioni.png)

Consulta il contratto eseguibile per capire quali dati determinano il ramo del pagamento e quando avviene la persistenza. Nel canvas apri **Diagram > Contents > Edit Executable Interaction**. Si apre direttamente **Interaction · checkout**. Naviga la gerarchia di messaggi, frame e rami. Per ogni chiamata dichiara mittente, destinatario proprietario dell’operazione, argomenti, modalità sincrona o asincrona, risposta, deadline (tempo massimo per la risposta), correlazione (per associare risposta e richiesta), risultati ed errori pertinenti.

| Costrutto | Uso pratico |
| --- | --- |
| alt | Scegliere un solo ramo in base a guardie; il ramo else copre gli altri esiti |
| opt | Eseguire un corpo soltanto quando la condizione lo richiede |
| loop | Ripetere con guardia, contatore e massimo esplicito |
| par | Avviare rami locali concorrenti e attenderne il join previsto |
| critical | Proteggere una risorsa locale con ordine dei lock coerente |
| ref | Richiamare una sotto-interazione con contratto e revisione espliciti |

Quando un argomento usa il risultato di una chiamata precedente, riferiscilo a quella specifica occorrenza: una risposta valida in un ramo non è automaticamente disponibile in un altro. Risultati di chiamate ripetute hanno identità distinte. Mantieni gli argomenti nello scope del ramo e della chiamata pertinenti. Il motore rifiuta cicli fra sotto-interazioni e ordini di lock incompatibili.

Per estendere la copertura oltre gli scenari forniti, dichiara in anticipo anche le risposte dei collaboratori e l’ordine atteso: così la verifica può rilevare una chiamata mancante o anticipata. I casi del progetto comprendono pagamento approvato, alternative, notifica e condizioni di errore. Apri **Independent Business Expectations** per aggiungere un caso dell’interazione: scegli il criterio, inserisci input e risposte simulate, ritardi, completamento/fallimento, output e ordine delle chiamate attesi. Le risposte sono dati: questa verifica non contatta il servizio Payments.

**Esercizio:** prepara la review da **Code > Prepare Model to Code Review**. Se compare la richiesta di attendibilità, controlla che indichi la copia di `interazioni` e scegli **Trust Folder & Continue**. Premi **Run Real Verification** e verifica che passino **sette casi derivati e sette indipendenti**. Scorri il canvas fino a **Optional · Guard: notify** per leggere la guardia e la chiamata Checkout → Notifications. Per consultare i campi, da **Edit Executable Interaction** scegli **opt**, premi **Next** e scegli **Open Child Steps**, poi **Next**. La riga **notify** corrisponde al messaggio del ramo opzionale. Clicca **Cancel** per uscire conservando il modulo di partenza. Per approfondire, **Independent Business Expectations > Author Independent Interaction Case** permette di aggiungere input, risposte simulate e ordine atteso.

**Collegamento a Mercato:** Payments rappresenta Pagamenti esterni; Orders la registrazione dell’Ordine; Notifications la notifica. Studia prima il modulo senza rinominarne le identità o gli attesi. Poi riporta nella tua specifica i contratti effettivamente necessari. Un diagramma descrittivo della soluzione e questa interazione eseguibile sono due livelli distinti del percorso.

**Controllo L13:** sai distinguere la chiamata, la risposta simulata, il ramo alternativo e il criterio indipendente. Una verifica passata non prova un pagamento reale.


### L14. Simula il ciclo di vita dell’ordine

Il risultato di una chiamata non descrive da solo il ciclo di vita dell’ordine. Dopo le interazioni, usa eventi e stati per controllare quali passaggi sono ammessi, se un errore conserva lo stato precedente e come vengono trattate consegne duplicate. Il modulo rende osservabili queste scelte nella traccia della simulazione.

#### Macchine a stati

Passa al modulo dedicato perché la vista State di Mercato era descrittiva: qui trovi le risposte e le azioni necessarie per simulare davvero il ciclo di vita locale. Apri `07-mercato-laboratorio/moduli/stati`. **Checkout Lifecycle** contiene Draft, Paid e Cancelled. Il contratto eseguibile dichiara inizializzazione, eventi, azioni entry/exit/do, guardie, priorità ed effetti ordinati. Il solo disegno di tre stati non sarebbe sufficiente per eseguirlo.

Parti dal pagamento riuscito per avere una traccia di riferimento da confrontare con il fallimento e la consegna ripetuta. Apri il menu del progetto **Bottega - Stati** nella barra superiore e scegli **Project Settings > Executable Behavior > Simulate State Machine**. Seleziona **checkout.paid**. Il documento **State Simulation.txt** si apre nell’editor. Il rapporto mostra stato **Paid**, evento accettato e transizione **Draft verso Paid**. La traccia distingue valutazione della guardia, annullamento dell’attività do, exit, effetto, entry e commit.

![Il rapporto della simulazione a stati rende visibili le fasi e lo stato finale](immagini/10-stati.png)

Per controllare gli esiti negativi, torna alla scheda **Checkout Lifecycle** nella barra degli editor. Si riapre la pagina **Project Settings** con **Executable Behavior** già espanso. Seleziona di nuovo **Simulate State Machine** e prova `checkout.failed-charge`. Verifica lo stato Draft e l’errore denied. Ripeti con `checkout.dedup-reopen` e verifica lo stato Paid e i tre eventi accepted, duplicate e rejected con deliveryConflict. Per tornare al canvas dopo l’ultimo rapporto, clicca la scheda **Checkout Lifecycle** e il pulsante **Back to Diagram**.

Modifica la macchina solo dopo aver letto le tracce. In **Project Settings > Executable Behavior**, usa **Edit Executable State Machine** e seleziona **Checkout 1** per aprire la definizione del modulo. Ownership, eventi e transizioni precisano a quale ordine si applica ciascuna azione e in quali condizioni può cambiarne lo stato. Dichiara ownership architetturale e di lifecycle, un solo stato iniziale, eventuali stati finali, eventi con payload tipizzato, transizioni interne/esterne, guardia, priorità e azioni. Le azioni richiamano interazioni revisionate. Una self-transition interna e una esterna seguono cicli di entry/exit differenti.

Per verificare una variante, scrivi l’evoluzione attesa prima di simularla: stato finale ed esiti degli eventi permettono di rilevare transizioni o effetti inattesi. Nei casi indipendenti dichiara input iniziale, eventi, risposte delle azioni, esiti accettato/rifiutato/duplicato/fallito, transizione ed errore attesi, stato finale, quiescenza e checkpoint quando necessari. Il profilo supporta macchine piatte: niente stati compositi o regioni ortogonali. La simulazione non è un monitor di istanze applicative vive.



**Collegamento a Mercato:** Draft, Paid e Cancelled sono i nomi degli stati del modulo eseguibile. Confrontali semanticamente con In attesa, Confermato e Rifiutato della tua progettazione; non considerarli equivalenti automaticamente, perché “annullato” e “pagamento rifiutato” possono richiedere transizioni diverse. Prima di integrare il modulo nel dominio reale decidi quale lifecycle adottare e i relativi eventi. Questo è un punto di modellazione da discutere, non un mapping implicito.


### L15. Simula pubblicazione e consegna dei messaggi

Dopo aver chiarito le transizioni dell’ordine, esamina come un evento può raggiungere gli altri partecipanti. Queue e topic risolvono esigenze diverse: assegnare un lavoro a un consumer oppure informare più subscription. La simulazione locale rende visibili consegne, nuovi tentativi e duplicati prima di scegliere un’infrastruttura reale.

Usa la topologia pronta per leggere le regole di pubblicazione e consegna. Apri `07-mercato-laboratorio/moduli/messaggi`, poi il menu del progetto **Bottega - Messaggistica > Project Settings > Executable Behavior**. Scegli **Edit Messaging Topology**, seleziona **checkout.messaging** e premi **Next** per consultare contratti, canali, producer, consumer e policy. La topologia contiene un producer di queue e uno di topic. Le subscription comprendono workers, billing e analytics. Per passare alla simulazione senza modificare la topologia, clicca **Cancel**.

Scegli una **queue** quando un lavoro deve essere assegnato a uno dei consumer concorrenti, come nell’esercizio workers. Scegli un **topic** quando lo stesso evento deve raggiungere subscription diverse, come billing e analytics: questa diffusione è detta fan-out. I contratti dei messaggi hanno nome/versione, payload record e campi per identità, routing e correlazione. Ack conferma l’elaborazione, backoff stabilisce l’attesa fra tentativi e la dead letter queue raccoglie gli esiti non consegnabili secondo la policy. Dichiara attesa, tentativi, capacità e deduplica/idempotenza per rendere verificabile anche il comportamento in caso di errore.

La prima simulazione isola una pubblicazione e una consegna riuscita: partire senza ritardi o errori rende riconoscibili le due osservazioni da confrontare con le policy più complesse.

**Simulazione guidata senza broker:**

1. In **Project Settings > Executable Behavior** apri **Simulate Messaging**. Nel modulo si apre la topologia `checkout.messaging`. Se il progetto ne contiene più di una, seleziona quella da simulare. Avanza con **Next** dopo ogni scelta o valore.
2. Scegli **Publish Message**, lascia il tempo logico `0` e scegli il producer **publish.queue**, per assegnare il lavoro a un worker.
3. Inserisci identità `ordine-guida-1`, `orderId` uguale a `42` e `correlationId` uguale a `checkout-42`: l’identità distingue il messaggio, orderId il dato di dominio e correlationId il contesto del checkout.
4. Scegli **Deliver to Worker**, tempo `0`, subscription **workers**, worker `A` e **Handler Succeeds**, così il primo confronto riguarda una consegna riuscita senza retry.
5. Scegli **Finish Scenario**, premi **Next** e controlla il riepilogo **Review Simulation Scenario**. Clicca **Run Simulation** per eseguire lo scenario locale.

Si apre **Simulation Result · Zero AI Calls · No Network**. Leggi le due righe **ordine-guida-1** (Publication Observation) e **workers:A:ordine-guida-1:1:ok** (Worker Delivery Observation). Il riepilogo mostra zero rifiuti e zero dead letter. Dopo la lettura puoi cliccare una riga per chiudere il risultato.

![Risultato del messaggio simulato, con una pubblicazione e una consegna](immagini/11-messaggi.png)

Dopo il caso riuscito puoi variare un esito per volta e confrontare le osservazioni: il fallimento mette alla prova la policy di retry, il topic la diffusione a più subscription. Per esplorare retry e backoff scegli Handler Fails e tempi logici coerenti con la policy. Per osservare fan-out usa publish.topic e subscription differenti. I casi indipendenti già forniti comprendono competizione, fan-out, deduplica, idempotenza, tentativi esauriti e incompatibilità del contratto; si verificano dalla review del profilo.

La simulazione è locale e non usa la rete. ADE non offre un pannello per avviare o amministrare un broker NATS reale. Un caso simulato passato non dimostra la consegna su un’infrastruttura esterna.

**Collegamento a Mercato:** usa il broker progettato in L4 come contesto e il modulo per verificare una policy locale. Descrivi un evento OrderConfirmed con identità, orderId e correlazione; decidi chi lo pubblica e chi lo consuma. Se vuoi un servizio reale, serviranno implementazione, configurazione, credenziali e prove d’integrazione separate.


### L16. Esegui il modulo di codice e importalo

Ora confronti il modello con un piccolo modulo JavaScript eseguibile. Test e demo fissano il comportamento iniziale; l’importazione successiva collega le dichiarazioni ai file da cui provengono. Questo riferimento serve a distinguere una funzione osservabile nel sorgente da una lettura architetturale proposta in seguito.

**Apri una copia di `07-mercato-laboratorio/codice`**, distinta dai moduli simulati: contiene `src/orders.mjs`, una demo e sette test, senza dipendenze da installare. Il modulo usa prezzi in centesimi, quantità intere positive ed esiti confirmed o declined.

Esegui test e demo sulla copia iniziale per avere un riferimento prima delle modifiche di L18. Puoi usare il terminale del sistema oppure quello integrato. Per usare quello integrato, apri la copia di `codice` nell’IDE. Se compare **Restricted Mode**, controlla il contenuto della cartella e usa **Trust** per questa copia soltanto. Nel menu del progetto scegli **Project Settings > Developer Tools > Terminal**.

Nel terminale controlla con `pwd` su macOS/Linux o `Get-Location` in PowerShell di essere in `codice`. Se serve usa `cd` con il percorso della copia fra virgolette. Il laboratorio è stato verificato con Node 24.22.1 e npm. Se usi `nvm` e hai già quella versione, selezionala con `nvm use 24.22.1`. Esegui i due comandi.

```sh
npm test
npm start
```

Devi ottenere sette test superati e la demo `{ status: 'confirmed', totalCents: 2500 }`. La demo usa due unità da 1250 centesimi con pagamento approvato: 2500 controlla il totale e confirmed l’esito, come riferimento prima delle modifiche.

#### Importazione locale

Crea l’inventario per risalire dal nome `validateQuantity` alla sua dichiarazione. Se avevi già importato la copia per aprire il terminale integrato, riprendi dal punto 3. La risoluzione semantica aggiunge i collegamenti JS/TS disponibili. **Structure Only** basta per il solo inventario strutturale.

1. Dalla Home scegli **Import Codebase** e la cartella `07-mercato-laboratorio/codice`.
2. Scegli **Structure and Available Semantic Analysis** per includere la risoluzione JS/TS disponibile, oppure Structure Only per il solo inventario strutturale.
3. Attendi **Source Inventory Ready**. L’importazione non ha installato dipendenze o eseguito l’applicazione.
4. Nella pagina **Explore Your Codebase**, clicca **Inspect Code Evidence** per consultare l’inventario locale.
5. Scegli **validateQuantity** con etichetta **Extracted declaration**, collegata a `src/orders.mjs:3`. La dichiarazione è già visibile nella lista di questo esempio. Nelle liste più lunghe puoi digitare il nome nel campo di ricerca. Nell’editor verifica che la funzione accetti gli interi positivi.
6. Per tornare all’esplorazione, clicca la scheda **Create Diagrams: codice** nella barra degli editor.

![L’inventario locale è pronto prima dell’interpretazione architetturale](immagini/13-importazione.png)

![Le evidenze distinguono dichiarazioni, riferimenti statici e definizioni](immagini/14-evidenze.png)

L’inventario non coincide con un’architettura di dominio già interpretata. Nell’esplorazione incrementale corrente, **Explore Architecture** avvia il percorso IA della sezione L17. Senza account puoi comunque esaminare le evidenze e continuare la progettazione manuale nei progetti visuali.

#### Copertura, scope e versioni

Prima di interpretare i risultati, controlla quali linguaggi e risoluzioni sono effettivamente coperti: un file presente nell’inventario può avere un’analisi soltanto parziale. L’importer include sedici profili: JavaScript, TypeScript, TSX, Python, Java, C#, C, C++, Go, Rust, PHP, Ruby, Swift, Dart, Kotlin e Scala. La risoluzione semantica integrata riguarda JS/TS/TSX; bundle SCIP coerenti possono integrare altri produttori supportati. Un riferimento statico non prova una chiamata avvenuta a runtime.

Nell’elenco delle evidenze, clicca **Open Full Analysis Details** per aprire il rapporto di sola lettura **Source Analysis.json**. Consulta inventario, revisioni, diagnostiche e produttori. Distingui analizzato, parziale, non supportato e non classificato. Controlla la copertura prima di affidarti a una relazione: un’analisi parziale può lasciare aperta la questione di una dipendenza.

Prima dell’esplorazione IA delimita l’inventario ai sorgenti e ai documenti utili. Dalla scheda **Create Diagrams: codice** clicca **Open Quick Access**, cerca `>Configure Import Scope` e scegli **Configure Import Scope**.

1. In **Include Source Paths** inserisci `src/**, test/**, package.json, REQUISITI.md` e conferma con Invio.
2. In **Exclude Source Paths** inserisci `.vscode/**` e conferma con Invio. Le regole di `.gitignore` e `.adeignore` continuano ad applicarsi.
3. Leggi **Source Inventory Preview**, controlla inclusioni, esclusioni e file analizzati, poi clicca **Apply Source Inventory**. ADE salva una nuova istantanea dell’analisi. Usa le evidenze della nuova istantanea per le ricerche successive.

Le versioni di modello/indice permettono recupero e confronto. Il ripristino storico dell’indice non riscrive i sorgenti correnti. Se un’evidenza risulta superata, aggiorna l’analisi o apri consapevolmente il file corrente senza applicare un vecchio range.

**Controllo L16:** nel nuovo percorso `codice` ottieni sette test passati e un inventario delle dichiarazioni. Apri validateQuantity dal risultato delle evidenze e confrontala con la regola del laboratorio: il modulo iniziale accetta quantità positive senza il massimo 10. È il punto di partenza per la modifica di L18, non la soluzione già aggiornata al nuovo limite.


### L17. Usa l’IA per esplorare, con contesto e review

L’inventario di L16 elenca fatti dei sorgenti; l’esplorazione IA propone una loro lettura in termini di responsabilità e flussi del checkout. Configura prima account, modello e budget, poi revisiona le bozze contro le evidenze: ottieni viste da discutere, senza trattare le ipotesi dell’assistente come comportamento provato.

**Ramo facoltativo.** Per questa lezione serve un account con un modello disponibile. Se l’account o il modello manca, torna al modulo quantità e prosegui da L20.

Apri il menu con il nome del progetto e scegli **AI Settings**. In **Account and Model** premi **Connect Claude Code or Codex** e segui il percorso di accesso del provider. Se una CLI compatibile è già autenticata, usa **Choose Model and CLI** per configurarla. **Refresh Account and Models** aggiorna lo stato dell’account dopo l’accesso. Scegli **Choose Diagram Model** per impostare il modello dell’esplorazione.

![Account, budget delle richieste e budget di esplorazione sono separati](immagini/09-ia.png)

Scegli il modello dal catalogo dell’account. Se l’ID che ti serve manca dall’elenco, scegli **Enter Exact Model ID** e inserisci un identificativo ammesso dal provider. Un modello disponibile in Copilot non diventa automaticamente disponibile nella CLI Codex o Claude. Un eseguibile mancante, un account non autenticato e un modello non valido sono problemi distinti.

Se **The Selected Diagram Model Is Not Available in Codex Chat** compare per un modello ammesso dalla tua CLI autenticata, usa **Refresh Account and Models** e leggi lo stato sotto **Account and Model**. Se il catalogo della chat continua a escludere il modello, riapri **Connect Claude Code or Codex > Codex > Choose Model and CLI**. Mantieni lo stesso ID e in **Original CLI Executable** indica il percorso assoluto della CLI Codex già autenticata. Poi verifica lo stesso ID in **Choose Diagram Model** e torna alla Home. Premi **Continue Generation** se il tentativo precedente ha già aperto una sessione, altrimenti **Explore Architecture**. Controlla il contesto e invia dal compositore.

In **AI Requests > Configure AI Request Budget** imposta il numero di invocazioni della CLI per operazione strutturata. Con zero prepari il contesto, con una prepari il piano e con due puoi richiedere anche l’implementazione. La CLI gestisce le proprie richieste HTTP, i turni e i token. Dopo aver aperto l’esplorazione del progetto, **Diagram Generation > Add Exploration Budget** modifica il suo budget specifico. L’invio nella conversazione avvia il lavoro del provider.

Apri soltanto la codebase e i file che vuoi coinvolgere. Prima di inviare leggi contesto, selezioni e perimetro. Lo stato nella modale distingue preparazione, attività degli strumenti, attesa, risposta ed errori. Durante una richiesta evita invii ripetuti; usa il controllo di interruzione se necessario. Questo controllo delimita le informazioni usate per proporre l’architettura; un file non incluso non può essere considerato automaticamente verificato.

La modale dei diagrammi ha una conversazione temporanea: chiudendola la richiesta attiva viene annullata e la cronologia della modale viene azzerata. Piano e bozze già completate rimangono nel progetto. Non usare la chiusura come archivio della conversazione.

Il confronto modelli è in **Advanced · Model Benchmarks**. Serve per prove esplicite: leggi progetto, modello, esito, contesto, tempi e uso riportato. Risultati simulati, token comunicati dal provider e una fattura effettiva sono misure diverse. Il confronto non sostituisce la scelta del modello disponibile al tuo account.

#### Dal codice alle viste proposte

Le evidenze e la connessione sono ora disponibili: puoi chiedere viste che rispondano alle domande di Mercato, mantenendo separati regole lette nel codice e ipotesi da chiarire. Dopo l’importazione del modulo codice di Mercato, con account e modello configurati, premi **Explore Architecture**. Leggi il messaggio iniziale e invialo soltanto quando sei pronto a condividere il contesto selezionato.

Per l’esempio puoi chiedere:

> Analizza questa piccola codebase degli ordini. Prepara una panoramica delle responsabilità e un flusso del checkout. Distingui la validazione della quantità, il calcolo in centesimi e l’esito del pagamento. Usa le evidenze dei sorgenti; segnala ciò che non puoi ricavare.

L’assistente esplora inventario e sorgenti nel perimetro, propone un piano di viste e prepara bozze condivise. Controlla che il piano risponda alle tue domande e che le responsabilità riusino identità coerenti. Puoi chiedere correzioni, separare scenari o chiarire il significato di una relazione.

Quando il piano è pronto, confronta responsabilità e collegamenti con le evidenze prima di applicare il gruppo: questo è il momento in cui una proposta diventa parte del modello locale. Procedi così:

1. Quando l’assistente ha finito di preparare le bozze, chiudi il compositore e apri **Review All Changes**.
2. Leggi prima le anteprime: responsabilità, collegamenti, condizioni e ordine dichiarato.
3. Controlla sorgenti, esclusioni, lacune e diagnostiche pertinenti. Apri **Change Details** per vedere le singole modifiche.
4. Se qualcosa non va, torna alla conversazione e chiedi una correzione mirata.
5. Usa **Apply All Changes** e conferma per applicare il gruppo revisionato al modello locale. Apri le viste dal selettore per controllare il risultato.

Un piano incompleto, una bozza invalida o una review diventata obsoleta impediscono Apply. **Continue Generation** riprende il lavoro incompleto; l’esaurimento del budget richiede un ampliamento esplicito. Per riaprire le viste applicate, dal menu del progetto scegli **Open Project** e seleziona la stessa cartella `codice`. Se cambiano i sorgenti, usa il percorso di aggiornamento per rivedere ciò che è diventato obsoleto invece di ricreare manualmente tutte le viste.

La generazione sceglie le notazioni pertinenti, non una vista di ogni tipo. Gli stati descrittivi non sono attualmente generati da questo percorso incrementale: puoi modellarli manualmente o usare il profilo eseguibile dedicato. I nomi e il numero delle bozze dipendono dall’analisi del provider, quindi non devono coincidere parola per parola con uno screenshot.

**Controllo L17:** prima dell’invio sai quale cartella e quale contesto coinvolgi; prima dell’applicazione sai distinguere evidenza, ipotesi, bozza e vista approvata. Se l’account manca, documenta la lezione come non eseguita e continua con le attività locali.


### L18. Richiedi un aggiornamento del codice e lavora in isolamento

Dopo aver applicato le viste della codebase, puoi chiedere che il limite 10 sia rispettato anche dal codice. Il modello salvato comunica l’intento; diff e test mostrano cosa è cambiato davvero. Il worktree è un percorso distinto per revisionare una feature separatamente, quando il progetto ne soddisfa i prerequisiti.

**Continua qui soltanto se hai completato l’esplorazione e applicato le viste di L17 nella copia del modulo codice.** Un inventario pronto non è ancora un modello interpretato. Senza account o senza queste viste, salta il ramo assistito e continua in L20 sul modulo quantità; i diagrammi del Mercato principale non vengono trasferiti automaticamente nella cartella codice.

Con la copia del modulo codice aperta, scrivibile e attendibile, apri la vista delle responsabilità applicata in L17. Seleziona `validateQuantity`, apri **Manage > Edit Description** e descrivi il nuovo comportamento. Per esempio, “Verifica che la quantità sia un intero sicuro. Restituisce true soltanto per le quantità da 1 a 10 inclusi e false per gli altri interi sicuri. Per un valore che non è un intero sicuro, inclusi decimali e stringhe, solleva TypeError.” Conferma con **Save Changes** e salva il modello con **Save**.

Se al salvataggio ADE propone **Update Codebase from Diagrams**, scegli quel pulsante. Altrimenti apri **Code** e premi **Update Codebase from Diagrams** nel riquadro **Codebase from Diagrams**. Il messaggio iniziale è modificabile e include il modello attivo e, quando disponibile, il cambiamento dell’ultimo salvataggio.

Per la codebase didattica, una richiesta concreta è:

> Limita a 10 le unità di un ordine. Mantieni i prezzi e il totale in centesimi. Aggiungi i controlli per 0, 1, 10 e 11, per un valore non intero e per un testo. Conserva gli esiti confirmed/declined e il comportamento non coinvolto. Mostra i test eseguiti e le eventuali scelte ancora da chiarire.

Nel compositore controlla cartella e intento, poi clicca **Send**. Se nel frattempo cambia il modello, prepara un nuovo contesto. Lo spostamento dei nodi riguarda la presentazione. Salva la scelta di business prima di chiedere all’assistente di implementarla.

Al termine leggi le modifiche effettive, controlla i file e riesegui `npm test` e `npm start` nel terminale integrato come in L16. Controlla anche il messaggio per i valori fuori intervallo. Per scartare una modifica assistita usa la review e gli strumenti Git del progetto. Il journal e l’undo del profilo deterministico appartengono alla procedura di L12.

Apri il flusso del checkout e confronta le condizioni con i nuovi test. Se il flusso descrive ancora la regola precedente, dal canvas scegli **Diagram > Update Diagrams from Codebase**, oppure apri la stessa azione dal pannello **Code**. Nel compositore chiedi di aggiornare la vista Activity già applicata usando il nuovo comportamento. Controlla il contesto prima dell’invio, poi rivedi le bozze prima di applicarle come in L17.

Una copia senza diagrammi interpretati può richiedere prima l’esplorazione o la creazione delle viste. L’aggiornamento usa la codebase del progetto aperto; evita di usare il clone dell’IDE come cartella di destinazione.

#### Una feature in un worktree

Un worktree permette di confrontare e verificare i file proposti prima di portarli nella cartella principale. Questo ramo richiede un modello legacy compatibile, una codebase Git collegata con almeno un commit e uno stato pulito, una feature con criteri di accettazione riconosciuti e un provider configurato. I progetti v4/v5 usano **Prepare Model to Code Review** per il comportamento eseguibile. Per la copia v5 importata in L16, continua con L20 dopo l’esercizio assistito disponibile.

Se parti dalla guida e hai accesso ai sorgenti di ADE preparati in A1, crea in Finder una copia indipendente della codebase didattica iniziale e chiamala `codice-legacy`. Copia al suo interno il file di esempio `ade/examples/checkout.ade.json` dai sorgenti di ADE senza cambiarne il contenuto. Dalla Home scegli **Start a Project > Examples and Model Files > Open Model** e apri il file nella copia. Il modello contiene **Conferma acquisto**, una feature con criteri già dichiarati.

Dal menu del progetto scegli **Show IDE**. Per una copia senza Git, apri **Source Control** ed esegui **Initialize Repository**. Seleziona **Stage All Changes**, scrivi il messaggio “Base del progetto di esempio” e clicca **Commit**. Se Git chiede nome o email, configura prima la tua identità. Verifica in **Source Control** che il commit sia registrato e che non ci siano modifiche in attesa. La cartella di lavoro `.ade` è già esclusa dall’ignore della codebase didattica.

Con il commit iniziale pronto, prepara l’istantanea di modello e codice. Clicca **Open Quick Access**, cerca `>A.D.E: Update Diagrams from Codebase` e seleziona il comando. Se richiesto, controlla il percorso della copia e scegli **Trust Folder & Continue**. Quando si apre il compositore, chiudilo senza inviare la richiesta. ADE ha già preparato l’istantanea iniziale dal modello aperto e dai sorgenti di quella cartella. Se avevi già preparato la baseline prima di inizializzare Git e compare **Source manifest changed**, riallineala con il percorso Sync di L19.

Nel progetto compatibile clicca **Open Quick Access**, cerca `>A.D.E: Implement Feature` e seleziona **Conferma acquisto** per l’esempio. Scrivi il cambiamento in **Requested Behavior** e conferma il campo con Invio. Scegli i file da condividere, `src/orders.mjs` e `test/orders.test.mjs` nell’esempio, e clicca **OK**. Leggi **Review Implementation Context**, quindi scegli **Send Context to Codex** o il controllo equivalente del tuo provider. Controlla piano e domande. Con il budget **Plan and Implementation** e dopo gli eventuali chiarimenti, clicca **Generate in Worktree**.

ADE prepara le modifiche in un worktree separato. Leggi le schede diff e **Implementation Review.md**, poi torna alla scheda del modello e apri **Code > Implementation Worktree**. Clicca **Run Tests** e conferma **Run Tests**. Dopo la verifica torna alla scheda del modello, clicca **Apply Verified Changes** nello stesso riquadro e conferma **Apply Changes**. Controlla il diff della cartella principale in **Source Control**.

Se il riquadro non è disponibile, da **Open Quick Access** cerca `>A.D.E: Verify Implementation` per la verifica e `>A.D.E: Apply Verified Implementation` dopo che i test sono passati. Entrambi i comandi mostrano la stessa conferma.

Se la feature non ha criteri riconosciuti o il formato non è supportato, l’azione può restare indisponibile. I criteri delle operazioni condivise e quelli delle feature legacy non sono intercambiabili automaticamente. Questa guida usa il percorso eseguibile della sezione L12 per il laboratorio locale interamente guidato; l’importazione del solo modulo codice di partenza non completa i prerequisiti del worktree.

**Resume Implementation** riprende una review salvata. **Recover Interrupted Implementation** gestisce una transazione interrotta. L’undo ripristina preimmagini soltanto quando non sovrascrive modifiche manuali successive. Un test annullato o interrotto richiede una nuova esecuzione riuscita. Il worktree non è una sandbox del sistema operativo e il percorso non installa automaticamente dipendenze suggerite dal modello.

**Esercizio Mercato:** usa una copia del modulo `codice`, porta il limite a 10, aggiungi prove per 0, 1, 10, 11, decimali e testo e verifica che i totali rimangano in centesimi. La consegna è il diff dei file e il risultato dei test. Non presentare come completata l’implementazione se hai soltanto salvato il diagramma o preparato il messaggio.


### L19. Riconcilia modello e sorgenti con Sync

Dopo modifiche indipendenti a modello e sorgenti, Sync confronta entrambi con la loro baseline comune per individuare divergenze e conflitti. Serve a recuperare un’intenzione coerente prima di proseguire il lavoro. È una scheda per progetti compatibili: il laboratorio non crea automaticamente la baseline e gli adapter richiesti.

**Scheda avanzata per progetti legacy compatibili.** Per eseguire Sync occorrono un formato e un adapter supportati, una codebase collegata, corrispondenze modello/codice e una baseline comune valida. Una nuova proposta assistita richiede anche l’account. Per vedere l’anteprima locale usa la copia `codice-legacy` e la preparazione della baseline di L18. Se hai aperto la copia di L16 con il percorso incrementale v5, passa a L20.

Per provare Sync dopo il worktree, usa una seconda copia pulita del progetto di esempio e prepara la baseline. Se **Review Sync Context** rifiuta un sorgente, controlla se proviene da **Apply** del worktree. In questa build Sync esclude i file collegati al journal con hard link.

Usa Sync quando modello e codice sono cambiati e devi recuperarne la coerenza. Confronta **baseline comune, modello corrente e codice corrente** per distinguere le modifiche di ciascun lato e riconoscere i conflitti. Servono formato e adapter compatibili: un progetto v5 di esplorazione non abilita implicitamente il Sync legacy.

Nel progetto legacy collegato apri **Code** e clicca **Sync Project** sotto **Recovery and Synchronization**. In **Sync Preview** leggi il riepilogo locale di file, simboli, dipendenze, viste e conflitti. Per una proposta assistita apri **Review Sync Context**, seleziona i file pertinenti e conferma. Controlla il contesto e clicca **Request Sync Proposal**.

Una proposta può includere modifiche puntuali al modello e sostituzioni ancorate nel testo dei file esistenti. Leggi il rapporto **Sync Proposal.md**, il diff in **Inspect Code Changes** e le eventuali domande in **Questions and Validation**. Rispondi con **Answer Sync Questions** e prepara la proposta aggiornata. **Apply Sync** compare quando la proposta soddisfa i controlli richiesti. Con una proposta vuota, per esempio dopo un commit che lascia intatti i sorgenti, **Apply Sync** registra un’istantanea comune dal modello e dai sorgenti correnti.

Quando modifichi contemporaneamente lo stesso contratto nel modello e nei sorgenti, confronta le tre versioni e decidi quale intento preservare. Conferma le corrispondenze di rinomina soltanto quando sono corrette. Non risolvere un conflitto scegliendo una versione solo per rendere verde la review. La baseline permette di distinguere una scelta nuova da un valore rimasto invariato; la rinomina deve mantenere la corrispondenza con la stessa identità.

Dopo Apply esegui i test e la build del progetto: Sync non li esegue automaticamente. **Undo Last Sync** ripristina modello e sorgenti se le immagini sono ancora valide. **Recover Sync** gestisce una riconciliazione interrotta. Il ripristino di un vecchio snapshot modello/indice lascia invece invariati i sorgenti.

Il Sync testuale attuale modifica file esistenti; creazione, spostamento ed eliminazione fisica appartengono ai profili strutturali che le supportano. Una proposta in cache può essere riusata senza una nuova chiamata solo per il medesimo contesto valido.

**Quando il progetto è compatibile e ha una baseline:** dopo una modifica effettiva aggiorna l’analisi, confronta il nuovo limite con il modello e revisiona la proposta. Conserva la scelta precedente finché il conflitto non è risolto. ADE Sync e Git Sync non sono lo stesso comando: il primo riconcilia artefatti del progetto, il secondo scambia commit con un remoto.


### L20. Completa il ciclo: reverse, runtime e continuità

Dopo la prima implementazione, una modifica dei sorgenti o del runtime può cambiare il comportamento concordato. Il reverse confronta il codice con il modello; gli stessi casi indipendenti aiutano a giudicare una variazione. Task e preparazione continua conservano il contesto e preparano review per le modifiche successive.

#### Tornare dal codice al modello

Una modifica diretta al codice può contraddire la regola concordata. Il reverse propone di riportarla nel modello; i casi indipendenti servono a decidere se quel nuovo comportamento è accettabile. La prova seguente deve proprio far emergere una divergenza. Abbassare apposta il massimo da 10 a 9 deve far fallire il caso Limite 10: il blocco dimostra che la proposta contraddice il requisito ancora valido.

**Torna con Open Project alla copia del modulo quantità di L12.** Se avevi concluso con Undo, prepara una nuova review, esegui Run Real Verification e Apply to Project: prima del reverse devono esistere i file generati. Le simulazioni di L13-L15 e l’importazione di L16 non li creano in questa cartella.

Per una prova reversibile:

1. Se l’Explorer è chiuso, dal menu del progetto apri **Project Settings > Developer Tools > Files**. Espandi `src` e apri il file `predicate-…mjs` creato dalla review di L12.
2. Nella funzione generata individua il letterale usato come limite nel confronto `<=`. Nell’esempio è `const v3=10;`. Se la riga è lunga, scorri orizzontalmente. Cambia soltanto `10` in `9`, lascia intatto il commento dei metadati e clicca **File > Save**.
3. Torna alla scheda ADE e apri **Progetto > Project Settings > Executable Behavior > Code and Context > Reverse Model Behavior from Code**.
4. Nella review **Code to Model** controlla `quantity ≤ 9` e premi **Run Real Verification**. Conferma se ADE lo chiede. Attendi **Real Verification Failed · Application Blocked** ed espandi **Verification Output**. Nella variante con 24 casi, 23 passano e fallisce **Limite 10**. **Apply to Project** resta disabilitato.
5. Non applicare la prova e non cambiare l’atteso per farla passare. Torna al file e ripristina il letterale `10`, poi salvalo.
6. Ripeti **Reverse Model Behavior from Code**. Quando file e modello tornano equivalenti, ADE mostra **Model Behavior Is Aligned · No Proposal · No AI Calls**. Apri **Project Settings > Developer Tools > Terminal** sulla copia `quantita`, verifica la cartella corrente e seleziona Node 24.22.1. Esegui `node --test test/*.test.mjs` per verificare i **12 test indipendenti** emessi nel progetto. La review ADE esegue anche i dodici casi derivati.

Questa prova insegna a riconoscere una divergenza e a fermarsi prima di applicarla. Per accettare davvero un nuovo limite servirebbero una decisione di business, il criterio aggiornato e gli attesi coerenti, seguiti da una nuova verifica.

Il reverse è delimitato: non ricostruisce l’intento da codice arbitrario. Predicati, interazioni, stati e messaging supportano sottoinsiemi dichiarati. Una modifica fuori grammatica può produrre un mapping parziale e bloccare Apply. ADR, annotazioni e contratti vengono conservati invece di essere dedotti dal testo del sorgente.

Se devi riorganizzare i file generati, usa le azioni di spostamento del sorgente gestito per conservare i riferimenti supportati: consentono percorsi annidati ammessi e aggiornano quei collegamenti. Usa la review per controllare collisioni e identità. Non spostare manualmente più copie dello stesso artifact aspettandoti che ADE scelga automaticamente quella corretta.

#### Scegliere Node o Bun

Valuta un cambio di runtime solo dopo avere una regola verificata da conservare: il piano confronta la nuova realizzazione con il comportamento di business, senza cambiare automaticamente quel requisito. In **Project Settings > Model and Architecture** usa **Choose Runtime and Review Stack Plan**. I profili correnti sono Node ESM e Bun ESM, con versioni previste dal prodotto. Per questa guida il laboratorio usa Node 24.22.1; il profilo Bun richiede Bun 1.3.2 disponibile all’avvio di ADE.

Il piano esplicita implementazione, dipendenze, storage, dati, test, deploy e ritorno. Riesegui gli stessi casi indipendenti per controllare che cambiare runtime conservi il comportamento di business. Risolvi eventuali vincoli ADR incompatibili. Il comando non installa Bun e non migra database o broker vivi.

#### Task, chiarimenti e continuità

Apri **Project Settings > Model and Architecture > Tasks and Clarifications**. Scegli **Create Task**, seleziona `validateQuantity` e scrivi l’intento “Verificare le quantità intere da 1 a 10 con casi indipendenti.” Premi **Next** dopo ogni scelta o campo. Controlla **Review Your Changes**, premi **Apply Changes** e salva. Riapri il task e scegli **Add Clarification**. Registra la domanda “Qual è il massimo incluso?” e la risposta “10. Il caso 11 deve risultare Not Satisfied.” Applica e salva il chiarimento. La prossima review userà anche questa decisione.

In **Code > Automatic Preparation** premi **Start or Stop Continuous Preparation** e inserisci il budget, per esempio `1`. Se compare il dialogo, premi **Enable Preparation**. L’attività prepara review per le modifiche semantiche stabilizzate. Selezione, zoom e layout non consumano tentativi. Consulta il contatore dei job e lo stato. Per sospendere, usa di nuovo **Start or Stop Continuous Preparation** e verifica **Paused**. Anche il cambio di progetto interrompe l’attività corrente.

Questa modalità prepara proposte, non le applica. Verifica e pubblicazione restano manuali. Un budget esaurito richiede una scelta esplicita; il riavvio non deve avviare da solo nuovi job.

**Controllo L20:** distingui modifiche semantiche e modifiche di layout, preparazione e applicazione, profilo dichiarato e runtime disponibile. La disponibilità di Bun, di un provider o di una connessione esterna è un prerequisito da verificare, non un risultato garantito dall’apertura della cartella.


### L21. Consegna il progetto a un’altra persona

Dopo aver salvato viste, decisioni e prove locali, prepara una consegna che permetta di ricostruire acquisto e reso.

Riapri Mercato e usa navigazione e ricerca per trovare **Cliente**, **Ordine**, conferma e richiesta di reso. Se hai un collega disponibile, fagli ripetere il percorso in autonomia e registra il suo riscontro.

Raccogli l’intera cartella di Mercato, inclusa `.ade`, i moduli pertinenti e un riepilogo di prove e decisioni aperte. Riapri la copia con **Open Project** per controllarne i riferimenti. Escludi cache, credenziali e cronologie del provider. Commit e pubblicazione sono facoltativi.

| Risultato da consegnare | Come lo dimostri |
| --- | --- |
| Modello salvato e riapribile | Chiudi, riapri e raggiungi una vista per ciascuna notazione |
| Due feature collegate senza duplicati | Segui Ordine dall’acquisto al reso e consulta l’impatto |
| Architettura comprensibile | Distingui contesto, container, componenti, package e deployment |
| Dati coerenti | Leggi cardinalità, chiavi e mapping fra identità distinte |
| Comportamento quantitativo verificato | Review corrente, casi indipendenti, Apply e Undo locali |
| Interazioni e policy dichiarate | Casi, tracce di stati e scenario messaging |
| Rapporto con i sorgenti | File aperti dalle evidenze e test tecnici eseguiti |
| IA usata consapevolmente, se disponibile | Perimetro, review, diff e prove; altrimenti indicazione non eseguita |

Per editor, terminale, Git, debug e accessibilità consulta A2-A7.


## Parte III - Atlante dei 16 diagrammi

Consulta questa parte quando devi scegliere come rappresentare una domanda o correggere una vista che mescola scopi diversi. D0 ti indirizza alla notazione pertinente; i capitoli successivi spiegano il significato delle scelte che nel laboratorio hai eseguito con i form. Non serve ripercorrerli tutti per continuare il lavoro.

### D0. Scegli la prospettiva e leggi i simboli

Una domanda di progetto richiede una prospettiva adatta. Come scegliamo fra le sedici notazioni? Come leggiamo elementi, frecce e condizioni, e riusiamo il modello senza creare duplicati? Quali dettagli vanno dichiarati oltre al disegno?

Prima di aggiungere una vista chiarisci la domanda e il pubblico. Usa la tabella per scegliere da dove partire; consulta poi il capitolo indicato per simboli, procedura e limiti. Non occorre creare tutte le viste per ogni feature.

| Domanda da chiarire | Vista da consultare | Capitolo |
| --- | --- | --- |
| Chi collabora e quale responsabilità ha? | Structure | D1 |
| Qual è il confine del prodotto, come si divide e cosa contiene un’applicazione? | C4 Context, Container, Component, dal generale al dettaglio | D2–D4 |
| Quali dati esistono e come saranno conservati? | ERD per il dominio; Database Schema per tabelle e chiavi | D5–D6 |
| Chi chiama chi e in quale ordine? | Sequence | D7 |
| Quali passi e alternative portano al risultato? | Activity / Flowchart | D8 |
| Quali eventi cambiano lo stato di una risorsa? | State Machine | D9 |
| Dove sono collocate le parti e come comunicano? | Deployment per gli host; Network per connessioni e protocolli | D10; D16 |
| Come organizzo tipi, contratti e moduli? | Class, UML Component e Package, secondo il livello | D11; D13–D14 |
| Quale obiettivo raggiunge un attore? | Use Case | D12 |
| Quali dati entrano, vengono trasformati e sono conservati? | Data Flow | D15 |

C4 descrive l’architettura per livelli di dettaglio. UML (Unified Modeling Language) è il linguaggio di modellazione da cui provengono, fra le altre, le viste di classi e casi d’uso. ERD (Entity–Relationship Diagram) indica il diagramma di entità e relazioni. ADE offre i sottoinsiemi descritti nei capitoli seguenti.

#### La procedura comune, senza modello testuale

1. Apri la root del progetto in cui vuoi conservare la vista. Clicca il nome del diagramma e scegli **Add Diagram**. Nel Mercato scegli la feature richiesta dal form: Acquisto per le viste generali, Resi e rimborsi per quelle dedicate. L’associazione permette di ritrovare il diagramma sotto la capacità che descrive. Per C4 con un soggetto segui invece il punto 3.
2. Nel form **Create Diagram** compila **Name** e scegli la notazione da **Diagram Type**. Imposta **Choose Feature** quando serve, poi premi **Create**.
3. Per **C4** segui L3. Apri **Structural Blueprint > Structure > C4 View Subject and Context**, premi **New C4 View** e imposta nome, livello, soggetto, contesto e visibilità. **Apply to Model** crea la vista e **Open Diagram** la apre. L1 è Context, L2 Container, L3 Component. Il soggetto resta visibile. L4 Contract definisce il perimetro di un contratto tramite la vista Class.
4. Per **State Diagram** scegli anche **Resource Whose State Is Represented** nel form di creazione. Gli stati descrivono il ciclo di vita della risorsa scelta. Per gli altri tipi crea gli oggetti nuovi con **Add Element** o riusa quelli già definiti con **Add Existing Element**.
5. Per includere una relazione già esistente, aggiungi entrambi gli estremi e usa **Diagram > Contents > Add Existing Relationship**. Sequence usa **Add Existing Message**. State offre **Add Existing Transition**. Per una relazione nuova compila **Create Relationship** con gli estremi, il tipo e il nome. Compila **Condition (Optional)** quando serve e premi **Save Changes**. In una sequenza includi i messaggi nell’ordine dichiarato.
6. Completa proprietà, confini e dettagli. Salva e riapri per controllare che il lavoro sia conservato; usa Read Diagram o la vista accessibile per leggere anche informazioni che il canvas sintetizza, come condizioni, membri e protocolli.

Per correggere una vista C4, aprila e usa **Diagram > Contents > Edit Visible Elements** o **Edit Context Dependencies**. Le stesse azioni sono disponibili in **Diagram Options**. Nel Blueprint controlla le spunte e premi **Apply to Model**. **Filter Elements** cerca per nome, tipo o proprietario. **Context** dichiara le dipendenze esterne al soggetto. **Visible** sceglie gli elementi che compaiono nel diagramma. Per mostrare una dipendenza di contesto, spunta anche **Visible**.

Se una vista C4 mostra **Draft Needs Correction**, apri **Structural Blueprint > Structure > C4 View Subject and Context** e scegli la vista in **Configuration**. **subjectAndScopeRequired** indica un perimetro mancante e **subjectNotVisible** un soggetto assente dal diagramma. Imposta livello e soggetto per ripristinare il perimetro e la sua visibilità. Premi **Apply to Model** e salva.

#### Gli elementi: vocabolario condiviso

Il testo del tipo sulla scheda è più affidabile del solo colore. Le forme aiutano la lettura, ma ADE non riproduce ogni convenzione grafica dei linguaggi originali. I picker filtrano i tipi compatibili; la tabella spiega il vocabolario complessivo, non suggerisce di inserire ogni tipo in ogni vista.

| Elemento | Significato e confine d’uso |
| --- | --- |
| Feature | Capacità organizzativa del progetto, ad esempio Resi; raggruppa prospettive, non equivale a un servizio |
| Actor | Ruolo esterno o soggetto che interagisce, ad esempio Cliente; non una specifica persona registrata |
| System | Sistema governato o sistema esterno; il suo scope distingue ciò che progetti da ciò da cui dipendi |
| Container | Applicazione/client, servizio, archivio o messaggistica distribuibile; in C4 non significa necessariamente container Docker |
| Component | Responsabilità interna, ad esempio Checkout; il contenimento dice a quale applicazione appartiene |
| Resource | Oggetto di dominio con identità, contratti o lifecycle, ad esempio Ordine; non è automaticamente una tabella |
| View / Interface della UI | Interfaccia del sistema, come Pagina resi; è un oggetto del prodotto, distinto dal diagramma aperto nell’IDE |
| Controller | Coordinamento di richieste o comportamento; non necessariamente una classe concreta del framework |
| Contract | Definizione condivisa del contratto; può essere collegata al provider e alle operazioni |
| Interface Contract | Interfaccia con membri/operazioni; distinta dalla pagina visuale del prodotto |
| Action | Attività espressa da un verbo; rappresenta qualcosa che accade |
| State | Condizione stabile di una risorsa, espressa di solito con un nome/aggettivo; rappresenta come si trova l’oggetto |
| Entity | Concetto logico dei dati e suoi attributi; indipendente dalla tabella fisica |
| Table | Struttura fisica progettata, con colonne, chiavi e vincoli dichiarati |
| Class | Tipo del progetto software con attributi e metodi; non ogni classe deve diventare un componente |
| Package | Modulo/layer logico non distribuibile; organizza dipendenze del software |
| Deployment Node | Ambiente/nodo che ospita applicazioni o artifact; ne dichiara la collocazione |
| Artifact | Prodotto distribuibile, ad esempio un bundle o modulo; non il ruolo dell’applicazione in sé |
| Network Node | Nodo o confine di connessione; descrive una parte della rete progettata |
| Use Case | Obiettivo/capacità dal punto di vista di un attore; non una singola schermata |
| Process | Trasformazione dei dati in un Data Flow; non implica un processo del sistema operativo |
| Data Store | Archivio nella prospettiva dati o infrastrutturale; può essere logico senza specificare un DBMS |
| Decision | Punto in cui il flusso sceglie in base a condizioni; le uscite devono chiarire le alternative |
| Start | Punto iniziale di un flusso di attività |
| End | Termine dichiarato di un flusso di attività |

#### Come leggere un collegamento

**Invocation** va da chi invoca a chi riceve; **Read/Write** da chi legge/scrive alla risorsa; **Dependency** da chi dipende a ciò che usa. **Transition** collega stato origine e destinazione; **Control Flow** ordina il percorso fra attività. **Data Flow** indica il trasferimento di un dato e deve nominarlo. **Communication** descrive una comunicazione architetturale o di rete, eventualmente con protocollo. **Hosts** va dal nodo ospitante all’oggetto ospitato.

**Association** esprime un legame strutturale; le molteplicità ai due estremi ne precisano il numero consentito. **Composition** e **Aggregation** qualificano un rapporto tutto/parte; **Inheritance** va dal tipo specializzato al generale; **Implementation** dall’implementazione al contratto. Per **Include/Extend** vedi D12. La freccia e il suo testo non sono una prova di esecuzione né un binding completo fra porte e operazioni.

Una **condizione testuale** spiega quando una relazione vale. Una **guardia eseguibile** è invece un’espressione tipizzata nel contratto pertinente. Un **protocollo** dichiara come comunicare; non dimostra una connessione. Una **cardinalità** dichiara quantità ammesse; non conta le istanze correnti. Mantieni queste distinzioni mentre leggi i capitoli seguenti.

### D1. Structure: la mappa delle responsabilità

Per capire una feature serve una prima mappa. Quali responsabilità collaborano, da dove entra la richiesta e quale risultato producono? Come distinguiamo una chiamata, un accesso ai dati e una dipendenza?

#### Quando e perché usarla

Usa Structure come prima mappa di una feature o come panoramica trasversale. È utile all’avvio di un progetto e quando devi orientare chi entra in una codebase. Il livello è flessibile: scegli uno scopo e mantienilo. Una panoramica con ogni funzione, tabella e file diventa rapidamente illeggibile.

Nel riferimento apri **01 Panoramica delle responsabilità**. Il Cliente usa Web shop; il web invia l’acquisto a Checkout; Checkout chiede l’autorizzazione e registra Ordine. Gestione resi dipende da Checkout per consultare l’acquisto. La vista sintetizza responsabilità, non la cronologia completa delle chiamate.

![Structure: persone, applicazioni, responsabilità e risorsa](immagini/atlante-01.png)

#### Elementi e dettagli

| Elemento utile | Come impiegarlo nel diagramma |
| --- | --- |
| Actor | Ruolo che avvia o usa la capacità; Cliente è uno solo anche se compare in altre feature |
| Component / Controller | Responsabilità e coordinamento; il nome deve dire cosa fa, non soltanto “Manager” |
| Resource | Dato/oggetto centrale con identità; Ordine è distinto dal suo schermo e dalla tabella |
| Interface / View | Punto d’interazione, come una pagina o un’interfaccia del sistema |
| System / Container | Contesto esterno o applicazione, quando il perimetro della panoramica lo richiede |
| Contract e altri tipi compatibili | Dettagli mirati da introdurre solo se aiutano a leggere responsabilità e vincoli |

Dalle proprietà usa la descrizione per chiarire cosa fa l’elemento e il contenimento per dichiarare a quale parte appartiene: il nome e la vicinanza grafica possono lasciare queste informazioni ambigue. I contratti possono precisare input, output, condizioni ed errori; formalizzali quando serve un accordo più preciso fra chi chiama e chi risponde. Le categorie avanzate del picker servono a raggiungere tipi meno frequenti, non a riempire il diagramma.

#### Collegamenti, costruzione e controllo

Usa Invocation per la richiesta, Read/Write per l’accesso alla risorsa, Dependency per l’uso strutturale. Nella panoramica Mercato la registrazione è un Write condizionato al pagamento autorizzato. Se la relazione descrive solo una dipendenza non chiamarla “esegue” per suggerire un ordine temporale che non hai dichiarato.

Segui D0, crea una Structure e aggiungi Cliente, Web shop, Checkout e Ordine; collega il percorso, poi introduci pagamento e resi. È un ordine consigliato per rendere leggibili ingresso, coordinamento e risultato prima di ampliare il contesto; puoi costruire gli stessi collegamenti in un altro ordine. Riusa le identità esistenti per mantenerne condivisi nome e dettagli. Per l’ordine delle chiamate aggiungi Sequence; per il confine del prodotto passa a C4 Context.

**Controllo:** un nuovo lettore sa trovare l’ingresso, chi coordina e il risultato. Evita duplicati omonimi, frecce senza significato e mescolanza di livelli non spiegata. Rimuovere dalla vista una responsabilità condivisa non deve eliminarla dal sistema.

### D2. C4 System Context: il confine del prodotto

Prima dei dettagli tecnici serve un confine condiviso. Che cosa comprende il nostro prodotto e chi lo usa? Da quali sistemi esterni dipende, e come rendiamo riconoscibile ciò che governiamo?

#### Quando e perché usarlo

Usa il Context con stakeholder, nuovi membri del team e nelle discussioni sul perimetro. Aiuta a chiarire responsabilità e confini prima di entrare nei dettagli tecnici. Il [riferimento C4 sul Context](https://c4model.com/diagrams/system-context) pone al centro un sistema e il suo ambiente.

Apri **02 C4 Contesto Mercato**: Mercato è il soggetto governato; Cliente e Assistenza sono ruoli; Pagamenti esterni e Corriere esterno sono sistemi di contesto. La vista racconta cosa il negozio deve fare e dove finisce il suo controllo.

![C4 Context: Mercato, persone e sistemi esterni](immagini/atlante-02.png)

#### Elementi

| Elemento | Significato e dato da curare |
| --- | --- |
| Sistema soggetto | Un solo sistema al centro dell’analisi; nome e descrizione esprimono il prodotto |
| Actor | Ruolo umano o soggetto che usa il sistema; Cliente e Assistenza hanno obiettivi diversi |
| External Software System | Sistema non governato qui; pagamento e consegna non diventano codice interno perché compaiono nella vista |
| Contesto dichiarato | Identità esterne ammesse nel perimetro della vista; non una seconda ownership |

Non inserire API, classi o tabelle per colmare spazio. Il tipo System distingue governato ed esterno; il soggetto è impostato dal blueprint. La presenza come contesto non autorizza la generazione o modifica del sistema esterno.

#### Collegamenti e uso in ADE

Communication o Dependency devono descrivere un rapporto comprensibile al lettore: “autorizza e rimborsa”, “richiede consegna”. La direzione segue chi usa/richiede l’altro sistema. Se la comunicazione è bidirezionale, chiarisci la responsabilità con nomi e collegamenti pertinenti invece di presumere che ogni freccia significhi entrambe le direzioni.

Crea il Context da **C4 View Subject and Context > New C4 View** come in L3 e D0. Scegli L1, indica Mercato come soggetto e imposta il nome. In **View Contents** seleziona i quattro oggetti di contesto e rendili visibili. Crea prima gli attori o i sistemi che ti mancano. Premi **Apply to Model** e **Open Diagram**, aggiungi le relazioni e salva.

**Controllo:** esiste un perimetro unico; i due attori sono distinguibili dai sistemi; nessun componente interno compete con il prodotto per la stessa gerarchia. Se vuoi sapere come Mercato è suddiviso, apri D3. Un Context non rappresenta una topologia di rete né osservazioni di traffico reale.

### D3. C4 Container: applicazioni e archivi

Definito il prodotto, dobbiamo suddividerlo in parti realizzabili. Quali applicazioni, servizi e archivi lo compongono? Come ne dichiariamo responsabilità, appartenenza e comunicazioni senza confonderli con gli host di esecuzione?

#### Quando e perché usarlo

Usa questa vista per discutere responsabilità distribuibili, tecnologia e confini fra client, servizio e persistenza. Nel lessico C4 un container è un’applicazione o un archivio: non presuppone Docker. Il [riferimento C4 Container](https://c4model.com/diagrams/container) distingue questo livello dalla distribuzione fisica.

In **03 C4 Applicazioni e dati** il sistema Mercato comprende Web shop, API Mercato, Archivio Mercato e Broker eventi; il Cliente resta contesto. Sono scelte progettate per l’esempio, non processi rilevati sul computer.

![C4 Container: applicazioni e dati entro il sistema](immagini/atlante-03.png)

#### Elementi

| Elemento | Uso corretto |
| --- | --- |
| Sistema soggetto/confine | Il sistema che possiede i container; deve essere visibile nella configurazione |
| Application / Container | Applicazione web o mobile, servizio, archivio o messaggistica; assegna responsabilità e runtime pertinenti |
| Data Store | Archivio dichiarato, se è il ruolo che vuoi rappresentare; evita un duplicato del container store già esistente |
| Resource | Risorsa di contesto ammessa dal picker; usala se chiarisce una dipendenza di dominio |
| Actor / External Software System | Contesto che usa o è usato dalle applicazioni, conservando lo scope esterno |

L’ownership è un dato del blueprint: dichiara che le parti interne appartengono a Mercato e permette di distinguerle dalle dipendenze esterne anche in altre viste. Trascinarle nel rettangolo non assegna il proprietario. Tecnologia e ambiente vanno dichiarati solo se conosciuti o esplicitamente progettati.

#### Collegamenti, procedura e controllo

Le comunicazioni di Mercato sono HTTPS dal Cliente al Web shop, HTTPS / JSON dal web all’API, SQL dall’API all’archivio e una pubblicazione verso il broker. Il nome della freccia esprime l’intento; il protocollo esprime il mezzo dichiarato. Se due oggetti sono collegati solo per dipendenza architetturale, non inventare protocollo o porta.

Nel Blueprint assegna i quattro container a Mercato con **Architectural or Lifecycle Owner** e completa i ruoli come in L4. Crea la vista C4 di livello L2 con soggetto Mercato, contesto Cliente e visibilità per Cliente e i quattro container. Il soggetto compare automaticamente. Premi **Apply to Model** e **Open Diagram**, poi collega gli elementi per dichiarare le integrazioni. Leggi D4 per il dettaglio dell’API e D10 per la collocazione.

**Controllo:** ogni container ha una responsabilità e un proprietario; applicazione e host restano distinguibili; un archivio non appare due volte come se fossero due sistemi reali. La vista non esegue installazioni, provisioning, comunicazioni o migrazioni.

### D4. C4 Component: l’interno di un’applicazione

Un’applicazione può racchiudere responsabilità diverse. Quali componenti organizzano l’interno dell’API e quali contratti offrono? Come distinguiamo le parti interne dalle dipendenze esterne al container scelto?

#### Quando e perché usarlo

Usa C4 Component quando il livello applicazioni è troppo generico per discutere responsabilità, dipendenze e contratti. Non occorre un diagramma per ogni applicazione: il [riferimento C4 Component](https://c4model.com/diagrams/component) suggerisce di usarlo quando aggiunge valore alla comunicazione.

La vista **04 C4 Componenti API** sceglie API Mercato come soggetto. Checkout, Registro esiti, Gestione resi e Scorte ne sono responsabilità interne. Scorte gestisce la disponibilità a livello applicativo; Archivio Mercato è invece la persistenza. Contratto acquisto appartiene anch’esso ad API Mercato ed è fornito da Checkout. Leggi l’ownership e il binding, non dedurli solo dalla posizione.

![C4 Component: responsabilità dell’API e contratto fornito da Checkout](immagini/atlante-04.png)

#### Elementi e ownership

| Elemento | Come interpretarlo |
| --- | --- |
| Container soggetto | L’applicazione di cui stai mostrando l’interno; qui API Mercato |
| Component | Responsabilità interna, come Checkout e Registro esiti |
| Controller | Coordinamento interno quando tale ruolo è più preciso del generico componente |
| Resource | Oggetto/risorsa necessario al dettaglio, senza convertirlo automaticamente in classe o tabella |
| Contract / Interface Contract | Contratto condiviso o interfaccia delle responsabilità; operazioni e tipi si completano nel blueprint |
| Context Container e altre dipendenze ammesse | Oggetti esterni al soggetto, dichiarati nel contesto invece di riassegnarli al container |

La soluzione formalizza Contratto acquisto versione 1 e Checkout come provider nel blueprint (L11): così il contratto ha un fornitore esplicito e i controlli possono leggere la firma offerta. La dipendenza verso Scorte non implica un ulteriore binding.

#### Collegamenti e uso

Dependency “richiede disponibilità” collega Checkout a Scorte; Communication “registra esito” lo collega a Registro esiti; Implementation esprime l’esposizione del Contratto acquisto; Gestione resi dipende da Checkout. Queste relazioni descrivono il rapporto; il controllo di compatibilità fra operazioni richiede porte, tipi e binding espliciti.

Nel Blueprint assegna i componenti ad API Mercato con **Architectural or Lifecycle Owner**, come in L4. Crea la vista C4 di livello L3 e scegli API Mercato come soggetto. Imposta **Context** e **Visible** secondo il perimetro che vuoi mostrare, poi premi **Apply to Model** e **Open Diagram**. Salva e controlla il confine anche in lettura testuale.

**Controllo:** nessun componente diventa un container solo per cambiare forma; nessuna dipendenza esterna viene trascinata nel sistema governato. Se il problema è l’interfaccia fra moduli piuttosto che il perimetro di un’applicazione, usa anche UML Component (D13).

### D5. ERD: concetti, attributi e cardinalità

Prima delle tabelle dobbiamo concordare il significato dei dati. Quali concetti hanno un’identità propria e quali attributi li descrivono? Quanti oggetti possono essere collegati, e quali regole esprimono le cardinalità?

#### Quando e perché usarlo

Usa l’ERD per concordare il dominio prima di decidere nomi di tabelle o dettagli del database. È utile quando due persone danno significati diversi alla stessa parola: un ordine, una sua riga e una richiesta di reso hanno identità e vincoli differenti.

Apri **05 Entità e cardinalità**: Cliente, Ordine, Riga ordine, Prodotto e Reso mostrano attributi essenziali. L’ERD del laboratorio è logico; non sostiene che esista già un database con quella struttura.

![ERD: entità logiche, attributi e quantità ammesse](immagini/atlante-05.png)

#### Elementi e membri

| Elemento/dettaglio | Significato |
| --- | --- |
| Entity | Concetto logico con identità, come Prodotto; scegli nomi singolari coerenti |
| Resource | Risorsa ammessa dalla notazione, utile se già definita; decidi se è davvero lo stesso oggetto prima di riusarla |
| Attributo | Dato caratteristico dell’entità: quantity appartiene alla Riga ordine, non al Prodotto |
| Tipo | Dominio del valore; testo e intero sono diversi anche quando il valore visualizzato è “42” |
| Presenza e nullabilità | Campo richiesto/facoltativo e valore null ammesso/vietato sono due proprietà distinte |

Un attributo non deve diventare una nuova entità solo per comparire. Viceversa una lista di righe con quantità e prezzo proprio merita un’entità distinta: inserirla come testo libero dentro Ordine nasconde i vincoli.

#### Legami e cardinalità

Association nomina un legame; ove pertinenti la notazione ammette rapporti tutto/parte. Per il laboratorio usa associazioni esplicite. **1** significa esattamente uno; **0..1** nessuno oppure uno; **0..\*** zero o più; **1..\*** uno o più. Il numero vicino a un’entità indica quante istanze di quella entità possono corrispondere all’oggetto all’altro estremo.

“Cliente 1 - Ordine 0..\*” significa che ogni ordine ha un cliente e ogni cliente può avere più ordini. “Riga ordine 0..\* - Prodotto 1” significa che una riga riguarda un prodotto e un prodotto può apparire in molte righe. Il legame Reso verso Ordine dichiara che il reso non è indipendente dall’acquisto.

Crea Entity e membri dalle proprietà per distinguere gli oggetti e i dati che li descrivono, poi collega le identità e modifica le cardinalità. **Controllo:** leggi ogni associazione in entrambe le direzioni: verificare solo quanti ordini ha un cliente lascerebbe aperto a quanti clienti può appartenere un ordine. Se una regola non è ancora decisa, segnalala invece di scegliere 1 per comodità. Non interpretare una molteplicità come vincolo già eseguito su record reali; lo schema fisico è D6.

### D6. Database Schema: tabelle e vincoli progettati

I concetti del dominio devono trovare una rappresentazione nella persistenza. Quali tabelle, colonne e chiavi servono? Come indichiamo la destinazione di un riferimento e colleghiamo i campi del dominio alle colonne progettate?

#### Quando e perché usarlo

Usa questa vista dopo aver chiarito il dominio o durante la lettura di schema e migrazioni esistenti. Una proposta di schema deve essere distinta da uno schema verificato sui sorgenti. In Mercato è un progetto didattico SQL, senza DBMS distribuito.

Apri **06 Schema dati progettato**. Le tabelle customers, orders, order_lines, products e returns sono identità differenti dalle cinque entità logiche, anche quando il loro significato è collegato.

![Database Schema: colonne, chiavi e riferimenti](immagini/atlante-06.png)

#### Elementi e colonne

| Elemento/dettaglio | Come usarlo |
| --- | --- |
| Table | Tabella fisica progettata; nome coerente con le convenzioni del progetto |
| Colonna e tipo | Campo memorizzato e dominio del valore; total_cents intero documenta l’unità monetaria scelta |
| Primary key (PK, chiave primaria) | Identifica una riga nella tabella; il diagramma ne dichiara il ruolo |
| Foreign key (FK, chiave esterna) | Colonna di riferimento; indica anche la colonna di destinazione |
| Unique | Valore o vincolo univoco dichiarato, ad esempio sku; non sostituisce automaticamente la PK |
| Field Presence / Nullability | Presenza richiesta o facoltativa e valore null ammesso o vietato sono scelte distinte |
| Data Store / Resource | Archivio o risorsa di contesto ammessi; un archivio può fare da confine facoltativo |

I membri si modificano con Edit Attributes and Technology. Dichiara i tipi delle colonne come in L5; i tipi condivisi e i mapping di L11 collegano poi persistenza e contratto. Così puoi cambiare la rappresentazione fisica mantenendo esplicita la corrispondenza con il dominio. ADE non deduce un DBMS da un’etichetta SQL generica.

#### Riferimenti e procedura

Le associazioni fra tabelle indicano le colonne ai due estremi: orders.customer_id punta a customers.id; order_lines.order_id a orders.id; order_lines.product_id a products.id; returns.order_id a orders.id. Seleziona la relazione e apri **Edit Cardinalities and Protocol**. Compila nell’ordine **Source Multiplicity**, **Target Multiplicity**, **Source Attribute / Column**, **Target Attribute / Column** e **Protocol / Transport**, confermando ciascun campo con Invio. Per i quattro riferimenti usa `0..*` e `1`; digita il nome della colonna origine e poi `id`, senza il prefisso della tabella; lascia vuoto il protocollo. Una freccia chiamata customer_id senza colonne corrette non documenta una FK completa. Il procedimento completo è in L5.

Costruisci prima tabelle e colonne, poi associazioni e riferimenti: le colonne devono esistere perché la relazione possa indicare estremi validi. Verifica i nomi dei membri dopo una rinomina, così il riferimento continui a indicare la colonna prevista. Usa mapping espliciti per legare orderId del dominio a orders.id: conservi la corrispondenza anche quando i nomi e le rappresentazioni differiscono. Entità, tabella e classe mantengono le proprie identità.

**Controllo:** quattro riferimenti validi, PK riconoscibili, nullabilità dichiarata e unità dei valori comprensibili. Il diagramma non esegue DDL, migrazioni o query e non dimostra che il database attivo rispetti i vincoli. Per questo servono migrazioni e test d’integrazione del progetto.

### D7. Sequence: partecipanti e ordine delle interazioni

In un acquisto l’ordine delle interazioni può cambiare il risultato. Chi invia ogni richiesta, chi la riceve e quale condizione la abilita? Come ordiniamo i messaggi riusando gli elementi e i collegamenti già definiti?

#### Quando e perché usarla

Usa Sequence per una conferma d’acquisto, una richiesta di reso o un caso d’errore specifico. È utile quando un flusso sembra semplice ma il punto preciso di una lettura, scrittura o risposta cambia il risultato.

Apri **07 Sequenza acquisto**: Cliente richiede la conferma a Checkout; Checkout invoca Pagamenti esterni; poi scrive Ordine con condizione di autorizzazione. La sequenza sceglie un livello di coordinamento e semplifica il canale web. Non è una traccia temporale misurata in produzione.

![Sequence descrittiva: tre messaggi ordinati](immagini/atlante-07.png)

#### Elementi e messaggi

| Elemento | Significato |
| --- | --- |
| Partecipante | Identità che invia o riceve; attore, responsabilità, interfaccia o risorsa compatibile |
| Linea di vita | Colonna che mantiene riconoscibile il partecipante durante lo scenario; non implica un thread o processo dedicato |
| Messaggio | Interazione con origine, destinazione, tipo e nome; l’indice è l’ordine locale dichiarato |
| Read / Write | Accesso a una risorsa; distingue una consultazione da un aggiornamento |
| Condizione | Presupposto dichiarato del messaggio; la sua prosa non è ancora una guardia compilabile |
| Occorrenza / frame, nei modelli pertinenti | Un evento distinto o un gruppo comportamentale; chiamate ripetute non condividono automaticamente lo stesso risultato |

Riusa i partecipanti con **Add Existing Element** e i collegamenti con **Add Existing Message** per descrivere lo scenario con le responsabilità e le condizioni già definite. Seleziona il partecipante e usa **Move Participant Left** o **Move Participant Right** nelle proprietà per disporre le colonne in modo leggibile. Nelle stesse proprietà apri **Sequence Message Options** del collegamento pertinente e usa **Move Message Earlier** o **Move Message Later** per cambiare l’ordine progettato delle interazioni. Lo spostamento grafico non sostituisce questi comandi. Salva e controlla l’ordine nella lettura testuale: l’autorizzazione deve precedere la registrazione dell’ordine.

#### Descrittiva ed eseguibile

Nel modello descrittivo v5 le occorrenze distinguono chiamate, alternative e vincoli d’ordine dichiarati. Nel modulo eseguibile di L13 ogni chiamata dichiara operazione, argomenti, sincronismo, risultati, errori e risposta simulata. I frame alt, opt, loop, par, critical e ref hanno contratti e limiti propri. Non disegnare una guardia testuale aspettandoti che diventi automaticamente un ramo verificabile.

Crea la vista, riusa i quattro partecipanti, includi i tre messaggi e ordina esplicitamente. Per aggiungere un caso negativo, descrivilo come scenario distinto o con le strutture pertinenti: conferma e rifiuto non devono sembrare due passi sempre consecutivi dello stesso acquisto. Mantieni chiaro quale ordine è dichiarato e quale è sconosciuto.

**Controllo:** puoi leggere ogni freccia ad alta voce con mittente, destinatario, contenuto e condizione. Il tempo scorre dall’alto in basso nell’ordine dichiarato, ma la distanza verticale non misura millisecondi. Per decisioni indipendenti dai partecipanti usa Activity; per lo stato persistente dell’ordine usa State Machine.

### D8. Activity / Flowchart: passi e alternative

Una procedura deve spiegare anche che cosa accade quando qualcosa va storto. Quali passi portano dall’ingresso agli esiti possibili? Dove cambia il percorso e quali condizioni distinguono le alternative?

#### Quando e perché usarla

Activity / Flowchart è una sola notazione del catalogo ADE. Usala per discutere una procedura con persone di ruoli diversi, evidenziare esiti mancanti e definire cosa deve accadere prima di cosa. Non richiede di scegliere subito classi e servizi.

Apri **08 Flusso acquisto**: validazione, verifica disponibilità, pagamento, conferma/rifiuto e conclusione. Nel tour il flusso del rimborso è più piccolo, ma usa lo stesso principio: un’alternativa deve avere un significato leggibile.

![Activity: ingresso, azioni, decisione ed esiti](immagini/atlante-08.png)

#### Elementi

| Elemento | Come nominarlo e interpretarlo |
| --- | --- |
| Start | Ingresso della procedura, ad esempio Inizio; chiarisci il trigger nella descrizione |
| Action | Passo con un verbo: Valida carrello, Richiedi pagamento; non uno stato come “Pagato” |
| Decision | Domanda o scelta: Scorte disponibili?; ogni uscita deve dire quando è percorribile |
| End | Esito/termine del percorso; non lasciare sospesa una via negativa involontariamente |
| Responsabilità e risorse compatibili | Contesto aggiuntivo quando serve capire chi esegue o cosa viene usato; evita di farlo competere con il flusso |
| Control Flow | Collegamento che guida il percorso fra passi e decisioni |

Le frecce devono avere condizioni comprensibili: disponibili/non disponibili, autorizzato/rifiutato. Due uscite entrambe chiamate “continua” non chiariscono la scelta. Se le condizioni possono sovrapporsi, decidi priorità o esclusività nel contratto pertinente.

#### Costruzione e controllo

È consigliato costruire prima il percorso principale da Start a End, per riconoscerne ingresso e risultato, e poi aggiungere la decisione sulle scorte e il ramo di rifiuto. Collega entrambi gli esiti del pagamento, così anche il caso negativo raggiunge una conclusione. Questo ordine aiuta a controllare la completezza, ma non è un vincolo dell’editor. Usa la lettura testuale per seguire tutte le relazioni, anche quando il routing si incrocia. Spostare i nodi migliora la lettura, ma non definisce un’espressione o un ordine eseguibile.

L’Activity descrittiva non è automaticamente un workflow eseguibile. Per alternative, concorrenza, ripetizioni e sotto-interazioni verificabili usa i costrutti del profilo di L13: non inferire fork/join o temporizzazione da due frecce disegnate in parallelo.

**Controllo:** ogni ramo conduce a un esito intenzionale; azioni e stati hanno nomi diversi; una decisione ha condizioni che un lettore sa valutare. Se il problema è chi invia il messaggio, aggiungi Sequence; se è la condizione stabile dopo il passo, aggiungi State Machine.

### D9. State Machine: il ciclo di vita di una risorsa

Un’azione può essere ammessa solo in alcune fasi della vita di un ordine. Quali stati appartengono alla risorsa e quali eventi ne consentono il cambiamento? Come distinguiamo stati, transizioni e azioni, e controlliamo gli esiti negativi?

#### Quando e perché usarla

Usa State Machine per ordini, richieste di reso, prenotazioni e oggetti con azioni ammesse solo in alcune fasi. Aiuta a riconoscere transizioni illegali e differenze fra tentativo, autorizzazione e completamento.

Apri **09 Stati ordine**: la risorsa Ordine possiede In attesa, Confermato e Rifiutato. Il diagramma del tour per Richiesta di reso distingue invece Richiesto, Autorizzato, Rimborsato e Rifiutato. Sono lifecycle di risorse diverse, non un unico elenco di tutti gli stati del negozio.

![State Machine descrittiva: risorsa, stati e transizioni](immagini/atlante-09.png)

#### Elementi e dettagli

| Elemento/dato | Significato |
| --- | --- |
| Risorsa/proprietario lifecycle | L’oggetto di cui stai descrivendo il ciclo; deve essere esplicito |
| Stato | Condizione dell’oggetto, non attività; “Confermato” si distingue da “Conferma ordine” |
| Transizione | Passaggio da uno stato a un altro con evento/condizione pertinenti |
| Evento | Occorrenza che può attivare il passaggio; nel profilo eseguibile ha payload tipizzato |
| Guardia | Condizione che abilita la transizione; testuale nella descrizione, espressione formale nel contratto eseguibile |
| Azioni ed errori | Effetti associati al passaggio o al lifecycle, nei form e profili che li supportano |

Nel diagramma descrittivo gli stati sono figli della risorsa. Nel contratto eseguibile si dichiarano stato iniziale, finali, eventi, priorità, transizioni interne/esterne e azioni entry/exit/do. Una self-transition interna non ripete lo stesso ciclo di uscita e ingresso di una esterna.

#### Uso e verifica

Crea la State Machine scegliendo Ordine: tutti gli stati aggiunti con Add State devono appartenere al ciclo di vita di quell’oggetto. Collega le transizioni e nomina eventi ed esiti per chiarire che cosa permette un cambiamento e dove porta. Per provare se un evento viene accettato o rifiutato usa il contratto eseguibile, Edit Executable State Machine e i casi di L14; Simulate State Machine restituisce le fasi e lo stato finale da confrontare con gli attesi.

**Controllo:** tutti gli stati appartengono al lifecycle corretto; un ordine già confermato non torna in attesa senza un evento previsto; il caso negativo è modellato. La figura non osserva ordini vivi. Il profilo corrente supporta macchine piatte, senza stati compositi o regioni ortogonali. Se servono retry e consegne, completa la policy di messaggistica invece di inventare stati non motivati.

### D10. Deployment: dove collochiamo software e dati

Per preparare la distribuzione dobbiamo assegnare una collocazione alle parti del sistema. Quali nodi ospitano applicazioni, dati e artefatti? Come distinguiamo il software, il prodotto distribuibile e l’ambiente che lo esegue?

#### Quando e perché usarlo

Usa Deployment quando conta la collocazione: separazione del web e dell’API, persistenza, confini di ambiente, artefatti distribuiti. È una prospettiva diversa da C4 Container: un’applicazione descrive responsabilità; un host descrive collocazione.

Apri **10 Distribuzione locale progettata**. Host Web ospita Web bundle; Host API ospita API ESM e API Mercato; Host dati ospita Archivio Mercato. “Locale progettata” è parte del nome per mantenere visibile la natura didattica del disegno.

![Deployment: nodi ospitanti e parti ospitate](immagini/atlante-10.png)

#### Elementi e proprietà

| Elemento | Significato e attenzione |
| --- | --- |
| Deployment Node | Macchina, processo/ambiente o nodo di esecuzione dichiarato; specifica cosa rappresenta nel tuo progetto |
| Artifact | Prodotto distribuito, come bundle o modulo ESM; distinto dalla responsabilità applicativa |
| Container / applicazione | Parte del sistema ospitata; riusa l’identità architetturale quando è la stessa |
| Archivio / risorsa compatibile | Dati o servizio di persistenza collocati nel nodo pertinente |
| Ambiente e tecnologia | Informazioni dichiarate dell’oggetto; non indicare “produzione” o un cloud se non hai una decisione/evidenza |
| Hosts | Collegamento dall’ospitante all’ospitato; esprime collocazione, non invocazione |

I tipi meno comuni si trovano nelle categorie Architecture, Data e Infrastructure del picker. Non rappresentare un database come Artifact se intendi il servizio che persiste i dati; usa il ruolo pertinente e, se utile, un artefatto separato per la sua distribuzione.

#### Costruzione e controllo

Definisci gli host, aggiungi artifact e applicazioni esistenti e collega con Hosts: per ogni parte rendi così esplicito l’ambiente previsto per eseguirla o conservarla. Completa ambiente e tecnologia dalle proprietà per distinguere, per esempio, una collocazione didattica locale da una proposta per la produzione. Mantieni distinta l’ownership architetturale dalla collocazione dichiarata con Hosts: appartenere all’API e risiedere su Host API sono informazioni diverse. Spostare una scheda cambia il layout; non cambia da solo le responsabilità o i collegamenti.

**Controllo:** per ogni applicazione sai indicare il luogo previsto e distinguere nodo, software e dati. Non presentare un deployment progettato come inventario osservato. La vista non avvia servizi né fornisce provisioning o discovery. Per protocolli e confini di comunicazione usa anche Network (D16).

### D11. Class: tipi, membri e relazioni del software

Per realizzare il modello servono tipi software con responsabilità precise. Quali attributi e metodi appartengono a ciascun tipo? Come rappresentiamo interfacce, dipendenze ed ereditarietà senza confonderle con entità e tabelle?

#### Quando e perché usarlo

Usa Class per chiarire un dominio ricco, un’interfaccia o una collaborazione fra pochi tipi. Non copiare automaticamente ogni classe del repository: un diagramma con centinaia di dettagli non aiuta a prendere decisioni.

Apri **11 Classi e repository**. CheckoutService dipende da Order e da OrderRepository; Order contiene orderId, totalCents e confirm; l’interfaccia espone save. Il risultato testo dei metodi è illustrativo; il contratto eseguibile completo deve usare input e risultati tipizzati nel blueprint.

![Class: tipi, attributi, metodi e interfaccia](immagini/atlante-11.png)

#### Elementi e compartimenti

| Elemento/dettaglio | Interpretazione |
| --- | --- |
| Class | Tipo concreto o progettato; nome distinto dall’istanza di dominio |
| Interface Contract | Contratto che un’implementazione può fornire; stesso oggetto riusabile in UML Component |
| Attributo | Dato del tipo, con nome, tipo, obbligatorietà e nullabilità pertinenti |
| Metodo | Operazione esposta dal tipo; nome e tipo/firma dichiarati, con ruolo Method |
| Tecnologia e ambiente | Contesto dichiarato della rappresentazione; non trasformano da soli il disegno in sorgente |

Usa **Edit Attributes and Technology** per aggiungere o rimuovere membri. Per correggerne uno selezionalo nell’elenco e scegli **Edit Member**. Distingui Attribute e Method: puoi dichiarare più metodi con lo stesso nome se le firme differiscono, ma una firma identica viene rifiutata. Nel laboratorio inserisci confirm, submit e save come nomi, senza le parentesi già visualizzate dal canvas.

#### Collegamenti

Association descrive un legame; Dependency un uso. Inheritance va dalla classe specializzata al tipo generale; Implementation dall’implementazione all’interfaccia. Composition rappresenta una relazione tutto/parte forte legata al ciclo di vita; Aggregation una relazione tutto/parte più debole. Sceglile per il significato, non per abbellire il collegamento. Le molteplicità descrivono quanti oggetti possono partecipare.

Crea le due classi e l’interfaccia, aggiungi i membri per chiarire i dati e le operazioni che espongono, poi le dipendenze per mostrare quali tipi usano. Confronta l’Order di questa vista con l’entità e la tabella: descrivono livelli diversi, quindi collegali con mapping espliciti quando serve seguirne la corrispondenza. Il nome simile non basta a renderli lo stesso oggetto.

**Controllo:** ogni membro è nel tipo giusto; una dipendenza non viene scambiata per ereditarietà; le firme sono leggibili. La figura non analizza automaticamente ogni differenza del codice e non implementa metodi. L’importazione e le evidenze di L16 sono il percorso per confrontare la descrizione con i sorgenti reali.

### D12. Use Case: obiettivi degli attori

Il progetto deve offrire risultati utili a chi lo usa. Quali obiettivi raggiunge ciascun attore e a quale sistema appartengono? Come distinguiamo un comportamento sempre necessario da un’aggiunta opzionale?

#### Quando e perché usarlo

Usa Use Case per concordare il perimetro funzionale con utenti e stakeholder, prima di progettare le schermate: “Richiedere reso” è un obiettivo; “aprire la terza modale” è una scelta d’interfaccia.

Apri **12 Casi d’uso**. Cliente può confermare un acquisto e richiedere un reso; Assistenza gestisce il reso. Il pagamento è incluso nella conferma, mentre il coupon estende la conferma solo quando presente. Quest’ultimo è un esempio progettato opzionale, non codice già pronto nel pacchetto.

![Use Case: attori, obiettivi, inclusione ed estensione](immagini/atlante-12.png)

#### Elementi

| Elemento | Uso |
| --- | --- |
| Actor | Ruolo che partecipa all’obiettivo; una persona può ricoprire più ruoli |
| Use Case | Capacità con un risultato per l’attore, chiamata con verbo e oggetto |
| Software System / confine | Sistema cui appartengono i casi; distingue interno ed esterno |
| Association | Partecipazione dell’attore; non è un ordine temporale di esecuzione |
| Include | Dal caso base al comportamento sempre incluso |
| Extend | Dal comportamento aggiuntivo verso il caso base, con condizione di estensione |

Il proprietario dei casi è Mercato. Gli attori rimangono esterni al confine del prodotto anche se le loro schede sono vicine. Se il diagramma non mostra il confine come scheda, consulta il contenimento nelle proprietà e nella lettura testuale.

#### Procedura e significato delle frecce

Aggiungi i due attori esistenti e i quattro casi. Associa Cliente a Confermare acquisto e Richiedere reso, Assistenza a Richiedere reso, per chiarire chi partecipa a ciascun obiettivo. Disegna Include da Confermare acquisto ad Autorizzare pagamento perché l’autorizzazione è necessaria. Disegna Extend da Applicare coupon a Confermare acquisto e assegna “coupon presente” perché l’aggiunta vale solo in quella condizione. Invertire quest’ultima freccia inverte chi estende chi.

I nomi sono centrati negli ovali, le cui dimensioni si adattano al contenuto. Dopo una modifica usa **Diagram > Arrange** e **Fit Diagram** per riordinare la vista. Include ed Extend descrivono necessità e opzionalità. Activity e Sequence descrivono l’ordine dei passi. I contratti e i casi Given/When/Then dichiarano requisiti verificabili.

**Controllo:** ogni caso rappresenta un obiettivo e ha un attore o un rapporto funzionale motivato; le azioni interne al database non compaiono come obiettivi del Cliente. Chiarisci le eccezioni nelle descrizioni o nei flussi complementari, senza inserire nel diagramma ogni piccolo passo dell’interfaccia.

### D13. UML Component: responsabilità e contratti

Più componenti possono collaborare attraverso contratti condivisi. Chi fornisce ciascuna interfaccia e chi la usa? Come riusiamo lo stesso contratto nelle viste e distinguiamo una freccia grafica da un collegamento formalizzato nel blueprint?

#### Quando e perché usarlo

Usa questa vista per discutere sostituibilità, contratti pubblici e dipendenze fra moduli. Si affianca a C4 Component: qui l’enfasi è sui rapporti fra componenti e interfacce, non sul dettaglio di un unico container soggetto.

Apri **13 Componenti e interfacce**. Checkout espone Contratto acquisto; Registro esiti fornisce OrderRepository. L’interfaccia è la stessa usata nella vista Class. La sua visualizzazione non è una seconda definizione.

![UML Component: implementazioni e contratti condivisi](immagini/atlante-13.png)

#### Elementi e binding

| Elemento | Ruolo nella vista |
| --- | --- |
| Component | Unità di responsabilità con un confine di interfaccia |
| Contract | Definizione condivisa del contratto, come Contratto acquisto |
| Interface Contract | Interfaccia con operazioni/membri, come OrderRepository |
| Application / Container | Contesto applicativo ammesso quando aiuta a collocare i componenti |
| Porte e operazioni nel blueprint | Interfacce richieste/fornite e binding effettivi da dichiarare separatamente dal solo collegamento grafico |

Il canvas usa i simboli offerti da ADE. Completa nel blueprint input, risultati, errori, effetti, permessi e criteri delle operazioni pertinenti (L11): chi usa il contratto deve conoscere dati richiesti, esiti ammessi e obblighi, oltre al nome dell’interfaccia.

#### Collegamenti e controllo

Implementation va dal componente che fornisce al contratto fornito; Dependency indica chi usa un contratto o un’altra responsabilità. La freccia “fornisce persistenza” di Registro esiti non dimostra che esista un adapter funzionante né che tipi e policy siano già compatibili.

Crea la vista e aggiungi le quattro identità esistenti. Usa **Diagram > Contents > Add Existing Relationship** per includere l’Implementation Checkout–Contratto acquisto e la Communication Checkout–Registro esiti, conservandone definizione e dettagli; poi crea l’Implementation Registro esiti–OrderRepository. Se vuoi controllare la compatibilità di un consumer con il provider, dichiara nel blueprint quale interfaccia è richiesta dal consumer, quale è fornita dal provider e come corrispondono operazioni e tipi. Consulta le diagnostiche prima della review per individuare dichiarazioni mancanti o incompatibili; la sola freccia non contiene questi accordi.

**Controllo:** il contratto appartiene al provider giusto; consumer e provider sono distinti; non confondi Interface Contract con Pagina acquisto. Se cambi una firma condivisa, consulta Show Change Impact e controlla i consumer per sapere quali chiamanti devono adeguarsi. Un diagramma può essere leggibile e salvabile pur non essendo ancora pronto alla generazione.

### D14. Package: moduli e direzione delle dipendenze

Il software va organizzato in gruppi con confini comprensibili. Quali moduli o layer scegliamo e da quali altri gruppi dipendono? Come leggiamo la direzione delle frecce e riconosciamo una dipendenza che introduce un ciclo?

#### Quando e perché usarlo

Usa Package per discutere layer, confini organizzativi e direzione delle dipendenze. È adatto anche a un’applicazione singola: non richiede microservizi né una distribuzione separata per ogni package.

Apri **14 Moduli applicativi**. Applicazione usa le regole di Dominio; Adapter implementa contratti del Dominio e collega i casi applicativi. Il dominio non dipende dagli adapter: è la scelta didattica che il diagramma rende facile controllare.

![Package: tre gruppi logici e le dipendenze dichiarate](immagini/atlante-14.png)

#### Elementi e confini

| Elemento/dato | Significato |
| --- | --- |
| Package | Modulo, namespace o layer semantico non distribuibile; il nome deve dire quale raggruppamento stai usando |
| Descrizione | Responsabilità del gruppo, contenuto incluso/escluso e criterio di raggruppamento |
| Contenimento | Relazione organizzativa con altri elementi ove dichiarata; non equivalente a un semplice trascinamento |
| Dependency | Uso di un altro gruppo; la direzione va dal dipendente al gruppo usato |

Il picker di questa notazione propone Package. Non usare un Container per ottenere una scheda più visibile: cambierebbe il ruolo semantico. Il package Dominio non è automaticamente una cartella chiamata domain; per legarlo ai sorgenti servono mapping o evidenze pertinenti.

#### Costruzione e lettura

Crea tre package con Add Element. Collega Applicazione verso Dominio “usa regole”; Adapter verso Dominio “implementa contratti”; Adapter verso Applicazione “collega esterni”. Questa direzione mantiene i dettagli esterni dipendenti dalle regole del negozio: il disegno permette di controllare che il dominio non debba conoscere un adapter specifico. Dai alle frecce nomi che spieghino perché la dipendenza esiste. Se una dipendenza ha entrambe le direzioni, chiediti se stai nascondendo un ciclo o usando un raggruppamento troppo ampio.

Un vincolo ADR può rendere esplicita una regola sulle dipendenze, ma la sola scelta grafica non impone una regola al compilatore. Un ciclo osservato nel codice richiede un’analisi del codice; un ciclo nel disegno indica ciò che hai dichiarato.

**Controllo:** sai spiegare la differenza fra package e servizio; ogni dipendenza ha un motivo; un lettore riconosce il nucleo e le parti esterne. Usa Class per i tipi interni, UML Component per i contratti e C4 Container per le applicazioni distribuibili.

### D15. Data Flow: dati, trasformazioni e archivi

Per comprendere un comportamento dobbiamo seguire anche le informazioni. Quali dati entrano, come vengono trasformati e dove finiscono? Come distinguiamo i dati trasferiti dalle azioni e dall’ordine temporale delle chiamate?

#### Quando e perché usarlo

Usa Data Flow per seguire dati sensibili, dati di ordine, fonti di prezzo o risultati di un processo. Aiuta quando una vista di chiamate mostra molto movimento ma non chiarisce che cosa attraversa il sistema.

Apri **15 Dati dell’acquisto**. Il Cliente fornisce dati acquisto; Elabora ordine consulta prezzi e disponibilità da Dati catalogo, scrive l’ordine confermato in Dati ordini e restituisce l’esito al Cliente. Le due frecce fra Cliente e processo portano dati diversi e hanno direzioni diverse.

![Data Flow: ingressi, trasformazione, archivi e risultato](immagini/atlante-15.png)

#### Elementi

| Elemento | Significato |
| --- | --- |
| Actor / Software System | Origine o destinatario esterno dei dati nella prospettiva scelta |
| Process | Trasformazione con input e output, ad esempio Elabora ordine; non un processo del sistema operativo |
| Data Store | Archivio logico da cui leggi o in cui scrivi; non richiede già una tabella fisica |
| Resource | Oggetto di dominio compatibile da usare quando chiarisce i dati rappresentati |
| Data Flow | Trasferimento nominato del dato, con direzione origine verso destinatario |

Scegli nomi di dato sulle frecce: “dati acquisto”, “prezzi e disponibilità”, “ordine confermato”. Un’etichetta “esegui” non dice quale informazione passa. Il processo dovrebbe spiegare la trasformazione e non funzionare come un generico nodo di smistamento senza responsabilità.

#### Costruzione e controllo

Aggiungi il Cliente esistente, il processo e i due archivi. È consigliato collegare prima ingresso e risultato per chiarire che cosa trasforma Elabora ordine, poi la lettura del catalogo e la scrittura degli ordini per precisare da dove provengono i dati e dove finiscono. Non è un ordine imposto dall’editor. Se vuoi dettagliare Elabora ordine, costruisci una seconda prospettiva con trasformazioni più piccole e mantieni riconoscibili gli stessi ingressi/uscite, così il dettaglio resta confrontabile con la vista generale.

Non interpretare le frecce come una cronologia completa: l’ordine temporale richiede Sequence o Activity. Una lettura dall’archivio e una risposta al Cliente non dimostrano che sia stata aperta una connessione reale. I tipi, la presenza e i vincoli sui payload vanno nei contratti.

**Controllo:** ogni processo ha ingressi/uscite motivati; distingui dati di catalogo e dati di ordine; le etichette non sono nomi generici di azioni. Se vuoi capire tabelle e FK apri Database Schema; se vuoi capire il protocollo di rete apri Network.

### D16. Network / Infrastructure: connessioni e confini

Le parti del sistema devono comunicare attraverso confini espliciti. Quali nodi e applicazioni sono collegati, e con quali protocolli? Come distinguiamo una connessione progettata da una configurazione osservata, senza confonderla con la collocazione del software?

#### Quando e perché usarlo

Usa questa vista per ragionare su raggiungibilità prevista, esposizione dei servizi e separazione dell’infrastruttura. Esplicita la provenienza delle informazioni, distinguendo configurazione osservata e scelta progettata.

Apri **16 Connessioni progettate**. Rete client raggiunge Web shop e il confine della Rete backend; il backend espone API Mercato, che comunica con Archivio Mercato. HTTPS 443 e SQL sono dichiarazioni dell’esempio. La vista non rappresenta una scansione della macchina o una configurazione applicata.

![Network: nodi, applicazioni e protocolli dichiarati](immagini/atlante-16.png)

#### Elementi e dettagli

| Elemento | Uso |
| --- | --- |
| Network Node | Nodo/confine di rete, come Rete backend; descrivi se è una zona, una rete o un endpoint concettuale |
| Deployment Node | Host/nodo di esecuzione quando la connessione richiede quel livello di dettaglio |
| Application / Container | Servizio, client o archivio che comunica; riusa le identità delle altre viste |
| Software System | Sistema interno o esterno coinvolto nella connessione |
| Protocollo e ambiente | Mezzo/contesto dichiarati, con versione o porta nel testo pertinente se note |
| Communication | Collegamento direzionale con intento e protocollo; non una regola firewall eseguita |

Non aggiungere un nodo cloud, CDN, VPC o database remoto solo perché è frequente in altri progetti. Se la fonte non lo dice, lascia la scelta aperta. Una rete e un’applicazione non sono lo stesso tipo di oggetto: il confine di rete descrive dove passa la comunicazione, il container chi la effettua.

#### Procedura e controllo

Crea i due Network Node per distinguere i confini di rete dalle applicazioni che li attraversano e aggiungi Web shop, API Mercato e Archivio Mercato esistenti. Collega gli estremi con Communication e completa i protocolli da Edit Cardinalities and Protocol: il lettore deve poter valutare quali parti dovranno comunicare e con quale mezzo previsto. Indica nella descrizione che la topologia è progettata; se stai importando configurazioni reali, conserva evidenze e perimetro osservato per distinguere i fatti rilevati dalle scelte ancora da realizzare.

**Controllo:** ogni collegamento dice chi comunica e come; le porte ignote non vengono inventate; le frecce non sono presentate come certificazione di sicurezza o disponibilità. Per collocazione degli artifact usa Deployment; per responsabilità del prodotto usa C4. Nessuna di queste viste esegue automaticamente provisioning, discovery, test di penetrazione o distribuzione.


## Appendici operative

Usa queste sezioni quando il percorso richiede di preparare l’ambiente, aprire i sorgenti, eseguire una prova o recuperare un errore. Gli strumenti dell’IDE aiutano a controllare ciò che il diagramma da solo non dimostra; non devi configurarli tutti prima di iniziare a progettare.


### A1. Installazione e avvio

Questa appendice serve a preparare ADE prima di T1, se non disponi già di un’applicazione funzionante. Installi gli strumenti con cui costruire e avviare la versione della guida; account IA e fiducia della cartella entrano in gioco soltanto nelle attività che li richiedono.

Se ADE è già installato e funzionante, torna a T1. Per l’avvio dai sorgenti servono Git, Python 3, gli strumenti di compilazione e il Node indicato in `.nvmrc`: allineare la versione evita incompatibilità con dipendenze e build. In questa revisione è **24.22.1**. Bun serve soltanto per il relativo profilo eseguibile.

#### macOS e Linux

Per riprodurre la versione collaudata in questa edizione, costruisci ADE dal workspace che contiene le correzioni, tenendo separate le cartelle dei progetti Mercato e Bottega. Se ti serve la base pubblicata, la sequenza qui sotto seleziona il commit di partenza e prepara l’applicazione. Chiudi l’istanza di sviluppo prima di aggiornare dipendenze e build. `nvm install` installa il Node richiesto da `.nvmrc` e `nvm use` lo seleziona nella shell.

```sh
git clone https://github.com/FrappaF/ADE.git
cd ADE
git checkout c8c4f6d81dc567e457e259c98a68e841221138bf
nvm install
nvm use
npm run ade:setup
./ade/scripts/dev.sh
```

Il checkout seleziona il commit di base in modalità detached HEAD. Per avviare l’edizione collaudata, esegui `nvm install`, `nvm use`, `npm run ade:setup` e `./ade/scripts/dev.sh` nella radice del workspace con le correzioni. `ade:setup` prepara dipendenze, client, motori locali, estensioni ed Electron. Il primo avvio richiede una connessione per gli artifact. Per gli avvii successivi usa `nvm use` e `./ade/scripts/dev.sh`. Puoi aggiungere al comando il percorso della cartella di un progetto.

Gli strumenti di compilazione e le librerie desktop servono alle dipendenze native dell’applicazione; controllali prima della preparazione, così un’assenza non viene confusa con un problema del progetto didattico. Su macOS verifica gli strumenti con `xcode-select -p`, `xcrun --find clang` e `python3 --version`. Se mancano i Command Line Tools, usa `xcode-select --install` e completa l’installazione. Su Debian/Ubuntu servono `build-essential`, `pkg-config`, `libx11-dev`, `libxkbfile-dev`, `libkrb5-dev`, `libsecret-1-dev`, `libgtk-3-dev`, `libgbm-dev`, `libnss3`, `libasound2-dev` e `xvfb`; per i test senza display anche `xauth`. I nomi possono variare con la distribuzione. La [preparazione del fork alla revisione di base](https://github.com/FrappaF/ADE/blob/c8c4f6d81dc567e457e259c98a68e841221138bf/ade/docs/fork-development.md#da-un-clone-pulito) raccoglie anche prerequisiti Windows e avvio con `scripts\code.bat`. Il collegamento richiede una connessione.

Se aggiorni il clone a una revisione successiva, seleziona nuovamente il suo Node e riesegui `npm run ade:setup`: il semplice riavvio non ricompila sempre i sorgenti cambiati. Prima di seguire la guida confronta la nuova interfaccia con la revisione indicata in apertura. Il controllo dei tipi e le suite del repository sono strumenti per sviluppare ADE; non servono per usare i progetti di questa guida.

#### Account e dati necessari

Per disegnare, salvare, importare sorgenti, simulare i casi e usare i profili deterministici non serve un account IA. Per conversazioni, interpretazione architetturale e implementazioni assistite devi configurare il provider richiesto dall’azione. La sezione L17 spiega la distinzione fra connessione, modello e budget.

La fiducia della cartella serve a consentire le attività che possono eseguirne il codice, come CLI e test. Usa **Manage Workspace Trust** nella palette per consultarla prima di quelle attività. Accorda fiducia alle copie degli esempi che hai estratto e controllato; un progetto importato può contenere comandi eseguibili propri.


### A2. File, workspace, editor e terminale

Apri gli strumenti dell’IDE quando devi collegare una regola del modello al suo file oppure eseguire il codice, come in L16 e L20. Explorer, editor e terminale servono a questo approfondimento; puoi tornare ai diagrammi per continuare la progettazione.

Apri **Progetto > Show IDE**, oppure **Project Settings > Developer Tools** per Files, Terminal, Debug e Git. Files apre il workspace; Terminal crea una sessione nella sua root. Controlla la directory delle sessioni già attive: la conservano anche cambiando progetto, quindi il prossimo comando potrebbe agire su una copia diversa da quella che stai leggendo nel canvas.

#### File e workspace

Usa l’Explorer per organizzare i sorgenti e i materiali della copia su cui stai lavorando. Crea, rinomina, copia, sposta o elimina file e cartelle dal menu contestuale; copia un percorso o rivela il file nel sistema operativo per ritrovare lo stesso documento fuori dall’IDE. Timeline e cronologia locale aiutano a confrontarne versioni precedenti. Apri un workspace salvato per ritrovare l’insieme di cartelle; aggiungi root o dividi gli editor quando devi confrontare più file senza passare continuamente da uno all’altro.

Usa Save As quando vuoi conservare una variante in un altro file e Save All quando una modifica coinvolge più documenti da scrivere insieme. Auto Save evita di richiamare manualmente il salvataggio durante l’editing, secondo la modalità che scegli. Codifica e terminatori vanno allineati ai requisiti dei file del progetto: cambiarli modifica il contenuto fisico. La cronologia locale aiuta a recuperare un file, ma non sostituisce un repository condiviso.

#### Cercare e modificare

Scegli la ricerca nel file per trovare un passaggio nel documento aperto, quella nel workspace per cercarne gli usi in più sorgenti e la definizione del simbolo per raggiungere il punto che lo dichiara. L’apertura rapida è utile quando conosci già il nome del file. La tabella raccoglie i tasti per queste azioni e per salvare o annullare gli edit.

| Azione | macOS | Windows / Linux |
| --- | --- | --- |
| Aprire la palette | Cmd+Shift+P oppure F1 | Ctrl+Shift+P oppure F1 |
| Salvare | Cmd+S | Ctrl+S |
| Aprire rapidamente un file | Cmd+P | Ctrl+P |
| Cercare nel file | Cmd+F | Ctrl+F |
| Cercare nel workspace | Cmd+Shift+F | Ctrl+Shift+F |
| Annullare | Cmd+Z | Ctrl+Z |
| Definizione del simbolo | F12, se il provider la supporta | F12, se il provider la supporta |
| Rinominare un simbolo | F2, se supportato | F2, se supportato |

Le associazioni effettive sono consultabili e personalizzabili in **Keyboard Shortcuts**. Per cambiare un simbolo usa la rinomina semantica, quando supportata: aggiorna i riferimenti riconosciuti dal linguaggio. Una sostituzione testuale può coinvolgere parole estranee; consulta l’anteprima e limita i percorsi.

Più cursori, selezione di occorrenze o colonne e modifica di righe riducono la ripetizione quando devi applicare lo stesso edit a più punti. Snippet, commenti e indentazione aiutano a scrivere; folding e wrap a leggere parti dense. Per comprendere il codice usa outline e breadcrumb per orientarti nella sua struttura, definizioni e riferimenti per seguire un simbolo. Completamenti, refactoring, quick fix e formattazione dipendono dal provider disponibile.

JS/TS includono il servizio TypeScript; HTML, CSS e JSON hanno i servizi web pertinenti. La colorazione di un linguaggio non installa automaticamente compilatore o debugger. Questo vale anche per Python, Java, C/C++, Go e gli altri linguaggi riconosciuti.

#### Terminale e task

Nel modulo codice di Mercato esegui `npm test` per controllare gli attesi già dichiarati, poi `npm start` per vedere l’esito della demo: i due comandi rispondono a domande diverse, come descritto in L16. Prima verifica di essere nella cartella `codice`. Più terminali o terminali divisi servono a tenere separate attività contemporanee; rinominali per riconoscerle, scegli il profilo della shell pertinente e usa ricerca e arresto del processo per consultare o interrompere l’esecuzione. La shell integration, quando presente, mostra comandi e relativo stato.

Usa un task quando il progetto ha già descritto una sequenza di build o test: riusi quella configurazione invece di ricostruire ogni volta i comandi. Dalla palette **Tasks: Run Task** avvia lo script o il task riconosciuto. I task possono avere dipendenze, restare in background e usare problem matcher per riportare gli errori. Avviare un task è una scelta di esecuzione; l’importazione ordinaria ADE non lo avvia al tuo posto.


### A3. Git, debug e test tecnici

Usa Git quando vuoi conservare o condividere una versione del codice; il debugger quando devi capire un risultato inatteso; i test quando vuoi confrontare il comportamento con gli attesi. Questi strumenti completano le review e le simulazioni ADE e producono prove da registrare nella consegna di L21.

#### Git

Usa Git per conservare una versione recuperabile e condividere modifiche riconoscibili. Apri **Source Control** e leggi il diff per controllare quali cambiamenti entreranno nel commit; prepara file o singoli hunk per includere quelli pertinenti allo stesso intento. Crea il commit con un messaggio che spieghi il cambiamento. **Push** pubblica i commit sul remoto e richiede account e permessi; fallo quando vuoi renderli disponibili agli altri. **Pull** e Git Sync scambiano commit con il remoto e sono diversi da ADE Sync, che riconcilia modello e codice.

Crea o cambia branch per tenere un esperimento separato dal lavoro condiviso; usa stash per accantonare temporaneamente edit non ancora committati. Cronologia, tag, worktree e confronto fra revisioni aiutano a ritrovare e confrontare una base. Prima di scartare file, ripristinare una revisione o risolvere un conflitto leggi il diff, così sai quali cambiamenti conserverai. La cronologia Git conserva commit; Undo ADE segue invece la pubblicazione revisionata e i suoi controlli di ripristino.

Le pull request complete dipendono da provider o estensioni aggiuntive: la presenza della vista Git non equivale a un client PR completo.

#### Debug tecnico

Usa il debugger per capire come il codice raggiunge un risultato inatteso. Apri **Run and Debug**; nel progetto JavaScript scegli una configurazione Node o un terminale di debug JavaScript, se disponibile. Inserisci un breakpoint in `calculateTotal`, avvia `src/demo.mjs` e osserva `quantity` e `total` con step/continue: puoi seguire il calcolo invece di dedurlo dal solo esito.

I breakpoint possono essere condizionali, logpoint o altri tipi supportati dall’adapter. Stack, variabili, watch e console appartengono al debugger tecnico. Non esiste ancora un debugger visuale ADE che mostri dal vivo l’esecuzione di tutti i diagrammi.

#### Test tecnici e verifiche ADE

Usa **Testing** per ritrovare i casi eseguibili, avviarli e risalire dal fallimento al file e all’output pertinenti. La vista scopre ed esegue test soltanto se un provider li espone; stack e coverage dipendono anch’essi dal supporto disponibile. In assenza di discovery per l’esempio Node, `npm test` nel terminale controlla comunque il comportamento del modulo.

Un test del progetto controlla il codice; un caso indipendente ADE dichiara un atteso separato dal generatore; una simulazione messaging prova consegne e policy locali; la verifica del profilo confronta la proposta con i casi previsti. Scegli la prova in base alla domanda che vuoi risolvere: per una consegna dichiarata serve il caso messaging, per il totale del modulo di L16 i suoi test. Registra anche ciò che è rimasto non eseguito, per non estendere il risultato a comportamenti diversi.


### A4. Documenti, browser, personalizzazione e integrazioni

Questi strumenti servono quando il lavoro richiede documenti, un’interfaccia web o un’integrazione aggiuntiva. Consulta la parte pertinente al tuo progetto: non devi configurare notebook, estensioni, chat e server per completare gli esercizi visuali della guida.

#### Documenti e contenuti

Per controllare come un documento verrà letto, apri un file Markdown e usa **Markdown: Open Preview** o la preview affiancata: confronti il testo sorgente con titoli, collegamenti e immagini renderizzati. Mermaid e formule sono disponibili nei contesti supportati. Mermaid nella documentazione e il modello semantico ADE sono oggetti distinti: una figura Mermaid non aggiorna automaticamente le identità del progetto.

Usa un notebook quando vuoi conservare testo, codice e risultati per celle nello stesso documento. Per eseguire le celle serve un kernel, cioè il motore che le valuta: la lettura del formato IPYNB e dei renderer non installa da sola un ambiente Jupyter. Immagini, audio, video, webview e editor personalizzati dipendono dai formati e dalle estensioni disponibili.

#### Browser

Usa il browser quando un progetto produce un’interfaccia web da provare o devi consultare documentazione online. Quello integrato nell’editor può aprire URL, navigare, cercare, regolare lo zoom e offrire strumenti di sviluppo ed emulazione per esaminare il risultato. Le azioni di condivisione della scheda, screenshot o elementi con l’agente dipendono dall’integrazione attiva. Puoi aprire il risultato dell’applicazione nel browser esterno quando l’azione è disponibile.

#### Personalizzazione ed estensioni

Adatta l’ambiente alle attività che svolgi spesso: **Preferences: Open Settings (UI)** apre le impostazioni grafiche, **Color Theme** modifica la presentazione e **Keyboard Shortcuts** i tasti. Scegli il livello utente per le tue preferenze abituali, workspace o cartella per quelle del progetto, linguaggio per le regole di un tipo di file. Il livello evita che una scelta locale cambi involontariamente gli altri progetti. Usa profili diversi se vuoi separare anche preferenze ed estensioni fra attività.

Consulta Extensions quando ti manca una capacità specifica, per esempio il debugger o il kernel del linguaggio che vuoi usare. La vista mostra estensioni integrate e installate e permette installazione da VSIX e gestione dell’abilitazione. Il prodotto non configura automaticamente il Marketplace Microsoft: disponibilità di gallerie, debugger, kernel e servizi online dipende dalla distribuzione.

Per diagnosticare un problema consulta Problems, Output e i log del servizio pertinente. Mantieni distinta una diagnostica del modello da un errore del parser, del compilatore o dell’estensione.

#### Chat e MCP

Usa la chat generale per una richiesta che coinvolge più parti del progetto, quella inline per un intervento nel codice aperto. File e selezioni allegati danno all’assistente il contesto da considerare; modello e modalità dipendono dal provider disponibile. Leggi le modifiche proposte prima di accettarle o rifiutarle, per confrontarle con l’intento. È una superficie diversa dalla conversazione temporanea dei diagrammi.

MCP (Model Context Protocol) collega strumenti e dati esterni alle integrazioni che li supportano. Configura un server quando ti serve una sua capacità concreta nel lavoro: i comandi MCP permettono di aggiungerlo, scegliere configurazione utente o workspace, consultarne stato/output e gestire fiducia e strumenti. Controllare le capacità disponibili chiarisce che cosa potrà fare l’integrazione. La presenza di servizi upstream non significa che tutti siano già configurati per ADE.


### A5. Accessibilità e uso da tastiera

Usa tastiera e lettura testuale per raggiungere gli stessi oggetti e controllarne il significato senza dipendere dalla disposizione del canvas. La lettura di relazioni, condizioni e contratti è utile anche per verificare che il modello dica ciò che intendi, mentre i temi e le impostazioni adattano la presentazione alle tue esigenze.

Sul canvas usa Tab per raggiungere gli elementi ed Enter per selezionarli e consultarne le proprietà. Nei diagrammi modificabili con layout libero, le frecce spostano il nodo focalizzato e Shift amplia il passo: servono a rendere leggibile la disposizione. Sequence usa invece un ordine dichiarato: modifica partecipanti e messaggi dalle proprietà, come in L7, anziché spostarne le coordinate. Con il focus sullo sfondo, le frecce spostano la vista per leggere altre parti del diagramma. **Shift+F10** apre il menu contestuale dell’oggetto focalizzato.

**Diagram > Read** e l’Accessible View consentono di controllare elementi, relazioni, condizioni e contratti senza dipendere da colori o disposizione. Con una review attiva viene letto il suo contenuto. L’aiuto contestuale mostra i tasti effettivi; su macOS quelli standard comprendono Option+F1 per l’aiuto e Option+F2 per la lettura, quando non rimappati.

Chiudi il lettore con Escape per tornare al contesto. Se preferisci meno suggerimenti cerca la verbosità ADE nelle impostazioni grafiche. Temi chiari, scuri e ad alto contrasto e preferenze di movimento ridotto aiutano ad adattare la presentazione.

La navigazione implementata e i test automatici non costituiscono una certificazione completa VoiceOver/NVDA su tutte le piattaforme. Se un controllo non annuncia nome o stato, annota oggetto, azione, sistema operativo e tecnologia assistiva per la segnalazione.


### A6. Problemi comuni e recupero

Usa questa tabella quando il risultato di un passaggio non coincide con quello atteso. Parti dal sintomo per controllare il prerequisito o il contesto che lo può spiegare, prima di creare altri oggetti, cambiare attesi o ripetere un’applicazione. L’obiettivo è recuperare il percorso conservando il lavoro già corretto.

| Cosa osservi | Cosa controllare e fare |
| --- | --- |
| Non vedo il mio progetto | Open Project deve puntare alla cartella della copia, per caricare il modello dell’esercizio; il clone ADE e il solo file di codice hanno un altro scopo |
| Il canvas sembra vuoto | Usa Fit Diagram per ritrovare elementi fuori dall’inquadratura, poi System Map per cercarli nell’intero sistema; così eviti di crearne duplicati. Dettagli in A9 |
| Voglio un elemento già presente | Add Existing Element riusa l’identità; Add Element crea una nuova definizione |
| Ho tolto un nodo ma esiste ancora | È stato rimosso dalla vista; consulta Details/Impact per sapere quali altri riferimenti coinvolgerebbe l’eliminazione dal sistema |
| Non vedo file e terminale | Usa menu progetto, Show IDE oppure Project Settings > Developer Tools quando devi leggere sorgenti o eseguire comandi; il canvas resta il contesto della progettazione |
| Una voce non compare | Seleziona l’oggetto e la notazione pertinenti: i comandi dipendono dal contesto. Controlla anche tipo di documento e prerequisiti |
| Apply to Model è disabilitato in Structural Blueprint | Apri **Review** per individuare eventuali configurazioni incomplete. Se un campo richiede un oggetto mancante, crealo prima di completare la bozza |
| Ho compilato Structural Blueprint e il modello è ancora invariato | Premi **Apply to Model** per applicare la bozza, poi **Save** per conservarla nel progetto |
| Il testo viene rifiutato nel caso numerico | Usa un numero intero per un input ordinario; Different Value Type serve a provare deliberatamente un tipo errato in un caso negativo |
| Una condizione non si può salvare | Il predicato deve dare una risposta booleana alla condizione; completa confronto o logica con tipi compatibili |
| Il modello è salvabile ma non generabile | Risolvi le diagnostiche di readiness su tipi, ownership, criteri, binding e runtime: indicano le informazioni necessarie al profilo scelto, oltre al salvataggio del disegno |
| Apply non è disponibile | Leggi lo stato corrente per individuare quale condizione manca: review incompleta/obsoleta, domande aperte o verifica mancante/fallita |
| Ho cambiato un criterio dopo i test | Prepara e verifica una nuova review: il risultato precedente riguarda la vecchia regola |
| I test sono stati annullati | Riesegui la verifica e attendi un esito completo; annullato non equivale a passato |
| Undo è bloccato da un file | Confronta e conserva le modifiche manuali successive, perché il ripristino non deve sovrascriverle; ripristina solo se è la scelta desiderata |
| L’import non ha prodotto architettura | Source Inventory Ready raccoglie le evidenze; Explore Architecture le interpreta nel percorso incrementale. Consulta L16-L17 per scegliere quale risultato ti serve |
| Un’evidenza è superata | Aggiorna l’analisi per riferirla ai sorgenti correnti; la vecchia posizione potrebbe ora indicare altro codice |
| L’account è connesso ma la richiesta fallisce | Controlla separatamente eseguibile, modello esatto, quota e configurazione del provider: la connessione dell’account da sola non li rende disponibili |
| È finito il budget | Per proseguire, aumenta esplicitamente quello dell’operazione pertinente; il budget IA strutturato e l’esplorazione sono separati |
| Ho chiuso la chat e non vedo la cronologia | La modale è temporanea; riparti dal piano/bozze persistenti per ritrovare il lavoro completato, oppure avvia una nuova conversazione |
| Sync non è disponibile | Verifica formato del modello e adapter: servono a riconoscere le corrispondenze supportate fra modello e codice; l’esplorazione v5 non abilita il percorso legacy |
| Bun manca | Installa la versione del profilo e rendila disponibile all’avvio, per eseguire la verifica con il runtime scelto; ADE non ripiega silenziosamente su Node |
| Non vedo test o un debugger | Verifica il provider/estensione che espone quelle azioni; per controllare l’esempio Node puoi comunque eseguire npm test nel terminale |
| Non riesco a salvare | Leggi l’errore corrente e verifica destinazione, permessi, conflitti e stato del documento; salva una copia se appropriato per conservare il lavoro mentre risolvi la destinazione |

Per permettere a un’altra persona di riprodurre il difetto, prepara passi, risultato atteso/osservato, versione ADE, sistema operativo, diagramma coinvolto e uno screenshot pertinente. Una copia sintetica del progetto riduce i dettagli estranei alla riproduzione. Consulta Output e i comandi di apertura log della palette per aggiungere il messaggio del servizio che ha fallito.


### A7. Garanzie, disponibilità e copertura della guida

Consulta queste matrici prima di scegliere un approfondimento o di dichiarare completata una consegna. La prima collega ogni capacità al risultato che puoi effettivamente ottenere; la seconda indica dove impararla e quali prerequisiti preparare. Così una simulazione locale o una vista salvata non vengono usate come prova di un servizio reale.

| Capacità | Cosa puoi fare oggi | Cosa non implica |
| --- | --- | --- |
| Disegno | Modificare modelli e sedici notazioni nel loro sottoinsieme | Implementazione automatica di ogni forma UML/C4 |
| Importazione | Inventario e analisi dei profili supportati | Esecuzione o comprensione completa di qualsiasi linguaggio |
| Diagrammi IA | Esplorazione, piano, bozze, correzione e review | Prova delle chiamate runtime o infrastruttura realmente installata |
| Chat modello-codice | Chiedere implementazione e test contestuali | Journal/undo deterministico di ogni modifica dell’assistente |
| Worktree | Revisione separata e test Node nel percorso ammesso | Sandbox del sistema operativo o runner universale |
| Profilo eseguibile | Predicati, interazioni, macchine piatte e messaging formalizzati | Corpi arbitrari, framework completi o transazioni distribuite |
| Simulazione | Provare dati, eventi e risposte dichiarati | Monitoraggio di servizi o broker reali |
| Reverse e Sync | Trasformazioni nei sottoinsiemi dichiarati, con review | Ricostruzione illimitata dell’intento da codice arbitrario |
| Dati e runtime | Mapping, schemi rappresentati e piano Node/Bun | Migrazioni automatiche di database o servizi vivi |
| Apply | Scrivere modifiche locali revisionate | Commit, push o deploy |

Gli esempi permettono di provare progettazione e profili locali senza aggiungere servizi. La configurazione IA, gli SDK, gli eseguibili esterni, i kernel e i debugger dipendono dall’ambiente effettivamente installato.

Usa la matrice seguente per passare dall’attività che vuoi svolgere alla lezione pertinente e verificare se il tuo ambiente la consente. I comandi di dettaglio dell’editor dipendono dal provider pertinente; non tutte le combinazioni di sistema operativo, estensione e servizio esterno vengono eseguite dal solo progetto di esempio.

| Famiglia | Dove impararla | Disponibilità/prerequisito |
| --- | --- | --- |
| Progetti, salvataggio, recupero, identità, navigazione, mappa | T1-T5; L2; A6 | Locale |
| Elementi, relazioni, proprietà, layout, 16 notazioni | L2-L10; D0-D16 | Locale, compatibilità della vista |
| Contratti, tipi, ownership, porte, mapping, ADR, impatto | L4-L5; L11 | Blueprint valido; readiness da completare |
| Predicati, input tipizzati, casi, review, pubblicazione, undo | L12 | Profilo locale e runtime disponibile |
| Scenari descrittivi, prospettive e interazioni eseguibili | L7; L13; D7-D8 | Dati descrittivi oppure contratto eseguibile esplicito |
| Macchine a stati e messaggistica | L14-L15; D9 | Simulazioni locali; nessun broker richiesto |
| Importazione, scope, evidenze, indici, versioni | L16 | Sorgenti accessibili; servizio semantico pertinente |
| Account IA, conversazioni, diagrammi, benchmark | L17 | Account, CLI/modello e budget espliciti |
| Aggiornamento codice, worktree, Sync e riconciliazione | L18-L19 | Repository/radice pertinenti; provider dove previsto |
| Reverse, migrazione runtime, task e continuità | L20 | Sottoinsieme del profilo e runtime disponibili |
| File, editing, linguaggi, terminale, task | A2 | Servizi del linguaggio e tool locali |
| Git, debug, test e coverage | A3 | Git/remoto, debugger o test provider secondo l’azione |
| Notebook, documenti, media, browser | A4 | Formato, kernel o estensione pertinente |
| Personalizzazione, estensioni, trust, chat e MCP | A1; A4 | Account/SDK/estensioni dove richiesti |
| Accessibilità e presentazione | A5 | Tastiera, lettura testuale e impostazioni del workbench |

Il verbale del laboratorio registra le prove su ADE desktop macOS e i controlli successivi. Le immagini comprendono le 16 notazioni della soluzione, che contiene 18 viste, e schermate dei comandi. I profili eseguibili sono quelli dei moduli didattici. Le procedure IA dipendono dai prerequisiti di L17-L19. Nomi, numero di bozze e risultati possono variare in base al provider.


### A8. Glossario e riferimenti

Consulta il glossario quando due parole sembrano indicare lo stesso risultato: una review da leggere, per esempio, non è ancora un Apply eseguito. Le definizioni mantengono distinte progettazione, implementazione e prova, così puoi descrivere con precisione ciò che hai ottenuto o chiedere un chiarimento.

| Termine | Significato operativo |
| --- | --- |
| Modello | Definizioni condivise di elementi, relazioni, tipi e comportamenti |
| Vista / diagramma | Prospettiva con notazione e layout sul modello |
| Identità | Riferimento stabile, indipendente da nome e posizione |
| Feature | Capacità o area funzionale del sistema |
| Blueprint | Fondazione architetturale e contrattuale condivisa |
| Ownership | Responsabilità esplicita di sistema, container, componente o lifecycle |
| Contratto | Input, risultati, errori, effetti, permessi e criteri pertinenti |
| Predicato | Condizione pura tipizzata con risultato booleano o indeterminato ammesso |
| Criterio di accettazione | Regola di business dichiarata, spesso Given/When/Then |
| Caso indipendente | Input e atteso scritti dall’autore separatamente dal generatore |
| Evidenza | Collegamento versionato a un fatto o range di sorgente |
| Scenario | Occorrenze, condizioni e ordine dichiarato di un comportamento |
| Bozza | Proposta non ancora applicata al modello pubblicato |
| Review | Contenuto e differenze da leggere prima di un’applicazione |
| Baseline | Stato comune usato per confrontare modello e codice |
| Worktree | Cartella Git separata per una revisione del codice |
| Readiness | Completezza e compatibilità per il target/profilo scelto |
| Apply | Applicazione locale delle modifiche revisionate |
| Reverse | Ricostruzione delimitata di modifiche supportate dal sorgente |
| Recovery | Ripresa controllata di un’operazione interrotta |
| ADR | Decisione architetturale con motivazioni, stato e storia |

Questa edizione segue l’editor **Structural Blueprint**, il riuso delle relazioni con **Add Existing Relationship** e l’Atlante a livelli di **System Map**. Le schermate aiutano a orientarsi. In T2 trovi gli esiti per riconoscere le quattro prospettive dell’acquisto.

Approfondimenti online del repository alla revisione di base: [editing visuale](https://github.com/FrappaF/ADE/blob/c8c4f6d81dc567e457e259c98a68e841221138bf/ade/docs/visual-editing.md), [esploratore semantico](https://github.com/FrappaF/ADE/blob/c8c4f6d81dc567e457e259c98a68e841221138bf/ade/docs/semantic-explorer.md), [accessibilità](https://github.com/FrappaF/ADE/blob/c8c4f6d81dc567e457e259c98a68e841221138bf/ade/docs/accessibility.md), [importazione](https://github.com/FrappaF/ADE/blob/c8c4f6d81dc567e457e259c98a68e841221138bf/ade/docs/code-import.md), [collaborazione IA](https://github.com/FrappaF/ADE/blob/c8c4f6d81dc567e457e259c98a68e841221138bf/ade/docs/ai-collaboration.md), [riconciliazione](https://github.com/FrappaF/ADE/blob/c8c4f6d81dc567e457e259c98a68e841221138bf/ade/docs/reconciliation.md) e [profili eseguibili](https://github.com/FrappaF/ADE/blob/c8c4f6d81dc567e457e259c98a68e841221138bf/ade/docs/diagram-driven-ai/dai-12.md). Richiedono una connessione e comprendono anche verbali storici: per le procedure parti dai capitoli di questa guida.

Gli esempi sono sintetici e derivano dai modelli dimostrativi del repository ADE e dal laboratorio Bottega. Sono distribuiti con la licenza MIT del progetto. Il pacchetto non contiene account, credenziali, cronologie IA o repository Git personali.

Per approfondire il significato delle notazioni: [C4 System Context](https://c4model.com/diagrams/system-context), [C4 Container](https://c4model.com/diagrams/container), [C4 Component](https://c4model.com/diagrams/component) e [specifica UML 2.5.1 dell’OMG](https://www.omg.org/spec/UML/2.5.1). Questi riferimenti descrivono le notazioni; per le operazioni effettivamente disponibili in ADE valgono i form e i limiti indicati nella guida. ADE non viene presentato come implementazione completa di ogni costrutto UML.

### A9. System Map: Atlante a livelli e filtri cumulativi

Usa System Map quando vuoi trovare gli elementi coinvolti in un’attività, come l’acquisto del Cliente, senza aprire ogni diagramma. I filtri delimitano il contesto che ti interessa; l’apertura dei livelli ne mostra i dettagli. Da quel contesto puoi poi raggiungere l’identità o la vista da consultare.

System Map segue i gruppi dichiarati nel modello e permette di raggiungere anche gli elementi non disegnati.

#### Dove aprire la mappa

Scegli uno di questi accessi equivalenti alla stessa mappa: la sidebar mentre navighi nel progetto, il pulsante mentre leggi un diagramma o la palette per richiamarla da tastiera. Non occorre percorrerli tutti.

- Nella sidebar ADE, in alto: **Home**, **System Map** e **Search System**, disposti in verticale. La mappa è disponibile anche quando il progetto nella navigazione è chiuso; **New > Structural Blueprint** raccoglie l’editing strutturale.
- Sopra un diagramma: **System Map**, accanto a **Diagrams**.
- Dalla palette: **A.D.E: Show System Map**. Aprila con `Cmd+Shift+P` su macOS o `Ctrl+Shift+P` su Windows/Linux.

![System Map con il filtro Cliente: la barra mantiene visibili i criteri attivi](immagini/17-system-map-panorama.png)

#### Come leggere l’Atlante

Leggi i gruppi per distinguere chi usa il sistema, quale capacità ti interessa e quali responsabilità sono condivise fra più capacità. A sinistra trovi gli **Actors**. La colonna centrale mostra prima le **Areas**, poi le **Features** dell’area aperta, infine gli **Internal Elements** della feature aperta. A destra, **Shared Elements** raccoglie gli elementi condivisi o non assegnati a una sola feature.

Se il modello non dichiara aree, usa **Features Without a Declared Area**. È il caso del tour Bottega Ordini: il gruppo rende accessibili le feature senza introdurre un’area di business fittizia.

| Controllo | Effetto |
| --- | --- |
| Corpo della scheda | Aggiunge un filtro; il livello corrente rimane aperto |
| Freccia a destra della scheda | Apre il livello inferiore e mantiene i filtri |
| × accanto a un filtro | Rimuove soltanto quel criterio |
| Percorso sopra la mappa | Risale di livello mantenendo i filtri |

#### Prova guidata: Cliente e Conferma acquisto

Isola ciò che serve al Cliente per acquistare: selezionerai un attore e una feature, poi ne aprirai i dettagli conservando quel contesto. Aggiungi anche il filtro dell’area per provare a rimuovere un solo criterio senza perdere gli altri: è un esercizio sui filtri, non un prerequisito tecnico per leggere la feature.

1. Apri Bottega Ordini e premi **System Map**. Clicca sul corpo di **Cliente** per concentrarti sulle capacità collegate a quell’attore: compare tra i filtri attivi.
2. Clicca sul corpo di **Features Without a Declared Area**, il gruppo che raccoglie le feature del tour senza inventare un’area di business. I due filtri, Cliente e area, rimangono attivi; sei ancora nel livello generale.
3. Premi la freccia del gruppo per aprirlo. Clicca sul corpo di **Conferma acquisto** per distinguere l’acquisto dalla gestione dei resi nel contesto del Cliente.
4. Premi la freccia di Conferma acquisto per leggere le responsabilità interne e condivise della capacità scelta. Cliente, area e feature restano nella barra dei filtri.
5. Rimuovi il filtro dell’area con la sua **×** per provare la rimozione indipendente: Cliente e Conferma acquisto restano applicati. Cliccare nuovamente una scheda già filtrata mantiene il suo filtro attivo.

![Tre filtri attivi: Cliente, area e feature; gli elementi interni rimangono disponibili](immagini/18-system-map-filtri.png)

I filtri sono cumulativi: ogni nuovo criterio restringe il contesto comune. Il filtro per un attore conserva i contenuti interni e condivisi delle feature collegate. Con una combinazione incompatibile la mappa mostra uno stato vuoto e lascia tutti i filtri visibili: rimuovi una × per ampliare i risultati.

#### Ricerca, relazioni e sistemi estesi

Quando conosci il nome di un oggetto, usa la ricerca per raggiungerlo senza aprire tutti i livelli: riguarda l’intero sistema, compresi gli oggetti fuori pagina. Il clic su un risultato aggiunge un filtro; la freccia, quando presente, apre il suo livello. Usa **Inspect …** per leggere i dettagli di quell’identità oppure i pulsanti dei diagrammi per vederla nella prospettiva scelta.

Le linee aggregano relazioni dichiarate fra gli oggetti mostrati, per leggere i collegamenti del contesto senza aprire ogni vista. Con un attore filtrato, una linea continua indica una relazione diretta e una tratteggiata una relazione nel contesto delle feature. Per valutare una dipendenza specifica apri **Relationships**: leggi origine, destinazione, condizioni ed errori originali, perché la linea aggregata da sola non ne mostra tutti i dettagli e non crea una nuova relazione di business.

![Estratto di Relationships: origine e destinazione restano identità del modello](immagini/19-system-map-relazioni.png)

Ogni elenco ha pagine e conteggi propri. Cambiare pagina, livello o scheda, oppure tornare da un diagramma, conserva i filtri nel corso della sessione dell’editor. In una finestra stretta le colonne si dispongono in verticale: conteggi e dettagli delle relazioni restano consultabili.

**Controllo A9:** aggiungi Cliente, area e feature; apri gli elementi interni soltanto con le frecce. Togli una sola × e verifica che gli altri filtri rimangano applicati.
